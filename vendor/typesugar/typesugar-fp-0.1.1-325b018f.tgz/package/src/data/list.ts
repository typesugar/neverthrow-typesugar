/**
 * Immutable List Data Type
 *
 * A purely functional, immutable singly-linked list.
 * Either Cons(head, tail) or Nil (empty).
 *
 * PEP-014 Wave 2: Nil is `null` at runtime for zero-cost empty lists.
 * Cons is `{ head, tail }` with no `_tag` field.
 */

import type { TypeFunction } from "@typesugar/type-system";
import type { Option } from "./option.js";
import { Some, None, isSome } from "./option.js";
import type { Eq, Ord, Ordering } from "../typeclasses/eq.js";
import type { Show } from "../typeclasses/show.js";
import type { Semigroup, Monoid } from "../typeclasses/semigroup.js";

// ============================================================================
// List Type Definition
// ============================================================================

/**
 * Cons variant — a non-empty list cell.
 * At runtime it's `{ head: A; tail: List<A> }` — no `_tag` field.
 */
export interface Cons<A> {
  readonly head: A;
  readonly tail: List<A>;
}

/**
 * Nil type — the empty list, represented as `null` at runtime.
 *
 * This saves ~32 bytes per empty list allocation compared to `{ _tag: "Nil" }`.
 */
export type Nil = null;

/**
 * Immutable singly-linked list — either Cons (non-empty) or Nil (null/empty).
 *
 * Discrimination is via null-check: `list !== null` narrows to Cons.
 * Or use type guards: `isCons(list)` / `isNil(list)`.
 *
 * @hkt
 */
export type List<A> = Cons<A> | Nil;

/**
 * Type-level function for `List<A>`.
 * Kind<ListF, number> resolves to List<number>.
 */
export interface ListF extends TypeFunction {
  readonly __kind__: unknown;
  readonly _: List<this["__kind__"]>;
}

// ============================================================================
// Constructors
// ============================================================================

/**
 * Create a Cons cell (non-empty list)
 */
export function Cons<A>(head: A, tail: List<A>): Cons<A> {
  return { head, tail };
}

/**
 * The empty list (singleton) — `null` at runtime
 */
export const Nil: Nil = null;

// ============================================================================
// Pattern matching: Destructure instances (std's match(), match: switch)
// ============================================================================
//
// `match(o).case(Cons(h, t))` resolves these by the constructor's symbol. The
// `@destructure` descriptor is what the macro inlines (zero cost: a null
// test and a direct binding); `extract` is the same logic as a function.

/**
 * `Cons(head, tail)` in a pattern: matches a non-empty List.
 *
 * @impl Destructure<typeof Cons, List<unknown>, [unknown, List<unknown>]>
 * @destructure not-null -> head, tail
 */
export const destructureCons = {
  extract: <A>(l: List<A>): [A, List<A>] | undefined => (l != null ? [l.head, l.tail] : undefined),
};

/**
 * `Nil` in a pattern: matches the empty List (`null`).
 *
 * @impl Destructure<typeof Nil, List<unknown>, []>
 * @destructure null
 */
export const destructureNil = {
  extract: <A>(l: List<A>): [] | undefined => (l == null ? [] : undefined),
};

/**
 * Create a list from variadic arguments
 */
export function of<A>(...as: A[]): List<A> {
  return fromArray(as);
}

/**
 * Create a list from an array
 */
export function fromArray<A>(arr: readonly A[]): List<A> {
  let result: List<A> = Nil;
  for (let i = arr.length - 1; i >= 0; i--) {
    result = Cons(arr[i], result);
  }
  return result;
}

/**
 * Create a list from an iterable
 */
export function fromIterable<A>(iter: Iterable<A>): List<A> {
  return fromArray([...iter]);
}

/**
 * Create a single-element list
 */
export function singleton<A>(a: A): List<A> {
  return Cons(a, Nil);
}

/**
 * Create a list with n copies of a value
 */
export function replicate<A>(n: number, a: A): List<A> {
  let result: List<A> = Nil;
  for (let i = 0; i < n; i++) {
    result = Cons(a, result);
  }
  return result;
}

/**
 * Create a list from a range
 */
export function range(start: number, end: number): List<number> {
  let result: List<number> = Nil;
  for (let i = end - 1; i >= start; i--) {
    result = Cons(i, result);
  }
  return result;
}

/**
 * Create an empty list
 */
export function empty<A = never>(): List<A> {
  return Nil;
}

// ============================================================================
// Type Guards
// ============================================================================

/**
 * Check if List is Cons (non-empty)
 */
export function isCons<A>(list: List<A>): list is Cons<A> {
  return list !== null;
}

/**
 * Check if List is Nil (empty)
 */
export function isNil<A>(list: List<A>): list is Nil {
  return list === null;
}

/**
 * Check if list is empty
 */
export function isEmpty<A>(list: List<A>): boolean {
  return list === null;
}

/**
 * Check if list is non-empty
 */
export function nonEmpty<A>(list: List<A>): boolean {
  return list !== null;
}

// ============================================================================
// Basic Operations
// ============================================================================

/**
 * Get the head of the list
 */
export function head<A>(list: List<A>): Option<A> {
  return list !== null ? Some(list.head) : None;
}

/**
 * Get the tail of the list, or `undefined` for the empty list.
 *
 * Not `Option<List<A>>`: both `Nil` and `None` are `null` at runtime, so
 * `Some(Nil)` would be indistinguishable from `None` (the tail of a
 * one-element list would read as "no tail").
 */
export function tail<A>(list: List<A>): List<A> | undefined {
  return list !== null ? list.tail : undefined;
}

/**
 * Get the last element
 */
export function last<A>(list: List<A>): Option<A> {
  if (list === null) return None;
  let current = list;
  while (current.tail !== null) {
    current = current.tail;
  }
  return Some(current.head);
}

/**
 * Get all but the last element, or `undefined` for the empty list
 * (not `Option<List<A>>` — see `tail`).
 */
export function init<A>(list: List<A>): List<A> | undefined {
  if (list === null) return undefined;
  return dropLast(list, 1);
}

/**
 * Get the nth element (0-indexed)
 */
export function get<A>(list: List<A>, index: number): Option<A> {
  let current: List<A> = list;
  let i = 0;
  while (current !== null) {
    if (i === index) return Some(current.head);
    current = current.tail;
    i++;
  }
  return None;
}

/**
 * Get the length of the list
 */
export function length<A>(list: List<A>): number {
  let count = 0;
  let current: List<A> = list;
  while (current !== null) {
    count++;
    current = current.tail;
  }
  return count;
}

// ============================================================================
// Transformations
// ============================================================================

/**
 * Map over the list (stack-safe)
 */
export function map<A, B>(list: List<A>, f: (a: A) => B): List<B> {
  let acc: List<B> = Nil;
  let current: List<A> = list;
  while (current !== null) {
    acc = Cons(f(current.head), acc);
    current = current.tail;
  }
  return reverse(acc);
}

/**
 * FlatMap over the list (stack-safe)
 */
export function flatMap<A, B>(list: List<A>, f: (a: A) => List<B>): List<B> {
  let acc: List<B> = Nil;
  let current: List<A> = list;
  while (current !== null) {
    let inner: List<B> = f(current.head);
    while (inner !== null) {
      acc = Cons(inner.head, acc);
      inner = inner.tail;
    }
    current = current.tail;
  }
  return reverse(acc);
}

/**
 * Filter the list (stack-safe)
 */
export function filter<A>(list: List<A>, predicate: (a: A) => boolean): List<A> {
  let acc: List<A> = Nil;
  let current: List<A> = list;
  while (current !== null) {
    if (predicate(current.head)) {
      acc = Cons(current.head, acc);
    }
    current = current.tail;
  }
  return reverse(acc);
}

/**
 * Filter and map in one pass (stack-safe)
 */
export function filterMap<A, B>(list: List<A>, f: (a: A) => Option<B>): List<B> {
  let acc: List<B> = Nil;
  let current: List<A> = list;
  while (current !== null) {
    const result = f(current.head);
    if (isSome(result)) {
      acc = Cons(result as B, acc);
    }
    current = current.tail;
  }
  return reverse(acc);
}

/**
 * Reverse the list
 */
export function reverse<A>(list: List<A>): List<A> {
  let result: List<A> = Nil;
  let current: List<A> = list;
  while (current !== null) {
    result = Cons(current.head, result);
    current = current.tail;
  }
  return result;
}

/**
 * Prepend an element
 */
export function prepend<A>(a: A, list: List<A>): List<A> {
  return Cons(a, list);
}

/**
 * Append an element
 */
export function appendOne<A>(list: List<A>, a: A): List<A> {
  return append(list, singleton(a));
}

/**
 * Append two lists (stack-safe)
 */
export function append<A>(list1: List<A>, list2: List<A>): List<A> {
  if (list1 === null) return list2;
  if (list2 === null) return list1;
  let reversed = reverse(list1);
  let result: List<A> = list2;
  while (reversed !== null) {
    result = Cons(reversed.head, result);
    reversed = reversed.tail;
  }
  return result;
}

/**
 * Flatten a list of lists
 */
export function flatten<A>(lists: List<List<A>>): List<A> {
  return flatMap(lists, (list) => list);
}

/**
 * Take the first n elements (stack-safe)
 */
export function take<A>(list: List<A>, n: number): List<A> {
  let acc: List<A> = Nil;
  let current: List<A> = list;
  let count = n;
  while (count > 0 && current !== null) {
    acc = Cons(current.head, acc);
    current = current.tail;
    count--;
  }
  return reverse(acc);
}

/**
 * Drop the first n elements (stack-safe)
 */
export function drop<A>(list: List<A>, n: number): List<A> {
  let current: List<A> = list;
  let count = n;
  while (count > 0 && current !== null) {
    current = current.tail;
    count--;
  }
  return current;
}

/**
 * Drop the last n elements
 */
export function dropLast<A>(list: List<A>, n: number): List<A> {
  const len = length(list);
  return take(list, Math.max(0, len - n));
}

/**
 * Take elements while predicate holds (stack-safe)
 */
export function takeWhile<A>(list: List<A>, predicate: (a: A) => boolean): List<A> {
  let acc: List<A> = Nil;
  let current: List<A> = list;
  while (current !== null && predicate(current.head)) {
    acc = Cons(current.head, acc);
    current = current.tail;
  }
  return reverse(acc);
}

/**
 * Drop elements while predicate holds
 */
export function dropWhile<A>(list: List<A>, predicate: (a: A) => boolean): List<A> {
  let current: List<A> = list;
  while (current !== null && predicate(current.head)) {
    current = current.tail;
  }
  return current;
}

/**
 * Zip two lists (stack-safe)
 */
export function zip<A, B>(listA: List<A>, listB: List<B>): List<[A, B]> {
  let acc: List<[A, B]> = Nil;
  let currentA: List<A> = listA;
  let currentB: List<B> = listB;
  while (currentA !== null && currentB !== null) {
    acc = Cons([currentA.head, currentB.head], acc);
    currentA = currentA.tail;
    currentB = currentB.tail;
  }
  return reverse(acc);
}

/**
 * Zip with a function (stack-safe)
 */
export function zipWith<A, B, C>(listA: List<A>, listB: List<B>, f: (a: A, b: B) => C): List<C> {
  let acc: List<C> = Nil;
  let currentA: List<A> = listA;
  let currentB: List<B> = listB;
  while (currentA !== null && currentB !== null) {
    acc = Cons(f(currentA.head, currentB.head), acc);
    currentA = currentA.tail;
    currentB = currentB.tail;
  }
  return reverse(acc);
}

/**
 * Unzip a list of tuples (stack-safe)
 */
export function unzip<A, B>(list: List<[A, B]>): [List<A>, List<B>] {
  let accA: List<A> = Nil;
  let accB: List<B> = Nil;
  let current: List<[A, B]> = list;
  while (current !== null) {
    accA = Cons(current.head[0], accA);
    accB = Cons(current.head[1], accB);
    current = current.tail;
  }
  return [reverse(accA), reverse(accB)];
}

/**
 * Intersperse a separator between elements (stack-safe)
 */
export function intersperse<A>(list: List<A>, sep: A): List<A> {
  if (list === null) return Nil;
  let acc: List<A> = Cons(list.head, Nil);
  let current: List<A> = list.tail;
  while (current !== null) {
    acc = Cons(current.head, Cons(sep, acc));
    current = current.tail;
  }
  return reverse(acc);
}

// ============================================================================
// Folds
// ============================================================================

/**
 * Fold left
 */
export function foldLeft<A, B>(list: List<A>, init: B, f: (b: B, a: A) => B): B {
  let acc = init;
  let current: List<A> = list;
  while (current !== null) {
    acc = f(acc, current.head);
    current = current.tail;
  }
  return acc;
}

/**
 * Fold right (stack-safe via reverse + foldLeft)
 *
 * Note: This is stack-safe but evaluates strictly (not lazy).
 * For lazy/short-circuiting foldRight, use Eval-based version.
 */
export function foldRight<A, B>(list: List<A>, init: B, f: (a: A, b: B) => B): B {
  return foldLeft(reverse(list), init, (b, a) => f(a, b));
}

/**
 * Reduce with a semigroup (requires non-empty)
 */
export function reduce<A>(list: List<A>, f: (a: A, b: A) => A): Option<A> {
  if (list === null) return None;
  return Some(foldLeft(list.tail, list.head, f));
}

// ============================================================================
// Search
// ============================================================================

/**
 * Find the first element matching a predicate
 */
export function find<A>(list: List<A>, predicate: (a: A) => boolean): Option<A> {
  let current: List<A> = list;
  while (current !== null) {
    if (predicate(current.head)) return Some(current.head);
    current = current.tail;
  }
  return None;
}

/**
 * Find index of first element matching a predicate
 */
export function findIndex<A>(list: List<A>, predicate: (a: A) => boolean): Option<number> {
  let current: List<A> = list;
  let i = 0;
  while (current !== null) {
    if (predicate(current.head)) return Some(i);
    current = current.tail;
    i++;
  }
  return None;
}

/**
 * Check if any element satisfies the predicate
 */
export function exists<A>(list: List<A>, predicate: (a: A) => boolean): boolean {
  return isSome(find(list, predicate));
}

/**
 * Check if all elements satisfy the predicate
 */
export function forall<A>(list: List<A>, predicate: (a: A) => boolean): boolean {
  let current: List<A> = list;
  while (current !== null) {
    if (!predicate(current.head)) return false;
    current = current.tail;
  }
  return true;
}

/**
 * Check if list contains an element
 */
export function contains<A>(
  list: List<A>,
  a: A,
  eq: (x: A, y: A) => boolean = (x, y) => x === y
): boolean {
  return exists(list, (x) => eq(x, a));
}

/**
 * Count elements satisfying a predicate
 */
export function count<A>(list: List<A>, predicate: (a: A) => boolean): number {
  return foldLeft(list, 0, (acc, a) => (predicate(a) ? acc + 1 : acc));
}

// ============================================================================
// Conversion
// ============================================================================

/**
 * Convert list to array
 */
export function toArray<A>(list: List<A>): A[] {
  const result: A[] = [];
  let current: List<A> = list;
  while (current !== null) {
    result.push(current.head);
    current = current.tail;
  }
  return result;
}

/**
 * Join elements with a separator
 */
export function mkString(list: List<string>, sep: string = ""): string {
  return toArray(list).join(sep);
}

/**
 * Show elements with a separator
 */
export function mkStringShow<A>(list: List<A>, show: (a: A) => string, sep: string = ""): string {
  return toArray(list).map(show).join(sep);
}

// ============================================================================
// Traverse
// ============================================================================

/**
 * Traverse the list with an Option-returning function (stack-safe).
 *
 * Returns the mapped list, or `undefined` if any `f` returned `None`.
 * Not `Option<List<B>>`: both `Nil` and `None` are `null` at runtime, so a
 * successful traverse of the empty list would read as failure.
 */
export function traverse<A, B>(list: List<A>, f: (a: A) => Option<B>): List<B> | undefined {
  let acc: List<B> = Nil;
  let current: List<A> = list;
  while (current !== null) {
    const result = f(current.head);
    if (!isSome(result)) return undefined;
    acc = Cons(result as B, acc);
    current = current.tail;
  }
  return reverse(acc);
}

/**
 * Sequence a list of Options (`undefined` if any is `None`; see `traverse`)
 */
export function sequence<A>(list: List<Option<A>>): List<A> | undefined {
  return traverse(list, (opt) => opt);
}

// ============================================================================
// Typeclass Instances
// ============================================================================

/**
 * Eq instance for List
 */
export function getEq<A>(E: Eq<A>): Eq<List<A>> {
  const eq: Eq<List<A>> = {
    equals: (x, y) => {
      let currentX: List<A> = x;
      let currentY: List<A> = y;
      while (currentX !== null && currentY !== null) {
        if (!E.equals(currentX.head, currentY.head)) return false;
        currentX = currentX.tail;
        currentY = currentY.tail;
      }
      return currentX === null && currentY === null;
    },
    notEquals: (x, y) => !eq.equals(x, y),
  };
  return eq;
}

/**
 * Ord instance for List (lexicographic).
 * Includes comparison methods for operator rewriting via @op JSDoc tags.
 */
export function getOrd<A>(O: Ord<A>): Ord<List<A>> {
  const compare = (x: List<A>, y: List<A>): Ordering => {
    let currentX: List<A> = x;
    let currentY: List<A> = y;
    while (currentX !== null && currentY !== null) {
      const cmp = O.compare(currentX.head, currentY.head);
      if (cmp !== 0) return cmp;
      currentX = currentX.tail;
      currentY = currentY.tail;
    }
    if (currentX === null && currentY === null) return 0 as Ordering;
    return currentX === null ? (-1 as Ordering) : (1 as Ordering);
  };
  return {
    ...getEq(O),
    compare,
    lessThan: (x, y) => compare(x, y) === -1,
    lessThanOrEqual: (x, y) => compare(x, y) !== 1,
    greaterThan: (x, y) => compare(x, y) === 1,
    greaterThanOrEqual: (x, y) => compare(x, y) !== -1,
  };
}

/**
 * Show instance for List
 */
export function getShow<A>(S: Show<A>): Show<List<A>> {
  return {
    show: (list) => `List(${toArray(list).map(S.show).join(", ")})`,
  };
}

/**
 * Semigroup instance for List (concatenation)
 */
export function getSemigroup<A>(): Semigroup<List<A>> {
  return {
    combine: append,
  };
}

/**
 * Monoid instance for List
 */
export function getMonoid<A>(): Monoid<List<A>> {
  return {
    ...getSemigroup<A>(),
    empty: Nil,
  };
}

// ============================================================================
// Do-notation Support
// ============================================================================

/**
 * Start a do-comprehension with List
 */
export const Do: List<{}> = singleton({});

/**
 * Bind a value in do-notation style
 */
export function bind<N extends string, A extends object, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => List<B>
): (list: List<A>) => List<A & { readonly [K in N]: B }> {
  return (list) =>
    flatMap(list, (a) => map(f(a), (b) => ({ ...a, [name]: b }) as A & { readonly [K in N]: B }));
}

/**
 * Let - bind a non-effectful value
 */
export function let_<N extends string, A extends object, B>(
  name: Exclude<N, keyof A>,
  f: (a: A) => B
): (list: List<A>) => List<A & { readonly [K in N]: B }> {
  return (list) => map(list, (a) => ({ ...a, [name]: f(a) }) as A & { readonly [K in N]: B });
}

// ============================================================================
// Utilities
// ============================================================================

/**
 * Perform a side effect for each element
 */
export function forEach<A>(list: List<A>, f: (a: A) => void): void {
  let current: List<A> = list;
  while (current !== null) {
    f(current.head);
    current = current.tail;
  }
}

/**
 * Map with index (stack-safe)
 */
export function mapWithIndex<A, B>(list: List<A>, f: (index: number, a: A) => B): List<B> {
  let acc: List<B> = Nil;
  let current: List<A> = list;
  let i = 0;
  while (current !== null) {
    acc = Cons(f(i, current.head), acc);
    current = current.tail;
    i++;
  }
  return reverse(acc);
}

/**
 * Sort the list
 */
export function sort<A>(list: List<A>, compare: (a: A, b: A) => number): List<A> {
  return fromArray(toArray(list).sort(compare));
}

/**
 * Sort by a key
 */
export function sortBy<A, B>(
  list: List<A>,
  f: (a: A) => B,
  compare: (b1: B, b2: B) => number
): List<A> {
  return sort(list, (a1, a2) => compare(f(a1), f(a2)));
}

/**
 * Group consecutive elements by a key (stack-safe)
 */
export function groupBy<A, K>(
  list: List<A>,
  f: (a: A) => K,
  eq: (k1: K, k2: K) => boolean = (k1, k2) => k1 === k2
): List<List<A>> {
  if (list === null) return Nil;

  let groups: List<List<A>> = Nil;
  let current: List<A> = list;

  while (current !== null) {
    const key = f(current.head);
    let groupAcc: List<A> = Cons(current.head, Nil);
    current = current.tail;

    while (current !== null && eq(f(current.head), key)) {
      groupAcc = Cons(current.head, groupAcc);
      current = current.tail;
    }

    groups = Cons(reverse(groupAcc), groups);
  }

  return reverse(groups);
}

/**
 * Distinct elements (preserves first occurrence)
 */
export function distinct<A>(
  list: List<A>,
  eq: (a: A, b: A) => boolean = (a, b) => a === b
): List<A> {
  const seen: A[] = [];
  return filter(list, (a) => {
    if (seen.some((s) => eq(s, a))) return false;
    seen.push(a);
    return true;
  });
}

/**
 * Partition list into [matching, non-matching]
 */
export function partition<A>(list: List<A>, predicate: (a: A) => boolean): [List<A>, List<A>] {
  const matching: A[] = [];
  const nonMatching: A[] = [];
  forEach(list, (a) => {
    if (predicate(a)) {
      matching.push(a);
    } else {
      nonMatching.push(a);
    }
  });
  return [fromArray(matching), fromArray(nonMatching)];
}

// ============================================================================
// List Namespace Object
// ============================================================================

/**
 * List namespace - groups all List operations for clean API access.
 *
 * @example
 * ```typescript
 * import { List, Cons, Nil } from "@typesugar/fp";
 *
 * const xs = List.of(1, 2, 3);
 * List.map(xs, n => n * 2);      // List(2, 4, 6)
 * List.filter(xs, n => n > 1);   // List(2, 3)
 * List.foldLeft(xs, 0, (a, b) => a + b); // 6
 * ```
 */
export const List = {
  // Constructors
  of,
  fromArray,
  fromIterable,
  singleton,
  replicate,
  range,
  empty,

  // Type guards
  isCons,
  isNil,
  isEmpty,
  nonEmpty,

  // Basic operations
  head,
  tail,
  last,
  init,
  get,
  length,

  // Transformations
  map,
  flatMap,
  filter,
  filterMap,
  reverse,
  prepend,
  append,
  appendOne,
  flatten,
  take,
  drop,
  dropLast,
  takeWhile,
  dropWhile,
  zip,
  zipWith,
  unzip,
  intersperse,

  // Folds
  foldLeft,
  foldRight,
  reduce,

  // Search
  find,
  findIndex,
  exists,
  forall,
  contains,
  count,

  // Conversions
  toArray,
  mkString,
  mkStringShow,

  // Traverse
  traverse,
  sequence,

  // Typeclass instances
  getEq,
  getOrd,
  getShow,
  getSemigroup,
  getMonoid,

  // Do-notation
  Do,
  bind,
  let_,

  // Utilities
  forEach,
  mapWithIndex,
  sort,
  sortBy,
  groupBy,
  distinct,
  partition,
} as const;
