/**
 * Compile-Time Reflection Macros
 *
 * Provides compile-time type introspection capabilities, allowing you to
 * examine types, generate code based on type information, and more.
 *
 * Inspired by:
 * - Rust's proc_macro with derive
 * - Java/C# reflection but at compile time
 * - Zig's @typeInfo
 *
 * @example
 * ```typescript
 * @reflect
 * interface User {
 *   id: number;
 *   name: string;
 *   email: string;
 * }
 *
 * // Get metadata at compile time
 * const userMeta = typeInfo<User>();
 * // { name: "User", fields: [{ name: "id", type: "number" }, ...] }
 *
 * // Generate a validator
 * const validateUser = validator<User>();
 * ```
 */

import * as ts from "typescript";
import { defineExpressionMacro, defineAttributeMacro, globalRegistry } from "@typesugar/core";
import { MacroContext, AttributeTarget, isSyntheticNode } from "@typesugar/core";

const printer = ts.createPrinter({ newLine: ts.NewLineKind.LineFeed });
const dummySource = ts.createSourceFile("__dummy__.ts", "", ts.ScriptTarget.Latest);

/**
 * Safely get the text of a node, handling synthetic nodes that lack source
 * file position information.
 */
function safeGetText(node: ts.Node): string {
  // Printing, not checker calls: the printer gives the same text getText()
  // would (a node outside a parsed file has no text to get), and a node it
  // can't print is not one a declaration's annotation can be.
  if (!isSyntheticNode(node)) {
    try {
      return node.getText();
    } catch {
      // Fall through to printer
    }
  }
  try {
    return printer.printNode(ts.EmitHint.Unspecified, node, dummySource);
  } catch {
    return "unknown";
  }
}

// ============================================================================
// Type Information Structures
// ============================================================================

export interface TypeInfo {
  name: string;
  kind:
    | "interface"
    | "class"
    | "type"
    | "enum"
    | "primitive"
    | "union"
    | "intersection"
    | "array"
    | "tuple"
    | "function";
  fields?: FieldInfo[];
  methods?: MethodInfo[];
  typeParameters?: string[];
  extends?: string[];
  modifiers?: string[];
  variants?: string[];
}

export interface FieldInfo {
  name: string;
  type: string;
  optional: boolean;
  readonly: boolean;
  defaultValue?: string;
}

export interface MethodInfo {
  name: string;
  parameters: ParameterInfo[];
  returnType: string;
  isAsync: boolean;
  isStatic: boolean;
}

export interface ParameterInfo {
  name: string;
  type: string;
  optional: boolean;
  defaultValue?: string;
}

// ============================================================================
// @reflect Attribute Macro
// ============================================================================

export const reflectAttribute = defineAttributeMacro({
  name: "reflect",
  cacheable: false, // depends on the checker's view of the type, not just the call text
  module: "typesugar",
  description: "Enable compile-time reflection for a type",
  validTargets: ["interface", "class", "type"] as AttributeTarget[],

  expand(
    ctx: MacroContext,
    decorator: ts.Decorator,
    target: ts.Declaration,
    _args: readonly ts.Expression[]
  ): ts.Node | ts.Node[] {
    // Extract type information directly from the type checker. What a
    // checker failure left out is said in one warning (CLAUDE.md: a caught
    // checker failure that degrades leaves a visible trace).
    const failures: string[] = [];
    let firstError: unknown;
    const typeInfo = extractTypeInfo(ctx, target, (what, error) => {
      if (failures.length === 0) firstError = error;
      failures.push(what);
    });
    if (failures.length > 0) {
      const name = (target as { name?: ts.Node }).name;
      ctx.reportWarning(
        target,
        `@reflect on '${name && ts.isIdentifier(name) ? name.text : "<anonymous>"}' left out ` +
          `${failures.join(", ")}: the type checker failed (${firstError}).`
      );
    }

    if (typeInfo) {
      // Generate metadata as an exported const alongside the original declaration.
      // INTENTIONALLY UNHYGIENIC: The meta variable name is part of the public reflect API.
      // Users may reference this name directly (e.g., `__User_meta__`).
      const metaName = `__${typeInfo.name}_meta__`;
      const metaDecl = generateTypeInfoDeclaration(ctx, metaName, typeInfo);

      return [target, metaDecl];
    }

    return target;
  },
});

/**
 * Extract type information from a declaration
 */
/**
 * The display type of a field: the checker's type of the property, except
 * that an optional property of a non-generic declaration shows its DECLARED
 * type (`age?: number` is "number", with `optional: true` beside it), not
 * the `number | undefined` the checker gives it under strictNullChecks. Taken
 * from the checker either way (the declared type is `getTypeFromTypeNode` on
 * the annotation), never from the annotation's text. In a generic
 * declaration (`value?: T`) the declared type is the type parameter, so the
 * instantiated type is shown, undefined included.
 */
function fieldTypeString(checker: ts.TypeChecker, prop: ts.Symbol, location: ts.Node): string {
  const decl = prop.getDeclarations()?.[0];
  const optionalAnnotation =
    prop.flags & ts.SymbolFlags.Optional &&
    decl &&
    (ts.isPropertySignature(decl) || ts.isPropertyDeclaration(decl)) &&
    decl.type &&
    !isSyntheticNode(decl)
      ? decl.type
      : undefined;
  if (optionalAnnotation && !insideGenericDeclaration(optionalAnnotation)) {
    return checker.typeToString(checker.getTypeFromTypeNode(optionalAnnotation));
  }
  return optionalTypeString(
    checker,
    checker.getTypeOfSymbolAtLocation(prop, decl ?? location),
    optionalAnnotation
  );
}

/**
 * The type of an optional member (a field, a method's parameter) as the
 * checker has it where it is instantiated (`label?: T` of `Box<number>`:
 * `number | undefined` under strict), without the `undefined` its
 * optionality adds: removed from the union whatever else is in it
 * (`Box<boolean>`'s is `undefined | false | true`, review 9), unless the
 * annotation has an `undefined` of its own (`maybe?: T | undefined`). For a
 * member that isn't optional (`annotation` undefined), the type as the checker
 * prints it. An annotation outside a generic declaration is read directly
 * instead (see {@link fieldTypeString}); this is for one written in terms of
 * type parameters, which `getTypeFromTypeNode` would not instantiate (review
 * 8: `set(v?: T)` reported "T").
 *
 * The rest of the union is printed from the checker's own type node for it
 * (`typeToTypeNode`, its `undefined` member left out), so it reads as
 * `typeToString` would print it (`boolean`, not `false | true`).
 */
function optionalTypeString(
  checker: ts.TypeChecker,
  instantiated: ts.Type,
  annotation: ts.TypeNode | undefined
): string {
  if (annotation && instantiated.isUnion()) {
    const isUndefined = (t: ts.Type) => (t.flags & ts.TypeFlags.Undefined) !== 0;
    const declared = checker.getTypeFromTypeNode(annotation);
    const declaresUndefined =
      isUndefined(declared) || (declared.isUnion() && declared.types.some(isUndefined));
    const rest = instantiated.types.filter((t) => !isUndefined(t));
    if (!declaresUndefined && rest.length === 1) return checker.typeToString(rest[0]);
    if (!declaresUndefined && rest.length > 1) {
      const node = checker.typeToTypeNode(instantiated, undefined, TYPE_STRING_FLAGS);
      if (node && ts.isUnionTypeNode(node)) {
        const kept = node.types.filter((t) => t.kind !== ts.SyntaxKind.UndefinedKeyword);
        if (kept.length > 0 && kept.length < node.types.length) {
          const printed = kept.length === 1 ? kept[0] : ts.factory.createUnionTypeNode(kept);
          return typePrinter.printNode(ts.EmitHint.Unspecified, printed, printFile);
        }
      }
    }
  }
  return checker.typeToString(instantiated);
}

/** The node builder flags `typeToString` uses by default (it prints on one line, untruncated here). */
const TYPE_STRING_FLAGS =
  ts.NodeBuilderFlags.IgnoreErrors |
  ts.NodeBuilderFlags.AllowUniqueESSymbolType |
  ts.NodeBuilderFlags.UseAliasDefinedOutsideCurrentScope;
const typePrinter = ts.createPrinter({ removeComments: true });
const printFile = ts.createSourceFile("__reflect_type__.ts", "", ts.ScriptTarget.Latest);

/** Is `node` inside a declaration with type parameters (an interface, class, type alias, ...)? */
function insideGenericDeclaration(node: ts.Node): boolean {
  for (let n: ts.Node | undefined = node.parent; n && !ts.isSourceFile(n); n = n.parent) {
    const tps = (n as { typeParameters?: ts.NodeArray<ts.TypeParameterDeclaration> })
      .typeParameters;
    if (tps && tps.length > 0) return true;
  }
  return false;
}

/** Told what a checker failure left out of a `@reflect` type's metadata (`what`). */
type ReflectFailure = (what: string, error: unknown) => void;

function extractTypeInfo(
  ctx: MacroContext,
  node: ts.Declaration,
  onFailure: ReflectFailure
): TypeInfo | null {
  if (ts.isInterfaceDeclaration(node)) {
    return extractInterfaceInfo(ctx, node, onFailure);
  }

  if (ts.isClassDeclaration(node)) {
    return extractClassInfo(ctx, node, onFailure);
  }

  if (ts.isTypeAliasDeclaration(node)) {
    return extractTypeAliasInfo(ctx, node, onFailure);
  }

  return null;
}

function extractInterfaceInfo(
  ctx: MacroContext,
  node: ts.InterfaceDeclaration,
  onFailure: ReflectFailure
): TypeInfo {
  let type: ts.Type;
  let properties: ts.Symbol[];
  try {
    type = ctx.typeChecker.getTypeAtLocation(node);
    properties = ctx.typeChecker.getPropertiesOfType(type);
  } catch (error) {
    onFailure("every field", error);
    return {
      name: node.name.text,
      kind: "interface",
      fields: [],
      typeParameters: [],
      extends: [],
    };
  }

  const fields: FieldInfo[] = properties.map((prop) => {
    const decls = prop.getDeclarations();
    const decl = decls?.[0];
    let propTypeStr = "unknown";
    try {
      propTypeStr = fieldTypeString(ctx.typeChecker, prop, node);
    } catch (error) {
      onFailure(`the type of '${prop.name}' (shown as "unknown")`, error);
    }

    return {
      name: prop.name,
      type: propTypeStr,
      optional: (prop.flags & ts.SymbolFlags.Optional) !== 0,
      readonly:
        decl && (ts.isPropertySignature(decl) || ts.isPropertyDeclaration(decl))
          ? (decl.modifiers?.some((m) => m.kind === ts.SyntaxKind.ReadonlyKeyword) ?? false)
          : false,
    };
  });

  const typeParameters = node.typeParameters?.map((tp) => tp.name.text) ?? [];
  const extendsTypes =
    node.heritageClauses
      ?.filter((hc) => hc.token === ts.SyntaxKind.ExtendsKeyword)
      .flatMap((hc) =>
        hc.types.map((t) =>
          ts.isIdentifier(t.expression) ? t.expression.text : safeGetText(t.expression)
        )
      ) ?? [];

  return {
    name: node.name.text,
    kind: "interface",
    fields,
    typeParameters,
    extends: extendsTypes,
  };
}

function extractClassInfo(
  ctx: MacroContext,
  node: ts.ClassDeclaration,
  onFailure: ReflectFailure
): TypeInfo {
  let type: ts.Type;
  let properties: ts.Symbol[];
  try {
    type = ctx.typeChecker.getTypeAtLocation(node);
    properties = ctx.typeChecker.getPropertiesOfType(type);
  } catch (error) {
    onFailure("every field and method", error);
    return {
      name: node.name?.text ?? "Anonymous",
      kind: "class",
      fields: [],
      methods: [],
      typeParameters: [],
    };
  }

  const fields: FieldInfo[] = [];
  const methods: MethodInfo[] = [];

  for (const prop of properties) {
    const decls = prop.getDeclarations();
    const decl = decls?.[0];
    let typeStr = "unknown";
    // A method's metadata is read from its declaration, not this type.
    const isMethodDecl = decl !== undefined && ts.isMethodDeclaration(decl);
    try {
      typeStr = fieldTypeString(ctx.typeChecker, prop, node);
    } catch (error) {
      if (!isMethodDecl) onFailure(`the type of '${prop.name}' (shown as "unknown")`, error);
    }

    // Check if it's a method
    if (decl && ts.isMethodDeclaration(decl)) {
      const params: ParameterInfo[] = decl.parameters.map((p) => ({
        name: ts.isIdentifier(p.name) ? p.name.text : "param",
        type: p.type ? safeGetText(p.type) : "unknown",
        optional: !!p.questionToken,
        defaultValue: p.initializer ? safeGetText(p.initializer) : undefined,
      }));

      methods.push({
        name: prop.name,
        parameters: params,
        returnType: decl.type ? safeGetText(decl.type) : "void",
        isAsync: !!decl.modifiers?.some((m) => m.kind === ts.SyntaxKind.AsyncKeyword),
        isStatic: !!decl.modifiers?.some((m) => m.kind === ts.SyntaxKind.StaticKeyword),
      });
    } else {
      fields.push({
        name: prop.name,
        type: typeStr,
        optional: (prop.flags & ts.SymbolFlags.Optional) !== 0,
        readonly:
          decl && ts.isPropertyDeclaration(decl)
            ? (decl.modifiers?.some((m) => m.kind === ts.SyntaxKind.ReadonlyKeyword) ?? false)
            : false,
      });
    }
  }

  const typeParameters = node.typeParameters?.map((tp) => tp.name.text) ?? [];

  return {
    name: node.name?.text ?? "Anonymous",
    kind: "class",
    fields,
    methods,
    typeParameters,
  };
}

function extractTypeAliasInfo(
  ctx: MacroContext,
  node: ts.TypeAliasDeclaration,
  onFailure: ReflectFailure
): TypeInfo {
  let type: ts.Type;
  let typeString: string;
  try {
    type = ctx.typeChecker.getTypeAtLocation(node);
    typeString = ctx.typeChecker.typeToString(type);
  } catch (error) {
    onFailure("every field", error);
    return {
      name: node.name.text,
      kind: "type",
      fields: [],
      typeParameters: node.typeParameters?.map((tp) => tp.name.text) ?? [],
    };
  }

  // For object types, extract fields
  if (type.isClassOrInterface() || type.flags & ts.TypeFlags.Object) {
    let properties: ts.Symbol[];
    try {
      properties = ctx.typeChecker.getPropertiesOfType(type);
    } catch (error) {
      onFailure("every field", error);
      properties = [];
    }
    const fields: FieldInfo[] = properties.map((prop) => {
      let propTypeStr = "unknown";
      try {
        propTypeStr = fieldTypeString(ctx.typeChecker, prop, node);
      } catch (error) {
        onFailure(`the type of '${prop.name}' (shown as "unknown")`, error);
      }
      return {
        name: prop.name,
        type: propTypeStr,
        optional: (prop.flags & ts.SymbolFlags.Optional) !== 0,
        readonly: false,
      };
    });

    return {
      name: node.name.text,
      kind: "type",
      fields,
      typeParameters: node.typeParameters?.map((tp) => tp.name.text) ?? [],
    };
  }

  // Union type
  if (type.isUnion()) {
    const variants = (type as ts.UnionType).types.map((t) => ctx.typeChecker.typeToString(t));
    return {
      name: node.name.text,
      kind: "union",
      variants,
      typeParameters: node.typeParameters?.map((tp) => tp.name.text) ?? [],
    };
  }

  // Intersection type
  if (type.isIntersection()) {
    return {
      name: node.name.text,
      kind: "intersection",
      typeParameters: node.typeParameters?.map((tp) => tp.name.text) ?? [],
    };
  }

  return {
    name: node.name.text,
    kind: "type",
  };
}

/**
 * Generate a TypeInfo declaration
 */
function generateTypeInfoDeclaration(
  ctx: MacroContext,
  name: string,
  info: TypeInfo
): ts.Statement {
  const factory = ctx.factory;

  const fieldsArray =
    info.fields?.map((f) =>
      factory.createObjectLiteralExpression(
        [
          factory.createPropertyAssignment("name", factory.createStringLiteral(f.name)),
          factory.createPropertyAssignment("type", factory.createStringLiteral(f.type)),
          factory.createPropertyAssignment(
            "optional",
            f.optional ? factory.createTrue() : factory.createFalse()
          ),
          factory.createPropertyAssignment(
            "readonly",
            f.readonly ? factory.createTrue() : factory.createFalse()
          ),
        ],
        true
      )
    ) ?? [];

  const methodsArray =
    info.methods?.map((m) =>
      factory.createObjectLiteralExpression(
        [
          factory.createPropertyAssignment("name", factory.createStringLiteral(m.name)),
          factory.createPropertyAssignment("returnType", factory.createStringLiteral(m.returnType)),
          factory.createPropertyAssignment(
            "isAsync",
            m.isAsync ? factory.createTrue() : factory.createFalse()
          ),
          factory.createPropertyAssignment(
            "isStatic",
            m.isStatic ? factory.createTrue() : factory.createFalse()
          ),
          factory.createPropertyAssignment(
            "parameters",
            factory.createArrayLiteralExpression(
              m.parameters.map((p) =>
                factory.createObjectLiteralExpression(
                  [
                    factory.createPropertyAssignment("name", factory.createStringLiteral(p.name)),
                    factory.createPropertyAssignment("type", factory.createStringLiteral(p.type)),
                    factory.createPropertyAssignment(
                      "optional",
                      p.optional ? factory.createTrue() : factory.createFalse()
                    ),
                  ],
                  true
                )
              )
            )
          ),
        ],
        true
      )
    ) ?? [];

  const infoObj = factory.createObjectLiteralExpression(
    [
      factory.createPropertyAssignment("name", factory.createStringLiteral(info.name)),
      factory.createPropertyAssignment("kind", factory.createStringLiteral(info.kind)),
      factory.createPropertyAssignment(
        "fields",
        factory.createArrayLiteralExpression(fieldsArray, true)
      ),
      factory.createPropertyAssignment(
        "methods",
        factory.createArrayLiteralExpression(methodsArray, true)
      ),
      factory.createPropertyAssignment(
        "typeParameters",
        factory.createArrayLiteralExpression(
          (info.typeParameters ?? []).map((tp) => factory.createStringLiteral(tp))
        )
      ),
    ],
    true
  );

  return factory.createVariableStatement(
    [factory.createModifier(ts.SyntaxKind.ExportKeyword)],
    factory.createVariableDeclarationList(
      [factory.createVariableDeclaration(name, undefined, undefined, infoObj)],
      ts.NodeFlags.Const
    )
  );
}

// ============================================================================
// typeInfo<T>() Expression Macro
// ============================================================================

export const typeInfoMacro = defineExpressionMacro({
  name: "typeInfo",
  cacheable: false, // depends on the checker's view of the type, not just the call text
  module: "typesugar",
  description: "Get compile-time type information",

  expand(
    ctx: MacroContext,
    callExpr: ts.CallExpression,
    _args: readonly ts.Expression[]
  ): ts.Expression {
    const factory = ctx.factory;

    // Get the type argument
    const typeArgs = callExpr.typeArguments;
    if (!typeArgs || typeArgs.length !== 1) {
      ctx.reportError(callExpr, "typeInfo requires exactly one type argument");
      return callExpr;
    }

    const typeArg = typeArgs[0];
    const type = ctx.typeChecker.getTypeFromTypeNode(typeArg);
    const typeName = ctx.typeChecker.typeToString(type);

    // Always extract type info directly from the type checker.
    // This avoids cross-file mutable state and works reliably
    // regardless of file processing order or incremental builds.
    const properties = ctx.typeChecker.getPropertiesOfType(type);

    // Determine the kind
    let kind = "type";
    const symbol = type.getSymbol();
    if (symbol) {
      const decls = symbol.getDeclarations();
      if (decls && decls.length > 0) {
        const decl = decls[0];
        if (ts.isInterfaceDeclaration(decl)) kind = "interface";
        else if (ts.isClassDeclaration(decl)) kind = "class";
        else if (ts.isEnumDeclaration(decl)) kind = "enum";
      }
    }

    // A method (a class's method declaration, an interface's method
    // signature) is reported in `methods`, with the signature the checker
    // gives it, not as a field — as the `@reflect` class metadata does. A
    // function-valued property (`onDone: () => void`) stays a field.
    const isMethod = isMethodSymbol;
    const unreadable: string[] = [];
    const methodsArray = properties.filter(isMethod).flatMap((prop) => {
      const info = methodInfoFromChecker(ctx.typeChecker, prop, callExpr, unreadable);
      return info ? [methodInfoLiteral(factory, info)] : [];
    });
    // CLAUDE.md: a caught checker failure that degrades leaves a visible
    // trace — one line per expansion, naming every method left out.
    if (unreadable.length > 0) {
      ctx.reportWarning(
        callExpr,
        `typeInfo<${typeName}>() left out ${unreadable.length === 1 ? "method" : "methods"} ` +
          `${unreadable.map((n) => `'${n}'`).join(", ")}: the type checker failed on ` +
          `${unreadable.length === 1 ? "its signature" : "their signatures"}.`
      );
    }

    const fieldsArray = properties
      .filter((prop) => !isMethod(prop))
      .map((prop) => {
        const decls = prop.getDeclarations();
        const decl = decls?.[0];
        const isReadonly =
          decl && (ts.isPropertySignature(decl) || ts.isPropertyDeclaration(decl))
            ? (decl.modifiers?.some((m) => m.kind === ts.SyntaxKind.ReadonlyKeyword) ?? false)
            : false;

        return factory.createObjectLiteralExpression(
          [
            factory.createPropertyAssignment("name", factory.createStringLiteral(prop.name)),
            factory.createPropertyAssignment(
              "type",
              factory.createStringLiteral(fieldTypeString(ctx.typeChecker, prop, callExpr))
            ),
            factory.createPropertyAssignment(
              "optional",
              (prop.flags & ts.SymbolFlags.Optional) !== 0
                ? factory.createTrue()
                : factory.createFalse()
            ),
            factory.createPropertyAssignment(
              "readonly",
              isReadonly ? factory.createTrue() : factory.createFalse()
            ),
          ],
          true
        );
      });

    return factory.createObjectLiteralExpression(
      [
        factory.createPropertyAssignment("name", factory.createStringLiteral(typeName)),
        factory.createPropertyAssignment("kind", factory.createStringLiteral(kind)),
        factory.createPropertyAssignment(
          "fields",
          factory.createArrayLiteralExpression(fieldsArray, true)
        ),
        factory.createPropertyAssignment(
          "methods",
          factory.createArrayLiteralExpression(methodsArray, true)
        ),
      ],
      true
    );
  },
});

/**
 * A method's `MethodInfo` from the checker: its (first) call signature as
 * seen from `location` — parameter and return types as the checker prints
 * them, a parameter optional when the checker says so (`?` or a default).
 * Undefined when the checker can't give a signature (reported as nothing,
 * as `fieldTypeString` reports "unknown").
 */
function methodInfoFromChecker(
  checker: ts.TypeChecker,
  prop: ts.Symbol,
  location: ts.Node,
  /** Collects the name of a method the checker failed on (the caller warns). */
  failed: string[]
): MethodInfo | undefined {
  try {
    const signature = checker
      .getTypeOfSymbolAtLocation(prop, location)
      .getNonNullableType()
      .getCallSignatures()[0];
    if (!signature) return undefined;
    const decl = (prop.getDeclarations() ?? []).find(
      (d): d is ts.MethodDeclaration | ts.MethodSignature =>
        ts.isMethodDeclaration(d) || ts.isMethodSignature(d)
    );
    return {
      name: prop.name,
      parameters: signature.getParameters().map((param) => {
        const paramDecl = param.valueDeclaration;
        const optional =
          !!paramDecl && ts.isParameter(paramDecl) && checker.isOptionalParameter(paramDecl);
        // Like a field's (`fieldTypeString`): an optional parameter shows its
        // declared type (`retries?: number` is "number", optional beside it),
        // through the checker, not the annotation's text; one written in a
        // generic declaration is read from the instantiated signature
        // (`set(v?: T)` of `Box<number>` is "number", not "T" — review 8).
        const annotation =
          optional && paramDecl && ts.isParameter(paramDecl) && !isSyntheticNode(paramDecl)
            ? paramDecl.type
            : undefined;
        const type =
          annotation && !insideGenericDeclaration(annotation)
            ? checker.typeToString(checker.getTypeFromTypeNode(annotation))
            : optionalTypeString(
                checker,
                checker.getTypeOfSymbolAtLocation(param, location),
                annotation
              );
        return { name: param.name, type, optional };
      }),
      returnType: checker.typeToString(signature.getReturnType()),
      isAsync: !!decl?.modifiers?.some((m) => m.kind === ts.SyntaxKind.AsyncKeyword),
      isStatic: false, // a property of the instance type
    };
  } catch {
    failed.push(prop.name);
    return undefined;
  }
}

/**
 * Is `prop` a method — a class's method declaration or an interface's method
 * signature — rather than a field? (A function-valued property, `onDone: ()
 * => void`, is a field.) Shared by `typeInfo<T>()` (its `methods` vs
 * `fields`) and `fieldNames<T>()`, so the two list the same fields.
 */
function isMethodSymbol(prop: ts.Symbol): boolean {
  return (prop.getDeclarations() ?? []).some(
    (d) => ts.isMethodDeclaration(d) || ts.isMethodSignature(d)
  );
}

/** The object literal `typeInfo<T>()` emits for one method. */
function methodInfoLiteral(factory: ts.NodeFactory, m: MethodInfo): ts.ObjectLiteralExpression {
  return factory.createObjectLiteralExpression(
    [
      factory.createPropertyAssignment("name", factory.createStringLiteral(m.name)),
      factory.createPropertyAssignment(
        "parameters",
        factory.createArrayLiteralExpression(
          m.parameters.map((p) =>
            factory.createObjectLiteralExpression(
              [
                factory.createPropertyAssignment("name", factory.createStringLiteral(p.name)),
                factory.createPropertyAssignment("type", factory.createStringLiteral(p.type)),
                factory.createPropertyAssignment(
                  "optional",
                  p.optional ? factory.createTrue() : factory.createFalse()
                ),
              ],
              false
            )
          ),
          true
        )
      ),
      factory.createPropertyAssignment("returnType", factory.createStringLiteral(m.returnType)),
      factory.createPropertyAssignment(
        "isAsync",
        m.isAsync ? factory.createTrue() : factory.createFalse()
      ),
      factory.createPropertyAssignment(
        "isStatic",
        m.isStatic ? factory.createTrue() : factory.createFalse()
      ),
    ],
    true
  );
}

// ============================================================================
// fieldNames<T>() - Get field names as a tuple type
// ============================================================================

export const fieldNamesMacro = defineExpressionMacro({
  name: "fieldNames",
  cacheable: false, // depends on the checker's view of the type, not just the call text
  module: "typesugar",
  description: "Get field names of a type as an array",

  expand(
    ctx: MacroContext,
    callExpr: ts.CallExpression,
    _args: readonly ts.Expression[]
  ): ts.Expression {
    const factory = ctx.factory;
    const typeArgs = callExpr.typeArguments;

    if (!typeArgs || typeArgs.length !== 1) {
      ctx.reportError(callExpr, "fieldNames requires exactly one type argument");
      return callExpr;
    }

    const type = ctx.typeChecker.getTypeFromTypeNode(typeArgs[0]);
    // The fields `typeInfo<T>().fields` lists: methods are left out (review
    // 8: `fieldNames<Box<number>>()` listed `set` and `get` too).
    const properties = ctx.typeChecker
      .getPropertiesOfType(type)
      .filter((prop) => !isMethodSymbol(prop));

    return factory.createArrayLiteralExpression(
      properties.map((prop) => factory.createStringLiteral(prop.name))
    );
  },
});

/** True when `name` can be written as `value.name` (public scanner API only). */
function isIdentifierName(name: string): boolean {
  if (name.length === 0) return false;
  let i = 0;
  for (const ch of name) {
    const cp = ch.codePointAt(0)!;
    const ok =
      i === 0
        ? ts.isIdentifierStart(cp, ts.ScriptTarget.ESNext)
        : ts.isIdentifierPart(cp, ts.ScriptTarget.ESNext);
    if (!ok) return false;
    i++;
  }
  return true;
}

// ============================================================================
// validator<T>() - Generate a runtime validator
// ============================================================================

export const validatorMacro = defineExpressionMacro({
  name: "validator",
  cacheable: false, // depends on the checker's view of the type, not just the call text
  module: "typesugar",
  description: "Generate a runtime validator for a type",

  expand(
    ctx: MacroContext,
    callExpr: ts.CallExpression,
    _args: readonly ts.Expression[]
  ): ts.Expression {
    const factory = ctx.factory;
    const typeArgs = callExpr.typeArguments;

    if (!typeArgs || typeArgs.length !== 1) {
      ctx.reportError(callExpr, "validator requires exactly one type argument");
      return callExpr;
    }

    const checker = ctx.typeChecker;
    const type = checker.getTypeFromTypeNode(typeArgs[0]);

    // A primitive or literal T (`string | number`, `"a" | "b"`, `boolean |
    // undefined`) is checked as a whole, below. The object path would demand
    // `typeof value === "object"` and then check T's apparent members
    // (toString, valueOf, ...), so it rejected every value T allows.
    const PRIMITIVE_FLAGS =
      ts.TypeFlags.StringLike |
      ts.TypeFlags.NumberLike |
      ts.TypeFlags.BooleanLike |
      ts.TypeFlags.BigIntLike |
      ts.TypeFlags.ESSymbolLike |
      ts.TypeFlags.EnumLike |
      ts.TypeFlags.Null |
      ts.TypeFlags.Undefined |
      ts.TypeFlags.Void;
    const topIsPrimitive = (type.isUnion() ? type.types : [type]).every(
      (m) => (m.flags & PRIMITIVE_FLAGS) !== 0
    );
    const properties = topIsPrimitive ? [] : checker.getPropertiesOfType(type);

    const valueId = () => factory.createIdentifier("value");
    const or = (l: ts.Expression, r: ts.Expression) =>
      factory.createBinaryExpression(l, factory.createToken(ts.SyntaxKind.BarBarToken), r);
    const and = (l: ts.Expression, r: ts.Expression) =>
      factory.createBinaryExpression(
        l,
        factory.createToken(ts.SyntaxKind.AmpersandAmpersandToken),
        r
      );
    const notStrictEq = (l: ts.Expression, r: ts.Expression) =>
      factory.createBinaryExpression(
        l,
        factory.createToken(ts.SyntaxKind.ExclamationEqualsEqualsToken),
        r
      );
    const strictEq = (l: ts.Expression, r: ts.Expression) =>
      factory.createBinaryExpression(
        l,
        factory.createToken(ts.SyntaxKind.EqualsEqualsEqualsToken),
        r
      );
    const typeofNot = (e: ts.Expression, t: string) =>
      notStrictEq(factory.createTypeOfExpression(e), factory.createStringLiteral(t));
    const notObject = (e: () => ts.Expression) =>
      factory.createParenthesizedExpression(
        or(typeofNot(e(), "object"), strictEq(e(), factory.createNull()))
      );
    const notArray = (e: ts.Expression) =>
      factory.createPrefixUnaryExpression(
        ts.SyntaxKind.ExclamationToken,
        factory.createCallExpression(
          factory.createPropertyAccessExpression(factory.createIdentifier("Array"), "isArray"),
          undefined,
          [e]
        )
      );

    /** Expression evaluating to the literal value of a literal type. */
    const literalExpr = (t: ts.Type): ts.Expression | undefined => {
      if (t.isStringLiteral()) return factory.createStringLiteral(t.value);
      if (t.isNumberLiteral()) {
        return t.value < 0 || Object.is(t.value, -0)
          ? factory.createPrefixUnaryExpression(
              ts.SyntaxKind.MinusToken,
              factory.createNumericLiteral(Math.abs(t.value))
            )
          : factory.createNumericLiteral(t.value);
      }
      if (t.flags & ts.TypeFlags.BigIntLiteral) {
        const v = (t as ts.BigIntLiteralType).value;
        const lit = factory.createBigIntLiteral(`${v.base10Value}n`);
        return v.negative
          ? factory.createPrefixUnaryExpression(ts.SyntaxKind.MinusToken, lit)
          : lit;
      }
      if (t.flags & ts.TypeFlags.BooleanLiteral) {
        return checker.typeToString(t) === "true" ? factory.createTrue() : factory.createFalse();
      }
      return undefined;
    };

    /**
     * Build an expression that is TRUE when `access()` does NOT match `t`.
     * Returns "any" when every value matches, or undefined when the type
     * cannot be checked at runtime (the caller reports that, rather than
     * silently skipping the field).
     */
    const failCheck = (
      t: ts.Type,
      access: () => ts.Expression
    ): ts.Expression | "any" | undefined => {
      const f = t.flags;
      if (f & (ts.TypeFlags.Any | ts.TypeFlags.Unknown)) return "any";
      if (f & ts.TypeFlags.Boolean && !t.isUnion()) return typeofNot(access(), "boolean");
      if (f & ts.TypeFlags.Null) return notStrictEq(access(), factory.createNull());
      if (f & (ts.TypeFlags.Undefined | ts.TypeFlags.Void)) {
        return notStrictEq(access(), factory.createIdentifier("undefined"));
      }
      const lit = literalExpr(t);
      if (lit) return notStrictEq(access(), lit);
      if (t.isUnion()) {
        // `boolean` (true | false), enums and literal unions all land here.
        // A value is invalid only if it fails EVERY member.
        const parts: ts.Expression[] = [];
        for (const member of t.types) {
          const c = failCheck(member, access);
          if (c === "any") return "any";
          if (c === undefined) return undefined;
          parts.push(c);
        }
        return factory.createParenthesizedExpression(parts.reduce(and));
      }
      if (f & ts.TypeFlags.StringLike) return typeofNot(access(), "string");
      if (f & ts.TypeFlags.NumberLike) return typeofNot(access(), "number");
      if (f & ts.TypeFlags.BigIntLike) return typeofNot(access(), "bigint");
      if (f & ts.TypeFlags.ESSymbolLike) return typeofNot(access(), "symbol");
      if (f & ts.TypeFlags.NonPrimitive) {
        // `object`: any non-null object or function
        return and(notObject(access), typeofNot(access(), "function"));
      }
      if (checker.isArrayType(t) || checker.isTupleType(t)) return notArray(access());
      if (t.isIntersection() && t.types.every((m) => (m.flags & ts.TypeFlags.Object) !== 0)) {
        return notObject(access);
      }
      if (f & ts.TypeFlags.Object) {
        if (t.getCallSignatures().length > 0 || t.getConstructSignatures().length > 0) {
          return typeofNot(access(), "function");
        }
        return notObject(access);
      }
      // Type parameters, intersections, conditional/indexed types, never, ...
      return undefined;
    };

    // Generate validation checks for each property
    const checks: ts.Statement[] = [];

    for (const prop of properties) {
      if (prop.name.startsWith("__@") || prop.name.startsWith("#")) {
        ctx.reportWarning(
          callExpr,
          `validator: property '${prop.name}' is symbol-keyed or private and is not validated`
        );
        continue;
      }
      const propType = checker.getTypeOfSymbolAtLocation(prop, callExpr);
      const isOptional = (prop.flags & ts.SymbolFlags.Optional) !== 0;

      // (value as Record<string, unknown>).name, or [...]["first-name"] when the
      // key is not an identifier. `value` is narrowed only to `object` at this
      // point, so a bare `value.name` fails strictOutput (TS2339/TS7053).
      const asRecord = () =>
        factory.createParenthesizedExpression(
          factory.createAsExpression(
            valueId(),
            factory.createTypeReferenceNode("Record", [
              factory.createKeywordTypeNode(ts.SyntaxKind.StringKeyword),
              factory.createKeywordTypeNode(ts.SyntaxKind.UnknownKeyword),
            ])
          )
        );
      const fieldAccess = () =>
        isIdentifierName(prop.name)
          ? factory.createPropertyAccessExpression(asRecord(), prop.name)
          : factory.createElementAccessExpression(
              asRecord(),
              factory.createStringLiteral(prop.name)
            );

      let checkExpr: ts.Expression | "any" | undefined =
        prop.flags & ts.SymbolFlags.Method
          ? typeofNot(fieldAccess(), "function")
          : failCheck(propType, fieldAccess);

      if (checkExpr === undefined) {
        ctx.reportWarning(
          callExpr,
          `validator: field '${prop.name}' has type '${checker.typeToString(propType)}', ` +
            `which cannot be checked at runtime; it is not validated`
        );
        continue;
      }
      if (checkExpr === "any") continue;

      // An optional property may be absent even when its type (without
      // strictNullChecks) does not include undefined.
      if (isOptional) {
        checkExpr = and(
          notStrictEq(fieldAccess(), factory.createIdentifier("undefined")),
          checkExpr
        );
      }

      const expectedStr = checker.typeToString(propType);
      checks.push(
        factory.createIfStatement(
          checkExpr,
          factory.createBlock([
            factory.createExpressionStatement(
              factory.createCallExpression(
                factory.createPropertyAccessExpression(factory.createIdentifier("errors"), "push"),
                undefined,
                [
                  factory.createStringLiteral(
                    `Invalid type for field '${prop.name}': expected ${expectedStr}`
                  ),
                ]
              )
            ),
          ])
        )
      );
    }

    // { success: true; value: T } | { success: false; errors: string[] }
    // (inlined: the ValidationResult name is not necessarily in scope at the call site)
    const resultType = factory.createUnionTypeNode([
      factory.createTypeLiteralNode([
        factory.createPropertySignature(
          undefined,
          "success",
          undefined,
          factory.createLiteralTypeNode(factory.createTrue())
        ),
        factory.createPropertySignature(undefined, "value", undefined, typeArgs[0]),
      ]),
      factory.createTypeLiteralNode([
        factory.createPropertySignature(
          undefined,
          "success",
          undefined,
          factory.createLiteralTypeNode(factory.createFalse())
        ),
        factory.createPropertySignature(
          undefined,
          "errors",
          undefined,
          factory.createArrayTypeNode(factory.createKeywordTypeNode(ts.SyntaxKind.StringKeyword))
        ),
      ]),
    ]);

    // "Expected <what>, got " + (value === null ? "null" : typeof value)
    const expectedGot = (what: string) =>
      factory.createBinaryExpression(
        factory.createStringLiteral(`Expected ${what}, got `),
        factory.createToken(ts.SyntaxKind.PlusToken),
        factory.createParenthesizedExpression(
          factory.createConditionalExpression(
            strictEq(valueId(), factory.createNull()),
            factory.createToken(ts.SyntaxKind.QuestionToken),
            factory.createStringLiteral("null"),
            factory.createToken(ts.SyntaxKind.ColonToken),
            factory.createTypeOfExpression(valueId())
          )
        )
      );

    // Primitive / literal T: one check of the whole value.
    const primitiveFail = topIsPrimitive ? failCheck(type, valueId) : undefined;
    const primitiveChecks: ts.Statement[] =
      primitiveFail && primitiveFail !== "any"
        ? [
            factory.createIfStatement(
              primitiveFail,
              factory.createBlock([
                factory.createExpressionStatement(
                  factory.createCallExpression(
                    factory.createPropertyAccessExpression(
                      factory.createIdentifier("errors"),
                      "push"
                    ),
                    undefined,
                    [expectedGot(checker.typeToString(type))]
                  )
                ),
              ])
            ),
          ]
        : [];

    // Object T: if (typeof value !== "object" || value === null) return failure
    const objectGuard = factory.createIfStatement(
      factory.createBinaryExpression(
        factory.createBinaryExpression(
          factory.createTypeOfExpression(factory.createIdentifier("value")),
          factory.createToken(ts.SyntaxKind.ExclamationEqualsEqualsToken),
          factory.createStringLiteral("object")
        ),
        factory.createToken(ts.SyntaxKind.BarBarToken),
        factory.createBinaryExpression(
          factory.createIdentifier("value"),
          factory.createToken(ts.SyntaxKind.EqualsEqualsEqualsToken),
          factory.createNull()
        )
      ),
      factory.createBlock([
        factory.createReturnStatement(
          factory.createObjectLiteralExpression(
            [
              factory.createPropertyAssignment("success", factory.createFalse()),
              factory.createPropertyAssignment(
                "errors",
                factory.createArrayLiteralExpression([expectedGot("object")])
              ),
            ],
            true
          )
        ),
      ])
    );

    // Build the validator function
    return factory.createArrowFunction(
      undefined,
      undefined,
      [
        factory.createParameterDeclaration(
          undefined,
          undefined,
          factory.createIdentifier("value"),
          undefined,
          factory.createKeywordTypeNode(ts.SyntaxKind.UnknownKeyword)
        ),
      ],
      resultType,
      factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken),
      factory.createBlock(
        [
          // const errors: string[] = [];
          factory.createVariableStatement(
            undefined,
            factory.createVariableDeclarationList(
              [
                factory.createVariableDeclaration(
                  "errors",
                  undefined,
                  factory.createArrayTypeNode(
                    factory.createKeywordTypeNode(ts.SyntaxKind.StringKeyword)
                  ),
                  factory.createArrayLiteralExpression([])
                ),
              ],
              ts.NodeFlags.Const
            )
          ),
          ...(topIsPrimitive ? primitiveChecks : [objectGuard]),
          ...checks,
          // Return result
          factory.createReturnStatement(
            factory.createConditionalExpression(
              factory.createBinaryExpression(
                factory.createPropertyAccessExpression(
                  factory.createIdentifier("errors"),
                  "length"
                ),
                factory.createToken(ts.SyntaxKind.EqualsEqualsEqualsToken),
                factory.createNumericLiteral(0)
              ),
              factory.createToken(ts.SyntaxKind.QuestionToken),
              factory.createObjectLiteralExpression(
                [
                  factory.createPropertyAssignment("success", factory.createTrue()),
                  factory.createPropertyAssignment(
                    "value",
                    factory.createAsExpression(factory.createIdentifier("value"), typeArgs[0])
                  ),
                ],
                true
              ),
              factory.createToken(ts.SyntaxKind.ColonToken),
              factory.createObjectLiteralExpression(
                [
                  factory.createPropertyAssignment("success", factory.createFalse()),
                  factory.createPropertyAssignment("errors", factory.createIdentifier("errors")),
                ],
                true
              )
            )
          ),
        ],
        true
      )
    );
  },
});

// Register macros
globalRegistry.register(reflectAttribute);
globalRegistry.register(typeInfoMacro);
globalRegistry.register(fieldNamesMacro);
globalRegistry.register(validatorMacro);

// ============================================================================
// Types for Runtime
// ============================================================================

export type ValidationResult<T> =
  | { success: true; value: T }
  | { success: false; errors: string[] };
