/**
 * Unified Configuration System
 *
 * Provides a centralized configuration API for typesugar macros.
 * Configuration is loaded from (in priority order):
 *
 * 1. Environment variables: TYPESUGAR_* (highest priority, for CI overrides)
 * 2. Config files: typesugar.config.ts, .typesugarrc, etc. — the nearest one
 *    found walking up from `process.cwd()` (or from the directory passed to
 *    `config.load({ searchFrom })`), stopping at the repository root, and
 *    never one inside a `node_modules` directory (a dependency's)
 * 3. Programmatic: config.set() calls
 * 4. Defaults (lowest priority)
 *
 * (`config.set()` values are applied on top of the merged result, so in
 * practice they override env/file values until the next reload.)
 *
 * A config file that exists but fails to load is reported with a
 * `console.warn` and through `config.getLoadError()`; it is never silently
 * treated as "no config".
 *
 * @example
 * ```typescript
 * import { config } from "@typesugar/core";
 *
 * // Read config values
 * config.get("debug")                    // → boolean
 * config.get("contracts.mode")           // → "full" | "none" | ...
 *
 * // Set config programmatically
 * config.set({ contracts: { mode: "none" } });
 * ```
 */

import { evaluateConfigCondition } from "./config-condition.js";
import { searchConfigFile, isNodeRuntime } from "./config-loader.js";

// ============================================================================
// Types
// ============================================================================

/**
 * Contract configuration options.
 */
export interface ContractsConfig {
  /** "full" = all checks, "assertions" = invariants only, "none" = stripped */
  mode?: "full" | "assertions" | "none";
  /** Attempt compile-time proofs to eliminate runtime checks */
  proveAtCompileTime?: boolean;
  /** Fine-grained stripping per contract type */
  strip?: {
    preconditions?: boolean;
    postconditions?: boolean;
    invariants?: boolean;
  };
}

/**
 * Resolution mode for typeclass and operator lookup. Accepted for
 * compatibility but not read in 1.0: resolution is always import-scoped
 * (PEP-052), with no "automatic" or "explicit" behaviour.
 */
export type ResolutionMode = "automatic" | "import-scoped" | "explicit";

/**
 * Resolution configuration. The 1.0 macros don't read it: resolution is
 * always import-scoped, with no prelude (PEP-052). `config.isInPrelude` and
 * `config.isTracingEnabled` still answer from it for callers of their own.
 */
export interface ResolutionConfig {
  /** Global resolution mode */
  mode?: ResolutionMode;
  /** Per-file overrides (glob patterns) */
  fileOverrides?: Record<string, ResolutionMode>;
  /** Typeclasses available without import in automatic mode */
  prelude?: string[];
  /** Enable resolution tracing */
  trace?: boolean;
}

/**
 * Security-related configuration (PEP-055).
 */
export interface SecurityConfig {
  /**
   * Package names (or "@scope/*" wildcard entries) allowed to register
   * macros outside the auto-trusted `@typesugar/*` scope. Written by
   * `typesugar approve-macros`; safe to hand-edit, but review each entry
   * as carefully as a new production dependency.
   */
  allowedMacroPackages?: string[];
}

/**
 * Full typesugar configuration schema.
 */
export interface TypesugarConfig {
  /** Enable debug mode */
  debug?: boolean;
  /** Contract system configuration */
  contracts?: ContractsConfig;
  /** Resolution configuration */
  resolution?: ResolutionConfig;
  /** Feature flags */
  features?: Record<string, boolean>;
  /** Security configuration (macro-package trust, etc.) */
  security?: SecurityConfig;
  /** Custom user configuration */
  [key: string]: unknown;
}

// ============================================================================
// Global State
// ============================================================================

/**
 * Why file-based config is not in effect, when it isn't (deep review
 * 2026-10, core #20/#53): `"failed"` = a config file was found but loading
 * it threw; `"unavailable"` = this runtime can't load config files at all.
 */
export interface ConfigLoadError {
  kind: "failed" | "unavailable";
  /** The config file that failed to load (`"failed"` only, when known). */
  filepath?: string;
  message: string;
  error?: Error;
}

/**
 * One loaded configuration. `config.get()` reads the CURRENT one. A host
 * serving several projects in one process (tsserver, the Node loader, one
 * vite process for several packages) keeps each project's with
 * `config.capture()` after `config.load()`, and makes it current around that
 * project's work with `config.runWith()` -- the TransformationPipeline does
 * this when given `config` (review 8: with one config per process, the
 * project loaded last applied to every project, its
 * `security.allowedMacroPackages` included).
 */
interface ConfigState {
  store: TypesugarConfig;
  loaded: boolean;
  filePath: string | undefined;
  loadError: ConfigLoadError | undefined;
  /** Directory the config-file search starts from; `undefined` = `process.cwd()`. */
  searchFromDir: string | undefined;
}

function newState(searchFromDir?: string): ConfigState {
  return { store: {}, loaded: false, filePath: undefined, loadError: undefined, searchFromDir };
}

let current: ConfigState = newState();

/**
 * A project's loaded configuration, from `config.capture()`; opaque. Pass
 * it to `config.runWith()` (or a TransformationPipeline's `config` option).
 */
export interface ConfigSnapshot {
  readonly __typesugarConfigSnapshot: true;
}

// ============================================================================
// Environment Variable Loading
// ============================================================================

/**
 * Map an env-var name (without the `TYPESUGAR_` prefix) to a config path.
 *
 * - The FIRST single `_` separates the top-level key from the rest:
 *   `CONTRACTS_MODE` → `contracts.mode`.
 * - `__` separates any further nesting levels:
 *   `CONTRACTS__STRIP__PRECONDITIONS` → `contracts.strip.preconditions`.
 * - Every other `_` joins words in camelCase:
 *   `CONTRACTS_PROVE_AT_COMPILE_TIME` → `contracts.proveAtCompileTime`.
 *
 * (Deep review 2026-10, core #52: previously every `_` became a `.` and
 * case was lost, so camelCase keys like `proveAtCompileTime` were
 * unreachable from the environment.)
 */
function envKeyToConfigPath(name: string): string {
  const camel = (words: string): string =>
    words
      .toLowerCase()
      .split("_")
      .filter((w) => w.length > 0)
      .map((w, i) => (i === 0 ? w : w[0].toUpperCase() + w.slice(1)))
      .join("");

  const levels = name.split("__");
  const first = levels[0];
  const sep = first.indexOf("_");
  const head =
    sep === -1 ? [camel(first)] : [camel(first.slice(0, sep)), camel(first.slice(sep + 1))];
  return [...head, ...levels.slice(1).map(camel)].filter((s) => s.length > 0).join(".");
}

/**
 * `TYPESUGAR_*` variables that other code reads straight from `process.env`
 * with their own meaning (profiling, colour, the language-service plugin,
 * `cfg()` conditions). They are not config: merged in, they would add stray
 * keys (`profile`, `verbose`, `show.suppressedDiagnostics`, ...) that
 * override a user's own same-named keys in config conditions (pre-merge
 * review 2026-11). Names without the `TYPESUGAR_` prefix.
 */
const DIRECT_READ_ENV_VARS = new Set([
  "PROFILE",
  "VERBOSE",
  "NO_COLOR",
  "SHOW_SUPPRESSED_DIAGNOSTICS",
  "COMPTIME_IN_EDITOR",
]);
/** `TYPESUGAR_CFG_*` sets `cfg()` conditions (`@typesugar/macros`), not config. */
const CFG_ENV_PREFIX = "CFG_";

/**
 * Load configuration from environment variables.
 * Variables prefixed with TYPESUGAR_ are parsed into the config object
 * (see `envKeyToConfigPath` for the name mapping), except the ones in
 * `DIRECT_READ_ENV_VARS` and `TYPESUGAR_CFG_*`.
 *
 * Examples:
 *   TYPESUGAR_DEBUG=1                              → { debug: true }
 *   TYPESUGAR_CONTRACTS_MODE=none                  → { contracts: { mode: "none" } }
 *   TYPESUGAR_CONTRACTS_PROVE_AT_COMPILE_TIME=1    → { contracts: { proveAtCompileTime: true } }
 *   TYPESUGAR_CONTRACTS__STRIP__PRECONDITIONS=1    → { contracts: { strip: { preconditions: true } } }
 */
function loadConfigFromEnv(): TypesugarConfig {
  const envConfig: TypesugarConfig = {};
  const PREFIX = "TYPESUGAR_";
  const proc = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process;
  if (!proc?.env) return envConfig;

  const entries: Array<[string, string]> = [];
  for (const [key, value] of Object.entries(proc.env)) {
    if (!key.startsWith(PREFIX) || value === undefined) continue;
    const name = key.slice(PREFIX.length);
    if (DIRECT_READ_ENV_VARS.has(name) || name.startsWith(CFG_ENV_PREFIX)) continue;
    const configPath = envKeyToConfigPath(name);
    if (configPath.length > 0) entries.push([configPath, value]);
  }
  // Shallower paths first, so `TYPESUGAR_CONTRACTS=0` can't wipe
  // `TYPESUGAR_CONTRACTS_MODE=none` depending on environment order.
  entries.sort(([a], [b]) => a.split(".").length - b.split(".").length || a.localeCompare(b));

  for (const [configPath, value] of entries) {
    // Parse value
    let parsedValue: unknown;
    if (value === "1" || value === "true") {
      parsedValue = true;
    } else if (value === "0" || value === "false" || value === "") {
      parsedValue = false;
    } else if (
      /^\d+$/.test(value) &&
      Number.isSafeInteger(Number(value)) &&
      String(Number(value)) === value
    ) {
      // Only canonical integers: `0123` (leading zero) and integers past
      // 2^53 would not round-trip through a number, so they stay strings.
      parsedValue = Number(value);
    } else {
      parsedValue = value;
    }

    setNestedValue(envConfig, configPath, parsedValue);
  }

  return envConfig;
}

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Set a nested value using dot notation.
 */
function setNestedValue(obj: Record<string, unknown>, path: string, value: unknown): void {
  const parts = path.split(".");
  let current: Record<string, unknown> = obj;

  for (let i = 0; i < parts.length - 1; i++) {
    const part = parts[i];
    if (typeof current[part] !== "object" || current[part] === null) {
      current[part] = {};
    }
    current = current[part] as Record<string, unknown>;
  }

  current[parts[parts.length - 1]] = value;
}

/**
 * Get a nested value using dot notation.
 */
function getNestedValue(obj: unknown, path: string): unknown {
  const parts = path.split(".");
  let current: unknown = obj;

  for (const part of parts) {
    if (typeof current !== "object" || current === null) {
      return undefined;
    }
    current = (current as Record<string, unknown>)[part];
  }

  return current;
}

/**
 * Deep merge objects (right takes precedence).
 */
function deepMerge(
  target: Record<string, unknown>,
  source: Record<string, unknown>
): Record<string, unknown> {
  const result = { ...target };

  for (const key of Object.keys(source)) {
    const sourceValue = source[key];
    const targetValue = result[key];

    if (
      typeof sourceValue === "object" &&
      sourceValue !== null &&
      !Array.isArray(sourceValue) &&
      typeof targetValue === "object" &&
      targetValue !== null &&
      !Array.isArray(targetValue)
    ) {
      result[key] = deepMerge(
        targetValue as Record<string, unknown>,
        sourceValue as Record<string, unknown>
      );
    } else {
      result[key] = sourceValue;
    }
  }

  return result;
}

// ============================================================================
// Config File Loading (see config-loader.ts)
// ============================================================================

/** Messages already printed, so a repeated reload doesn't spam the same warning. */
const warnedLoadErrors = new Set<string>();

function warnOnce(message: string): void {
  if (warnedLoadErrors.has(message)) return;
  warnedLoadErrors.add(message);
  console.warn(message);
}

function loadConfigFromFiles(): TypesugarConfig {
  const proc = (globalThis as { process?: { cwd?: () => string } }).process;
  const from = current.searchFromDir ?? proc?.cwd?.();
  if (from === undefined) {
    // Browser bundle (playground): there is no file system to search.
    return {};
  }

  const result = searchConfigFile(from);
  switch (result.kind) {
    case "found":
      current.filePath = result.filepath;
      return result.config as TypesugarConfig;
    case "none":
      return {};
    case "failed": {
      current.loadError = {
        kind: "failed",
        filepath: result.filepath,
        message: result.error.message,
        error: result.error,
      };
      warnOnce(
        `[typesugar] Failed to load config file ${result.filepath ?? "(unknown path)"}: ` +
          `${result.error.message}\n` +
          `[typesugar] All file-based settings (including security.allowedMacroPackages) ` +
          `are being ignored; using defaults and TYPESUGAR_* environment variables only.`
      );
      return {};
    }
    case "unavailable":
      current.loadError = { kind: "unavailable", message: result.reason };
      // Only a real Node process can have a config file worth warning about.
      if (isNodeRuntime()) {
        warnOnce(
          `[typesugar] Config files (typesugar.config.ts, .typesugarrc, ...) cannot be ` +
            `loaded: ${result.reason}. Only defaults and TYPESUGAR_* environment ` +
            `variables are in effect.`
        );
      }
      return {};
  }
}

// ============================================================================
// Config Initialization
// ============================================================================

/**
 * Initialize configuration from all sources.
 */
function initializeConfig(): void {
  if (current.loaded) return;

  const defaults: TypesugarConfig = {
    debug: false,
    contracts: {
      mode: "full",
      proveAtCompileTime: false,
      strip: {},
    },
    features: {},
  };

  const fileConfig = loadConfigFromFiles();
  const envConfig = loadConfigFromEnv();

  // Merge: defaults < fileConfig < envConfig
  current.store = deepMerge(deepMerge(defaults, fileConfig), envConfig) as TypesugarConfig;
  current.loaded = true;
}

// ============================================================================
// Public API
// ============================================================================

/**
 * Get a configuration value by path.
 */
function get<T = unknown>(path: string): T | undefined {
  initializeConfig();
  return getNestedValue(current.store, path) as T | undefined;
}

/**
 * Set configuration values programmatically.
 */
function set(values: Partial<TypesugarConfig>): void {
  initializeConfig();
  current.store = deepMerge(current.store, values) as TypesugarConfig;
}

/**
 * Check if a configuration path has a truthy value.
 */
function has(path: string): boolean {
  return !!get(path);
}

/**
 * Get all configuration values.
 */
function getAll(): Readonly<TypesugarConfig> {
  initializeConfig();
  return current.store;
}

/**
 * Get the path to the loaded config file (if any).
 */
function getConfigFilePath(): string | undefined {
  initializeConfig();
  return current.filePath;
}

/**
 * Reset configuration to defaults (mainly for testing).
 */
function reset(): void {
  // A new state, not a cleared one: a snapshot a host captured stays intact.
  current = newState();
}

/**
 * (Re)load configuration, searching for a config file upward from
 * `options.searchFrom` (default: `process.cwd()`). Discards previous
 * `config.set()` values, and re-reads the file even if it was loaded before
 * — call it again after the config file changes (watch mode / LSP hosts).
 *
 * Hosts that know the project (the tsconfig directory) should call this
 * with it, so the config doesn't depend on the process's cwd.
 */
function load(options: { searchFrom?: string } = {}): void {
  current = newState(options.searchFrom);
  initializeConfig();
}

/**
 * The current (loaded) configuration, to make current again later with
 * `runWith` -- after `load({ searchFrom: projectDir })`, that project's.
 * Later `config.set()` calls made while it is current apply to it.
 */
function capture(): ConfigSnapshot {
  initializeConfig();
  return current as unknown as ConfigSnapshot;
}

/**
 * Run `fn` with `snapshot` as the current configuration, then restore the
 * previous one. Synchronous, like everything that reads config (macro
 * expansion has no async boundary), so nothing else runs in between.
 */
function runWith<T>(snapshot: ConfigSnapshot, fn: () => T): T {
  const previous = current;
  current = snapshot as unknown as ConfigState;
  try {
    return fn();
  } finally {
    current = previous;
  }
}

/**
 * Why file-based config is not in effect, if it isn't: a config file that
 * was found but failed to load, or a runtime that can't load config files
 * at all. `undefined` when the file loaded fine or there simply is none.
 */
function getLoadError(): ConfigLoadError | undefined {
  initializeConfig();
  return current.loadError;
}

/**
 * Evaluate a condition string against the configuration.
 *
 * Supports dotted paths, quoted strings, numbers, true/false/null/undefined,
 * `==`/`===`/`!=`/`!==`, `&&`, `||`, `!` and parentheses. Throws a
 * `ConfigConditionError` for anything else, rather than silently returning
 * false (deep review 2026-10, core #51).
 */
function evaluate(condition: string): boolean {
  initializeConfig();
  return evaluateConfigCondition(condition, (p) => getNestedValue(current.store, p));
}

/**
 * Conditional value based on configuration.
 */
function when<T, U = undefined>(
  condition: string,
  thenValue: T | (() => T),
  elseValue?: U | (() => U)
): T | U | undefined {
  const isActive = evaluate(condition);

  if (isActive) {
    return typeof thenValue === "function" ? (thenValue as () => T)() : thenValue;
  } else if (elseValue !== undefined) {
    return typeof elseValue === "function" ? (elseValue as () => U)() : elseValue;
  }

  return undefined;
}

// ============================================================================
// Resolution Mode Helpers
// ============================================================================

/**
 * Get the resolution mode for a specific file.
 * Checks file overrides first, then falls back to global mode.
 */
function getResolutionModeForFile(fileName: string): ResolutionMode {
  const resolution = get<ResolutionConfig>("resolution");
  if (!resolution) return "import-scoped";

  // Check file overrides
  if (resolution.fileOverrides) {
    for (const [pattern, mode] of Object.entries(resolution.fileOverrides)) {
      if (matchGlob(fileName, pattern)) {
        return mode;
      }
    }
  }

  return resolution.mode ?? "import-scoped";
}

/**
 * Simple glob matching for file overrides.
 */
function matchGlob(fileName: string, pattern: string): boolean {
  // Convert glob pattern to regex
  const regexStr = pattern
    .replace(/[.+^${}()|[\]\\]/g, "\\$&")
    .replace(/\*/g, ".*")
    .replace(/\?/g, ".");
  const regex = new RegExp(`^${regexStr}$`);
  return regex.test(fileName);
}

/**
 * Check if a typeclass is in the prelude.
 */
function isInPrelude(typeclassName: string): boolean {
  const resolution = get<ResolutionConfig>("resolution");
  // PEP-052: no ambient prelude — nothing is in scope by default in import-scoped
  // mode; a file activates a typeclass only by importing it (or its @syntax marker).
  // A project may still opt into a prelude via `resolution.prelude` config.
  const prelude = resolution?.prelude ?? [];
  return prelude.includes(typeclassName);
}

/**
 * Check if resolution tracing is enabled.
 */
function isTracingEnabled(): boolean {
  const resolution = get<ResolutionConfig>("resolution");
  return resolution?.trace ?? false;
}

// ============================================================================
// Export: config object
// ============================================================================

/**
 * Unified configuration API.
 */
export const config = {
  get,
  set,
  has,
  getAll,
  getConfigFilePath,
  getLoadError,
  load,
  capture,
  runWith,
  reset,
  evaluate,
  when,
  getResolutionModeForFile,
  isInPrelude,
  isTracingEnabled,
} as const;

/**
 * Helper for creating type-safe configuration files.
 */
export function defineConfig(cfg: TypesugarConfig): TypesugarConfig {
  return cfg;
}
