/**
 * MacroContext Implementation - Provides utilities for macro expansion
 */

import * as ts from "typescript";
import { MacroContext, ComptimeValue, MacroDiagnostic } from "./types.js";
import { HygieneContext, globalHygiene, FileBindingCache } from "./hygiene.js";
import {
  cloneNodeDeep,
  isSyntheticNode,
  hasSourceText,
  numberToExpression,
  bigintToExpression,
} from "./ast-utils.js";
import {
  DiagnosticBuilder,
  type DiagnosticDescriptor,
  richToLegacyDiagnostic,
} from "./diagnostics.js";

/**
 * Unwrap expressions that do not change a value at runtime -- parentheses,
 * `as T` / `as const`, `satisfies T`, `<T>x` and `x!` -- so compile-time
 * evaluation sees the value they wrap (`const C = { T: 5 } as const` is as
 * constant as the same literal without `as const`).
 */
function skipTypeOnlyWrappers(node: ts.Node): ts.Node {
  while (
    ts.isParenthesizedExpression(node) ||
    ts.isAsExpression(node) ||
    ts.isSatisfiesExpression(node) ||
    ts.isTypeAssertionExpression(node) ||
    ts.isNonNullExpression(node)
  ) {
    node = node.expression;
  }
  return node;
}
export class MacroContextImpl implements MacroContext {
  private diagnostics: MacroDiagnostic[] = [];
  private scope: Map<string, ComptimeValue> = new Map();
  private _emittedShortNames: Set<string> = new Set();

  /**
   * Shared printer instance for node-to-string conversion.
   * Creating a printer is expensive; reuse across the lifetime of the context.
   */
  private _printer: ts.Printer | undefined;

  /** Hygiene context for scoped identifier generation */
  public readonly hygiene: HygieneContext;

  /**
   * File binding cache for reference hygiene.
   * Built lazily on first safeRef() call.
   */
  private _fileBindingCache: FileBindingCache | undefined;

  /** Whether verbose logging is enabled for hygiene */
  private _verbose: boolean;

  constructor(
    public readonly program: ts.Program,
    public readonly typeChecker: ts.TypeChecker,
    public readonly sourceFile: ts.SourceFile,
    public readonly factory: ts.NodeFactory,
    public readonly transformContext: ts.TransformationContext,
    hygiene?: HygieneContext,
    fileBindingCache?: FileBindingCache,
    verbose = false
  ) {
    this.hygiene = hygiene ?? globalHygiene;
    this._fileBindingCache = fileBindingCache;
    this._verbose = verbose;
  }

  /**
   * Get the file binding cache, creating it lazily if needed.
   */
  get fileBindingCache(): FileBindingCache {
    if (!this._fileBindingCache) {
      this._fileBindingCache = new FileBindingCache(this.sourceFile, this._verbose);
    }
    return this._fileBindingCache;
  }

  /**
   * Set the file binding cache (used by transformer to share across contexts).
   */
  setFileBindingCache(cache: FileBindingCache): void {
    this._fileBindingCache = cache;
  }

  /** Lazily-created shared printer instance */
  get printer(): ts.Printer {
    return (this._printer ??= ts.createPrinter({
      newLine: ts.NewLineKind.LineFeed,
    }));
  }

  // -------------------------------------------------------------------------
  // Tree-Shaking Annotations
  // -------------------------------------------------------------------------

  markPure<T extends ts.Node>(node: T): T {
    ts.addSyntheticLeadingComment(node, ts.SyntaxKind.MultiLineCommentTrivia, "#__PURE__", false);
    return node;
  }

  // -------------------------------------------------------------------------
  // Node Creation Utilities
  // -------------------------------------------------------------------------

  createIdentifier(name: string): ts.Identifier {
    return this.factory.createIdentifier(name);
  }

  createNumericLiteral(value: number): ts.NumericLiteral {
    return this.factory.createNumericLiteral(value);
  }

  createStringLiteral(value: string): ts.StringLiteral {
    return this.factory.createStringLiteral(value);
  }

  createBooleanLiteral(value: boolean): ts.Expression {
    return value ? this.factory.createTrue() : this.factory.createFalse();
  }

  createArrayLiteral(elements: ts.Expression[]): ts.ArrayLiteralExpression {
    return this.factory.createArrayLiteralExpression(elements);
  }

  createObjectLiteral(
    properties: Array<{ name: string; value: ts.Expression }>
  ): ts.ObjectLiteralExpression {
    const propAssignments = properties.map(({ name, value }) =>
      this.factory.createPropertyAssignment(this.factory.createIdentifier(name), value)
    );
    return this.factory.createObjectLiteralExpression(propAssignments, true);
  }

  parseExpression(code: string): ts.Expression {
    // Create a temporary source file to parse the expression
    const tempSource = ts.createSourceFile(
      "__macro_temp__.ts",
      `const __expr__ = ${code};`,
      ts.ScriptTarget.Latest,
      true,
      ts.ScriptKind.TS
    );

    // Check for parse errors
    const diags = (tempSource as unknown as { parseDiagnostics?: unknown[] }).parseDiagnostics;
    if (diags && diags.length > 0) {
      throw new Error(`Failed to parse expression: ${code}`);
    }

    // Extract the expression from the variable declaration. Require exactly
    // one statement with exactly one declarator: otherwise `a, b` (two
    // declarators) or `x; sideEffect()` (two statements) would silently lose
    // everything after the first part (deep review core #29). Trailing empty
    // statements (`expr;`) are fine.
    const nonEmpty = tempSource.statements.filter((st) => !ts.isEmptyStatement(st));
    const statement = nonEmpty[0];
    if (nonEmpty.length === 1 && ts.isVariableStatement(statement)) {
      const decls = statement.declarationList.declarations;
      const declaration = decls[0];
      if (decls.length === 1 && declaration.initializer) {
        // A synthesized copy (positions -1, tokens and lists included), so the
        // printer generates fresh text instead of reading the temp file's,
        // and TypeScript's emit resolver doesn't take it for a parse-tree
        // node of the program (it resolved names on the temp file's nodes and
        // queued "Cannot find name" at position -1 — audit F20).
        return cloneNodeDeep(declaration.initializer);
      }
    }

    throw new Error(`Failed to parse expression: ${code}`);
  }

  parseStatements(code: string): ts.Statement[] {
    const tempSource = ts.createSourceFile(
      "__macro_temp__.ts",
      code,
      ts.ScriptTarget.Latest,
      true,
      ts.ScriptKind.TS
    );
    // The parser recovers from errors; returning its recovery would emit
    // broken JS with no diagnostic pointing at the macro. Throw instead — the
    // transformer's expansion catch turns it into a visible macro error
    // (deep review core #29).
    const diags = (tempSource as unknown as { parseDiagnostics?: ts.Diagnostic[] })
      .parseDiagnostics;
    if (diags && diags.length > 0) {
      const first = ts.flattenDiagnosticMessageText(diags[0].messageText, "\n");
      throw new Error(`Failed to parse statements (${first}): ${code}`);
    }
    // Synthesized copies, as in parseExpression.
    return Array.from(tempSource.statements).map((stmt) => cloneNodeDeep(stmt));
  }

  // -------------------------------------------------------------------------
  // Type Utilities
  // -------------------------------------------------------------------------

  getTypeOf(node: ts.Node): ts.Type {
    return this.typeChecker.getTypeAtLocation(node);
  }

  getTypeString(node: ts.Node): string {
    const type = this.getTypeOf(node);
    return this.typeChecker.typeToString(type);
  }

  isAssignableTo(source: ts.Type, target: ts.Type): boolean {
    return this.typeChecker.isTypeAssignableTo(source, target);
  }

  getPropertiesOfType(type: ts.Type): ts.Symbol[] {
    return this.typeChecker.getPropertiesOfType(type);
  }

  getSymbol(node: ts.Node): ts.Symbol | undefined {
    return this.typeChecker.getSymbolAtLocation(node);
  }

  // -------------------------------------------------------------------------
  // Type Confidence
  // -------------------------------------------------------------------------

  isTypeReliable(type: ts.Type): boolean {
    if (type.flags & ts.TypeFlags.Any) {
      return false;
    }
    if (type.flags & ts.TypeFlags.Never) {
      return false;
    }
    return true;
  }

  assertTypeReliable(node: ts.Node, purpose: string): ts.Type | null {
    const type = this.typeChecker.getTypeAtLocation(node);
    if (!this.isTypeReliable(type)) {
      const nodeText = hasSourceText(node)
        ? node.getText(this.sourceFile)
        : this.printer.printNode(ts.EmitHint.Expression, node, this.sourceFile);
      // A macro-generated node has no type in the Program the checker was
      // built from, so "fix upstream type errors" would send the user hunting
      // for errors that don't exist (deep review core #48).
      const synthetic = isSyntheticNode(node) || !ts.getParseTreeNode(node);
      this.reportWarning(
        node,
        synthetic
          ? `typesugar skipped ${purpose} because '${nodeText}' is macro-generated code the type checker cannot see.`
          : `typesugar skipped ${purpose} because the type of '${nodeText}' could not be resolved. Fix upstream type errors first.`
      );
      return null;
    }
    return type;
  }

  // -------------------------------------------------------------------------
  // Diagnostics
  // -------------------------------------------------------------------------

  reportError(node: ts.Node, message: string): void {
    this.diagnostics.push({
      severity: "error",
      message,
      node,
    });
  }

  reportWarning(node: ts.Node, message: string): void {
    this.diagnostics.push({
      severity: "warning",
      message,
      node,
    });
  }

  diagnostic(descriptor: DiagnosticDescriptor): DiagnosticBuilder {
    return new DiagnosticBuilder(descriptor, this.sourceFile, (rich) => {
      const legacy = richToLegacyDiagnostic(rich);
      this.diagnostics.push({
        severity: legacy.severity,
        message: legacy.message,
        node: legacy.node,
        suggestion: legacy.suggestion,
      });
    });
  }

  getDiagnostics(): MacroDiagnostic[] {
    return [...this.diagnostics];
  }

  clearDiagnostics(): void {
    this.diagnostics = [];
  }

  // -------------------------------------------------------------------------
  // Compile-Time Evaluation
  // -------------------------------------------------------------------------

  evaluate(node: ts.Node): ComptimeValue {
    return this.evaluateNode(node);
  }

  isComptime(node: ts.Node): boolean {
    node = skipTypeOnlyWrappers(node);
    // Check if a node can be evaluated at compile time
    if (ts.isLiteralExpression(node)) {
      return true;
    }

    // Handle true/false keywords as literal expressions
    if (node.kind === ts.SyntaxKind.TrueKeyword || node.kind === ts.SyntaxKind.FalseKeyword) {
      return true;
    }

    if (ts.isArrayLiteralExpression(node)) {
      return node.elements.every((e) => this.isComptime(e));
    }

    if (ts.isObjectLiteralExpression(node)) {
      return node.properties.every((p) => {
        if (ts.isPropertyAssignment(p)) {
          return this.isComptime(p.initializer);
        }
        return false;
      });
    }

    if (ts.isBinaryExpression(node)) {
      return this.isComptime(node.left) && this.isComptime(node.right);
    }

    if (ts.isPrefixUnaryExpression(node) || ts.isPostfixUnaryExpression(node)) {
      return this.isComptime(node.operand);
    }

    if (ts.isConditionalExpression(node)) {
      return (
        this.isComptime(node.condition) &&
        this.isComptime(node.whenTrue) &&
        this.isComptime(node.whenFalse)
      );
    }

    if (ts.isParenthesizedExpression(node)) {
      return this.isComptime(node.expression);
    }

    // Identifiers are comptime only if they refer to const values
    if (ts.isIdentifier(node)) {
      const symbol = this.typeChecker.getSymbolAtLocation(node);
      if (symbol) {
        const declarations = symbol.getDeclarations();
        if (declarations && declarations.length > 0) {
          const decl = declarations[0];
          if (ts.isVariableDeclaration(decl)) {
            const parent = decl.parent;
            if (ts.isVariableDeclarationList(parent)) {
              if (parent.flags & ts.NodeFlags.Const) {
                return decl.initializer ? this.isComptime(decl.initializer) : false;
              }
            }
          }
        }
      }
    }

    return false;
  }

  private evaluateNode(node: ts.Node): ComptimeValue {
    node = skipTypeOnlyWrappers(node);
    // Numeric literals
    if (ts.isNumericLiteral(node)) {
      return { kind: "number", value: parseFloat(node.text) };
    }

    // String literals
    if (ts.isStringLiteral(node)) {
      return { kind: "string", value: node.text };
    }

    // Boolean literals
    if (node.kind === ts.SyntaxKind.TrueKeyword) {
      return { kind: "boolean", value: true };
    }
    if (node.kind === ts.SyntaxKind.FalseKeyword) {
      return { kind: "boolean", value: false };
    }

    // Null/undefined
    if (node.kind === ts.SyntaxKind.NullKeyword) {
      return { kind: "null" };
    }
    if (node.kind === ts.SyntaxKind.UndefinedKeyword) {
      return { kind: "undefined" };
    }

    // Array literals
    if (ts.isArrayLiteralExpression(node)) {
      const elements = node.elements.map((e) => this.evaluateNode(e));
      const hasError = elements.find((e) => e.kind === "error");
      if (hasError) return hasError;
      return { kind: "array", elements };
    }

    // Object literals
    if (ts.isObjectLiteralExpression(node)) {
      const properties = new Map<string, ComptimeValue>();
      for (const prop of node.properties) {
        if (ts.isPropertyAssignment(prop)) {
          const name = ts.isIdentifier(prop.name)
            ? prop.name.text
            : ts.isStringLiteral(prop.name)
              ? prop.name.text
              : null;
          if (name) {
            const value = this.evaluateNode(prop.initializer);
            if (value.kind === "error") return value;
            properties.set(name, value);
          }
        }
      }
      return { kind: "object", properties };
    }

    // Identifiers — resolve const declarations and scope bindings
    if (ts.isIdentifier(node)) {
      // Check local scope first (arrow function params, local variables)
      const scopeVal = this.scope.get(node.text);
      if (scopeVal) return scopeVal;

      // Resolve via type checker — follow const declarations to their initializers
      try {
        const symbol = this.typeChecker.getSymbolAtLocation(node);
        if (symbol) {
          const declarations = symbol.getDeclarations();
          if (declarations && declarations.length > 0) {
            const decl = declarations[0];
            if (ts.isVariableDeclaration(decl) && decl.initializer) {
              const parent = decl.parent;
              if (ts.isVariableDeclarationList(parent) && parent.flags & ts.NodeFlags.Const) {
                return this.evaluateNode(decl.initializer);
              }
            }
            // Enum members
            if (ts.isEnumMember(decl) && decl.initializer) {
              return this.evaluateNode(decl.initializer);
            }
          }
        }
      } catch {
        // Type checker may not be available in all contexts
      }
      return { kind: "error", message: `Cannot resolve identifier '${node.text}' at compile time` };
    }

    // Property access — handle .length, .includes(), etc. on known values
    if (ts.isPropertyAccessExpression(node)) {
      const prop = node.name.text;

      // Well-known globals must be checked BEFORE evaluating the expression,
      // since globals like `Math` aren't const declarations and would fail resolution.
      if (ts.isIdentifier(node.expression) && node.expression.text === "Math") {
        const mathProps: Record<string, number> = {
          PI: Math.PI,
          E: Math.E,
          LN2: Math.LN2,
          LN10: Math.LN10,
          LOG2E: Math.LOG2E,
          LOG10E: Math.LOG10E,
          SQRT2: Math.SQRT2,
          SQRT1_2: Math.SQRT1_2,
        };
        if (prop in mathProps) return { kind: "number", value: mathProps[prop] };
        const mathFns: Record<string, (...args: number[]) => number> = {
          abs: Math.abs,
          ceil: Math.ceil,
          floor: Math.floor,
          round: Math.round,
          sqrt: Math.sqrt,
          pow: Math.pow,
          min: Math.min,
          max: Math.max,
          sign: Math.sign,
          trunc: Math.trunc,
          log: Math.log,
          log2: Math.log2,
          log10: Math.log10,
        };
        if (prop in mathFns) {
          const fn = mathFns[prop];
          return {
            kind: "function",
            fn: (...args: ComptimeValue[]) => {
              const nums = args.map((a) => (a.kind === "number" ? a.value : NaN));
              return { kind: "number" as const, value: fn(...nums) };
            },
          };
        }
      }

      const obj = this.evaluateNode(node.expression);
      if (obj.kind === "error") return obj;

      if (obj.kind === "string") {
        if (prop === "length") return { kind: "number", value: obj.value.length };
        if (prop === "trim")
          return {
            kind: "function",
            fn: () => ({ kind: "string" as const, value: obj.value.trim() }),
          };
        if (prop === "toUpperCase")
          return {
            kind: "function",
            fn: () => ({ kind: "string" as const, value: obj.value.toUpperCase() }),
          };
        if (prop === "toLowerCase")
          return {
            kind: "function",
            fn: () => ({ kind: "string" as const, value: obj.value.toLowerCase() }),
          };
        if (prop === "startsWith")
          return {
            kind: "function",
            fn: (arg: ComptimeValue) => ({
              kind: "boolean" as const,
              value: arg.kind === "string" && obj.value.startsWith(arg.value),
            }),
          };
        if (prop === "endsWith")
          return {
            kind: "function",
            fn: (arg: ComptimeValue) => ({
              kind: "boolean" as const,
              value: arg.kind === "string" && obj.value.endsWith(arg.value),
            }),
          };
        if (prop === "includes")
          return {
            kind: "function",
            fn: (arg: ComptimeValue) => ({
              kind: "boolean" as const,
              value: arg.kind === "string" && obj.value.includes(arg.value),
            }),
          };
      }

      if (obj.kind === "array") {
        if (prop === "length") return { kind: "number", value: obj.elements.length };
        if (prop === "includes")
          return {
            kind: "function",
            fn: (arg: ComptimeValue) => ({
              kind: "boolean" as const,
              value: obj.elements.some(
                (e) =>
                  e.kind === arg.kind && "value" in e && "value" in arg && e.value === arg.value
              ),
            }),
          };
      }

      if (obj.kind === "object") {
        const val = obj.properties.get(prop);
        if (val) return val;
      }

      return {
        kind: "error",
        message: `Cannot access property '${prop}' on ${obj.kind} at compile time`,
      };
    }

    // Element access — handle array[0], obj["key"]
    if (ts.isElementAccessExpression(node)) {
      const obj = this.evaluateNode(node.expression);
      if (obj.kind === "error") return obj;
      const idx = this.evaluateNode(node.argumentExpression);
      if (idx.kind === "error") return idx;

      if (obj.kind === "array" && idx.kind === "number") {
        const i = Math.floor(idx.value);
        if (i >= 0 && i < obj.elements.length) return obj.elements[i];
        return { kind: "undefined" };
      }

      if (obj.kind === "object" && idx.kind === "string") {
        return obj.properties.get(idx.value) ?? { kind: "undefined" };
      }

      return {
        kind: "error",
        message: `Cannot index ${obj.kind} with ${idx.kind} at compile time`,
      };
    }

    // Parenthesized expressions
    if (ts.isParenthesizedExpression(node)) {
      return this.evaluateNode(node.expression);
    }

    // Binary expressions
    if (ts.isBinaryExpression(node)) {
      return this.evaluateBinaryExpression(node);
    }

    // Prefix unary expressions
    if (ts.isPrefixUnaryExpression(node)) {
      return this.evaluatePrefixUnary(node);
    }

    // Conditional expressions (ternary)
    if (ts.isConditionalExpression(node)) {
      const condition = this.evaluateNode(node.condition);
      if (condition.kind === "error") return condition;
      const condValue = this.comptimeToBoolean(condition);
      if (condValue === null) {
        return { kind: "error", message: "Cannot convert to boolean" };
      }
      return condValue ? this.evaluateNode(node.whenTrue) : this.evaluateNode(node.whenFalse);
    }

    // Template literals (simple case)
    if (ts.isTemplateExpression(node)) {
      let result = node.head.text;
      for (const span of node.templateSpans) {
        const value = this.evaluateNode(span.expression);
        if (value.kind === "error") return value;
        result += this.comptimeToString(value) + span.literal.text;
      }
      return { kind: "string", value: result };
    }

    if (ts.isNoSubstitutionTemplateLiteral(node)) {
      return { kind: "string", value: node.text };
    }

    // Arrow functions - return as function value for later evaluation
    if (ts.isArrowFunction(node)) {
      // Lexical scope: capture the bindings visible where the arrow is
      // DEFINED, not whatever `this.scope` holds when it is later called
      // (deep review core #45).
      const definitionScope = new Map(this.scope);
      return {
        kind: "function",
        fn: (...args: ComptimeValue[]) => {
          // Bind parameters to arguments, on top of the definition scope
          const savedScope = this.scope;
          this.scope = new Map(definitionScope);
          node.parameters.forEach((param, i) => {
            if (ts.isIdentifier(param.name)) {
              this.scope.set(
                param.name.text,
                i < args.length ? args[i] : { kind: "undefined" as const }
              );
            }
          });

          try {
            if (ts.isBlock(node.body)) {
              // Evaluate block body: execute statements, return last expression or undefined
              for (const stmt of node.body.statements) {
                if (ts.isReturnStatement(stmt)) {
                  return stmt.expression
                    ? this.evaluateNode(stmt.expression)
                    : ({ kind: "undefined" } as ComptimeValue);
                }
                if (ts.isExpressionStatement(stmt)) {
                  const result = this.evaluateNode(stmt.expression);
                  if (result.kind === "error") return result;
                }
                if (ts.isVariableStatement(stmt)) {
                  for (const decl of stmt.declarationList.declarations) {
                    if (ts.isIdentifier(decl.name) && decl.initializer) {
                      const val = this.evaluateNode(decl.initializer);
                      if (val.kind === "error") return val;
                      this.scope.set(decl.name.text, val);
                    }
                  }
                }
              }
              return { kind: "undefined" } as ComptimeValue;
            }
            return this.evaluateNode(node.body);
          } finally {
            // Restore scope
            this.scope = savedScope;
          }
        },
      };
    }

    // typeof expressions — map comptime value kind to JS typeof string
    if (ts.isTypeOfExpression(node)) {
      const operand = this.evaluateNode(node.expression);
      if (operand.kind === "error") return operand;
      const typeMap: Record<string, string> = {
        number: "number",
        string: "string",
        boolean: "boolean",
        bigint: "bigint",
        function: "function",
        null: "object",
        undefined: "undefined",
        array: "object",
        object: "object",
      };
      const result = typeMap[operand.kind];
      if (result) return { kind: "string", value: result };
      return { kind: "error", message: `Cannot determine typeof for ${operand.kind}` };
    }

    // Call expressions - evaluate function calls at compile time
    if (ts.isCallExpression(node)) {
      // Recognise comptime(() => expr) — evaluate the inner function immediately
      if (
        ts.isIdentifier(node.expression) &&
        node.expression.text === "comptime" &&
        node.arguments.length === 1 &&
        ts.isArrowFunction(node.arguments[0])
      ) {
        return this.evaluateNode(node.arguments[0].body);
      }

      const fn = this.evaluateNode(node.expression);
      if (fn.kind === "function") {
        const args = node.arguments.map((a) => this.evaluateNode(a));
        const errorArg = args.find((a) => a.kind === "error");
        if (errorArg) return errorArg;
        return fn.fn(...args);
      }
    }

    return {
      kind: "error",
      message: `Cannot evaluate node of kind ${ts.SyntaxKind[node.kind]} at compile time`,
    };
  }

  private evaluateBinaryExpression(node: ts.BinaryExpression): ComptimeValue {
    const op = node.operatorToken.kind;

    // Short-circuit evaluation for && and ||
    // These work with ANY types (not just booleans) and return one of the operands
    if (op === ts.SyntaxKind.AmpersandAmpersandToken) {
      const left = this.evaluateNode(node.left);
      if (left.kind === "error") return left;
      const leftBool = this.comptimeToBoolean(left);
      if (leftBool === null) {
        return { kind: "error", message: "Cannot convert to boolean in &&" };
      }
      // && returns left if falsy, otherwise evaluates and returns right
      if (!leftBool) return left;
      return this.evaluateNode(node.right);
    }

    if (op === ts.SyntaxKind.BarBarToken) {
      const left = this.evaluateNode(node.left);
      if (left.kind === "error") return left;
      const leftBool = this.comptimeToBoolean(left);
      if (leftBool === null) {
        return { kind: "error", message: "Cannot convert to boolean in ||" };
      }
      // || returns left if truthy, otherwise evaluates and returns right
      if (leftBool) return left;
      return this.evaluateNode(node.right);
    }

    // Nullish coalescing (??) - returns left if not null/undefined, else right
    if (op === ts.SyntaxKind.QuestionQuestionToken) {
      const left = this.evaluateNode(node.left);
      if (left.kind === "error") return left;
      if (left.kind !== "null" && left.kind !== "undefined") return left;
      return this.evaluateNode(node.right);
    }

    // For all other operators, evaluate both sides
    const left = this.evaluateNode(node.left);
    const right = this.evaluateNode(node.right);

    if (left.kind === "error") return left;
    if (right.kind === "error") return right;

    // Numeric operations
    if (left.kind === "number" && right.kind === "number") {
      switch (op) {
        case ts.SyntaxKind.PlusToken:
          return { kind: "number", value: left.value + right.value };
        case ts.SyntaxKind.MinusToken:
          return { kind: "number", value: left.value - right.value };
        case ts.SyntaxKind.AsteriskToken:
          return { kind: "number", value: left.value * right.value };
        case ts.SyntaxKind.SlashToken:
          return { kind: "number", value: left.value / right.value };
        case ts.SyntaxKind.PercentToken:
          return { kind: "number", value: left.value % right.value };
        case ts.SyntaxKind.AsteriskAsteriskToken:
          return { kind: "number", value: left.value ** right.value };
        case ts.SyntaxKind.LessThanToken:
          return { kind: "boolean", value: left.value < right.value };
        case ts.SyntaxKind.LessThanEqualsToken:
          return { kind: "boolean", value: left.value <= right.value };
        case ts.SyntaxKind.GreaterThanToken:
          return { kind: "boolean", value: left.value > right.value };
        case ts.SyntaxKind.GreaterThanEqualsToken:
          return { kind: "boolean", value: left.value >= right.value };
        case ts.SyntaxKind.EqualsEqualsToken:
        case ts.SyntaxKind.EqualsEqualsEqualsToken:
          return { kind: "boolean", value: left.value === right.value };
        case ts.SyntaxKind.ExclamationEqualsToken:
        case ts.SyntaxKind.ExclamationEqualsEqualsToken:
          return { kind: "boolean", value: left.value !== right.value };
        case ts.SyntaxKind.AmpersandToken:
          return { kind: "number", value: left.value & right.value };
        case ts.SyntaxKind.BarToken:
          return { kind: "number", value: left.value | right.value };
        case ts.SyntaxKind.CaretToken:
          return { kind: "number", value: left.value ^ right.value };
        case ts.SyntaxKind.LessThanLessThanToken:
          return { kind: "number", value: left.value << right.value };
        case ts.SyntaxKind.GreaterThanGreaterThanToken:
          return { kind: "number", value: left.value >> right.value };
        case ts.SyntaxKind.GreaterThanGreaterThanGreaterThanToken:
          return { kind: "number", value: left.value >>> right.value };
      }
    }

    // String operations
    if (left.kind === "string" && right.kind === "string") {
      switch (op) {
        case ts.SyntaxKind.PlusToken:
          return { kind: "string", value: left.value + right.value };
        case ts.SyntaxKind.EqualsEqualsToken:
        case ts.SyntaxKind.EqualsEqualsEqualsToken:
          return { kind: "boolean", value: left.value === right.value };
        case ts.SyntaxKind.ExclamationEqualsToken:
        case ts.SyntaxKind.ExclamationEqualsEqualsToken:
          return { kind: "boolean", value: left.value !== right.value };
        case ts.SyntaxKind.LessThanToken:
          return { kind: "boolean", value: left.value < right.value };
        case ts.SyntaxKind.GreaterThanToken:
          return { kind: "boolean", value: left.value > right.value };
      }
    }

    // String + number concatenation
    if (
      (left.kind === "string" && right.kind === "number") ||
      (left.kind === "number" && right.kind === "string")
    ) {
      if (op === ts.SyntaxKind.PlusToken) {
        return {
          kind: "string",
          value: this.comptimeToString(left) + this.comptimeToString(right),
        };
      }
    }

    // Boolean equality operations (&&/|| are handled above with short-circuit)
    if (left.kind === "boolean" && right.kind === "boolean") {
      switch (op) {
        case ts.SyntaxKind.EqualsEqualsToken:
        case ts.SyntaxKind.EqualsEqualsEqualsToken:
          return { kind: "boolean", value: left.value === right.value };
        case ts.SyntaxKind.ExclamationEqualsToken:
        case ts.SyntaxKind.ExclamationEqualsEqualsToken:
          return { kind: "boolean", value: left.value !== right.value };
      }
    }

    return {
      kind: "error",
      message: `Cannot apply operator ${ts.SyntaxKind[op]} to ${left.kind} and ${right.kind}`,
    };
  }

  private evaluatePrefixUnary(node: ts.PrefixUnaryExpression): ComptimeValue {
    const operand = this.evaluateNode(node.operand);
    if (operand.kind === "error") return operand;

    switch (node.operator) {
      case ts.SyntaxKind.MinusToken:
        if (operand.kind === "number") {
          return { kind: "number", value: -operand.value };
        }
        break;
      case ts.SyntaxKind.PlusToken:
        if (operand.kind === "number") {
          return { kind: "number", value: +operand.value };
        }
        break;
      case ts.SyntaxKind.ExclamationToken:
        const boolValue = this.comptimeToBoolean(operand);
        if (boolValue !== null) {
          return { kind: "boolean", value: !boolValue };
        }
        break;
      case ts.SyntaxKind.TildeToken:
        if (operand.kind === "number") {
          return { kind: "number", value: ~operand.value };
        }
        break;
    }

    return {
      kind: "error",
      message: `Cannot apply unary ${ts.SyntaxKind[node.operator]} to ${operand.kind}`,
    };
  }

  private comptimeToBoolean(value: ComptimeValue): boolean | null {
    switch (value.kind) {
      case "boolean":
        return value.value;
      case "number":
        return value.value !== 0 && !Number.isNaN(value.value);
      case "bigint":
        return value.value !== 0n;
      case "string":
        return value.value !== "";
      case "null":
      case "undefined":
        return false;
      case "array":
      case "object":
      case "function":
        return true;
      default:
        return null;
    }
  }

  private comptimeToString(value: ComptimeValue): string {
    switch (value.kind) {
      case "string":
        return value.value;
      case "number":
        return String(value.value);
      case "boolean":
        return String(value.value);
      case "bigint":
        return String(value.value); // JS: `${5n}` === "5"
      case "null":
        return "null";
      case "undefined":
        return "undefined";
      case "array":
        // JS `String([1, [2, 3], null])` → "1,2,3," (null/undefined → "")
        return value.elements
          .map((e) => (e.kind === "null" || e.kind === "undefined" ? "" : this.comptimeToString(e)))
          .join(",");
      case "object":
        return "[object Object]";
      case "function":
        return "[Function]";
      case "type":
        return "[Type]";
      case "error":
        return `[Error: ${value.message}]`;
    }
  }

  // -------------------------------------------------------------------------
  // Unique Name Generation
  // -------------------------------------------------------------------------

  generateUniqueName(prefix: string): ts.Identifier {
    // Always fresh, from the hygiene context's counters (one source of fresh
    // names, so it can't collide with mangled names), never memoised: two
    // calls with the same prefix in one expansion must not return the same
    // name (deep review core #28).
    return this.factory.createIdentifier(this.hygiene.freshName(prefix));
  }

  tryShortName(preferred: string): ts.Identifier {
    if (!this.nameConflictsWithScope(preferred)) {
      this._emittedShortNames.add(preferred);
      return this.factory.createIdentifier(preferred);
    }
    return this.generateUniqueName(preferred);
  }

  /**
   * Whether `name` is bound anywhere in the file (imports of every form, and
   * declarations/parameters/locals at ANY depth — the file binding cache's
   * conservative all-bindings set), or was already handed out as a short name.
   * Checking only top-level statements let a temp shadow a user parameter or
   * local inside a match arm (deep review core #44).
   */
  private nameConflictsWithScope(name: string): boolean {
    if (this._emittedShortNames.has(name)) return true;
    return this.fileBindingCache.isNameBound(name);
  }

  // -------------------------------------------------------------------------
  // Reference Hygiene
  // -------------------------------------------------------------------------

  safeRef(symbol: string, from: string): ts.Identifier {
    return this.fileBindingCache.safeRef(symbol, from);
  }

  ensureImport(symbol: string, from: string): ts.Identifier {
    return this.fileBindingCache.ensureImport(symbol, from);
  }

  // -------------------------------------------------------------------------
  // Helper: Convert ComptimeValue to TypeScript Expression
  // -------------------------------------------------------------------------

  comptimeValueToExpression(value: ComptimeValue): ts.Expression {
    switch (value.kind) {
      case "number":
        // Negatives/-0/NaN/Infinity are not numeric literals (deep review core #31).
        return numberToExpression(this.factory, value.value);
      case "string":
        return this.createStringLiteral(value.value);
      case "boolean":
        return this.createBooleanLiteral(value.value);
      case "bigint":
        return bigintToExpression(this.factory, value.value);
      case "null":
        return this.factory.createNull();
      case "undefined":
        return this.factory.createIdentifier("undefined");
      case "array":
        return this.createArrayLiteral(
          value.elements.map((e) => this.comptimeValueToExpression(e))
        );
      case "object":
        const props: Array<{ name: string; value: ts.Expression }> = [];
        value.properties.forEach((v, k) => {
          props.push({ name: k, value: this.comptimeValueToExpression(v) });
        });
        return this.createObjectLiteral(props);
      case "error":
        throw new Error(`Cannot convert error value to expression: ${value.message}`);
      default:
        throw new Error(`Cannot convert ${value.kind} to expression`);
    }
  }
}

/**
 * Options for creating a macro context.
 */
export interface CreateMacroContextOptions {
  /** Hygiene context for scoped identifier generation */
  hygiene?: HygieneContext;
  /** Pre-built file binding cache for reference hygiene */
  fileBindingCache?: FileBindingCache;
  /** Enable verbose logging for hygiene */
  verbose?: boolean;
}

/**
 * Create a macro context for a given program and source file.
 *
 * @param program - The TypeScript program
 * @param sourceFile - The source file being processed
 * @param transformContext - The transformation context
 * @param options - Optional configuration (hygiene context, file binding cache, verbose)
 */
export function createMacroContext(
  program: ts.Program,
  sourceFile: ts.SourceFile,
  transformContext: ts.TransformationContext,
  options?: HygieneContext | CreateMacroContextOptions
): MacroContextImpl {
  // Support legacy signature: createMacroContext(program, sourceFile, ctx, hygiene)
  if (options instanceof HygieneContext) {
    return new MacroContextImpl(
      program,
      program.getTypeChecker(),
      sourceFile,
      transformContext.factory,
      transformContext,
      options
    );
  }

  const opts = options ?? {};
  return new MacroContextImpl(
    program,
    program.getTypeChecker(),
    sourceFile,
    transformContext.factory,
    transformContext,
    opts.hygiene,
    opts.fileBindingCache,
    opts.verbose
  );
}

/**
 * Standalone markPure utility for use outside of MacroContext.
 * Use this in places without a MacroContext (e.g., the transformer itself).
 *
 * Bundlers (esbuild, webpack, Rollup) recognize this annotation on call
 * expressions and `new` expressions to indicate they have no side effects
 * and can be dropped if unused.
 */
export function markPure<T extends ts.Node>(node: T): T {
  ts.addSyntheticLeadingComment(node, ts.SyntaxKind.MultiLineCommentTrivia, "#__PURE__", false);
  return node;
}
