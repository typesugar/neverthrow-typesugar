/**
 * Typeclass declaration index (PEP-052).
 *
 * A generic, registry-free source of typeclass operator/method metadata. Given a
 * `ts.Program`, it discovers every `@typeclass`-annotated interface in scope and
 * reads each member's `@op <token>` JSDoc tags (one or more), producing a per-typeclass map from
 * operator token → method name (and the set of method names).
 *
 * This replaces the hardcoded `STANDARD_TYPECLASS_DEFS` + global `typeclassRegistry`
 * for the operator/method-resolution path: the compiler special-cases no typeclass,
 * and a third-party `@typeclass` is read identically to std's. The index caches its
 * result per `ts.Program`; watch/LSP rebuilds produce a fresh program, so the cache
 * invalidates naturally.
 *
 * @packageDocumentation
 */

import * as ts from "typescript";
import {
  extractOpsFromJSDoc,
  getStandardTypeclassOpInfos,
  buildTypeclassInfoFromInterface,
  type TypeclassInfo,
} from "./typeclass.js";

/** Operator/method metadata for a single typeclass, read from its declaration. */
export interface TypeclassOpInfo {
  /** The typeclass name (e.g., "Eq"). */
  name: string;
  /** Map from operator token (e.g., "===") to the method it dispatches to (e.g., "equals"). */
  opToMethod: Map<string, string>;
  /**
   * Map from PREFIX-UNARY operator token (e.g., "-") to the method it dispatches
   * to: an `@op` tag on a ONE-parameter member (`negate(a: A): A`). Kept apart
   * from `opToMethod` so `@op -` can name both `sub(a, b)` (binary `a - b`) and
   * `negate(a)` (unary `-a`) in the same typeclass. Optional: built-in seeds
   * declare no unary operators.
   */
  unaryOpToMethod?: Map<string, string>;
  /**
   * Binary operators whose method's RIGHT parameter is not the typeclass's type
   * parameter (`scale(a: A, k: number)`). For every other binary operator the
   * right operand must be the instance type, which operator dispatch checks.
   */
  mixedOperandOps?: Set<string>;
  /**
   * Binary operators whose method RETURNS the typeclass's type parameter
   * (`add(a: A, b: A): A`, not `equals(...): boolean`): the rewritten
   * expression has the instance type, so it can itself be the operand of a
   * further typeclass operator (`a + b + c`). Read from the declaration's
   * return type node (the parameter as written there, like `mixedOperandOps`).
   */
  selfResultOps?: Set<string>;
  /** All method names declared by the typeclass interface. */
  methodNames: Set<string>;
  /**
   * Operators that two same-named declarations mapped to DIFFERENT methods — the
   * bare name is ambiguous for these, so they are excluded from `opToMethod` and
   * yield no operator candidate (native fallback).
   */
  conflictedOps: Set<string>;
  /**
   * The full typeclass definition (methods, typeParam, fullSignatureText, …) — the
   * registry-free replacement for `typeclassRegistry.get(name)`, used by HKT
   * expansion and the public `getTypeclass`/`getTypeclasses` API (PEP-052 Phase C).
   */
  def?: TypeclassInfo;
  /**
   * Whether the typeclass is higher-kinded: its declaration (or an inherited
   * one) applies its type parameter as a type constructor (`Kind<F, ...>`).
   * Declaration-derived (PEP-052 Wave 4) — replaces the hardcoded
   * `hktTypeclassNames` table. Built-in seeds are never HKT.
   */
  isHkt: boolean;
}

const indexCache = new WeakMap<ts.Program, Map<string, TypeclassOpInfo>>();

/** Does this declaration carry a `@typeclass` JSDoc tag? */
function hasTypeclassTag(node: ts.Node): boolean {
  return ts.getJSDocTags(node).some((tag) => tag.tagName.text === "typeclass");
}

/** Read a single `@typeclass` interface declaration into a {@link TypeclassOpInfo}. */
/** The value parameters of a callable typeclass member, if it is one. */
function memberParameters(
  member: ts.TypeElement
): ts.NodeArray<ts.ParameterDeclaration> | undefined {
  if (ts.isMethodSignature(member)) return member.parameters;
  if (ts.isPropertySignature(member) && member.type && ts.isFunctionTypeNode(member.type)) {
    return member.type.parameters;
  }
  return undefined;
}

function readTypeclassInterface(iface: ts.InterfaceDeclaration): TypeclassOpInfo {
  const opToMethod = new Map<string, string>();
  const unaryOpToMethod = new Map<string, string>();
  const mixedOperandOps = new Set<string>();
  const selfResultOps = new Set<string>();
  const methodNames = new Set<string>();
  const typeParamName = iface.typeParameters?.[0]?.name.text;
  /** `t` is the type parameter itself, as written (`A`, no type arguments). */
  const isSelf = (t: ts.TypeNode | undefined): boolean =>
    !!t &&
    !!typeParamName &&
    ts.isTypeReferenceNode(t) &&
    ts.isIdentifier(t.typeName) &&
    t.typeName.text === typeParamName &&
    !t.typeArguments;

  for (const member of iface.members) {
    if (!member.name || !ts.isIdentifier(member.name)) continue;
    const methodName = member.name.text;
    methodNames.add(methodName);

    // A member may carry several `@op` tags (equivalent spellings such as
    // `@op ===` + `@op ==` on Eq.equals); each maps to this member.
    const ops = extractOpsFromJSDoc(member);
    if (ops.length === 0) continue;
    const params = memberParameters(member);
    if (params && params.length === 1) {
      // `/** @op - */ negate(a: A): A` -- the prefix-unary form `-a`.
      for (const op of ops) unaryOpToMethod.set(op, methodName);
      continue;
    }
    const rightIsSelf = isSelf(params?.[1]?.type);
    const resultType = ts.isMethodSignature(member)
      ? member.type
      : ts.isPropertySignature(member) && member.type && ts.isFunctionTypeNode(member.type)
        ? member.type.type
        : undefined;
    const resultIsSelf = isSelf(resultType);
    for (const op of ops) {
      opToMethod.set(op, methodName);
      if (params && params.length >= 2 && !rightIsSelf) mixedOperandOps.add(op);
      if (resultIsSelf) selfResultOps.add(op);
    }
  }

  const def = buildTypeclassInfoFromInterface(iface);

  return {
    name: iface.name.text,
    opToMethod,
    unaryOpToMethod,
    mixedOperandOps,
    selfResultOps,
    methodNames,
    conflictedOps: new Set(),
    def,
    // Direct Kind<F, ...> usage only; buildIndex's finalize pass folds in
    // heritage (a typeclass extending an HKT typeclass is itself HKT).
    isHkt: def?.usesKind ?? false,
  };
}

/** Build (and cache) the typeclass index for a program. */
function buildIndex(program: ts.Program): Map<string, TypeclassOpInfo> {
  const cached = indexCache.get(program);
  if (cached) return cached;

  const index = new Map<string, TypeclassOpInfo>();

  // Seed with the built-in standard typeclass metadata (plain static data) so
  // standard typeclasses (Eq/Ord/Show/…) resolve even when their interface isn't
  // in the program's source. Source `@typeclass` interfaces below merge over this.
  for (const info of getStandardTypeclassOpInfos()) {
    index.set(info.name, {
      name: info.name,
      opToMethod: new Map(info.opToMethod),
      methodNames: new Set(info.methodNames),
      conflictedOps: new Set(),
      def: info.def,
      isHkt: false,
    });
  }

  // Names that came from the built-in seed. The FIRST source `@typeclass`
  // declaration of such a name is authoritative and REPLACES the seed (rather than
  // merging) — otherwise the built-in `Eq` would mask/conflict with a user `Eq`
  // that maps the same operator to a different method. Subsequent same-name source
  // declarations then merge against the (now source-authoritative) entry.
  const seededNames = new Set(index.keys());

  for (const sourceFile of program.getSourceFiles()) {
    // Default lib files (lib.es*.d.ts) never carry @typeclass — skip the scan cost.
    if (program.isSourceFileDefaultLibrary(sourceFile)) continue;
    // Cheap text pre-filter: most files (all of @types, most of node_modules)
    // carry no @typeclass tag — skip the per-statement JSDoc walks entirely.
    if (!sourceFile.text.includes("@typeclass")) continue;

    for (const stmt of sourceFile.statements) {
      if (!ts.isInterfaceDeclaration(stmt)) continue;
      if (!hasTypeclassTag(stmt)) continue;

      const info = readTypeclassInterface(stmt);
      if (seededNames.has(info.name)) {
        // First source declaration overrides the built-in seed.
        index.set(info.name, info);
        seededNames.delete(info.name);
        continue;
      }
      const existing = index.get(info.name);
      if (existing) {
        // Same-named typeclass declared in multiple modules (e.g. std `Eq` vs a
        // third-party `Eq`). Union the method names. For op→method mappings: if the
        // two declarations AGREE, keep it; if they CONFLICT (map the same operator
        // to different methods), the bare name is ambiguous — drop that op entirely
        // so the operator falls back to native rather than emitting a call to a
        // method the resolved instance may not implement (silent miscompile).
        // A fully correct fix keys activation by declaring module, not bare name.
        for (const [op, method] of info.opToMethod) {
          if (existing.conflictedOps.has(op)) continue;
          const prev = existing.opToMethod.get(op);
          if (prev === undefined) {
            existing.opToMethod.set(op, method);
          } else if (prev !== method) {
            existing.opToMethod.delete(op);
            existing.conflictedOps.add(op);
          }
        }
        // Unary operators: same agree/conflict rule, tracked under a "unary "
        // key prefix so a unary conflict never hides the binary mapping.
        for (const [op, method] of info.unaryOpToMethod ?? []) {
          const key = `unary ${op}`;
          if (existing.conflictedOps.has(key)) continue;
          const unary = (existing.unaryOpToMethod ??= new Map());
          const prev = unary.get(op);
          if (prev === undefined) {
            unary.set(op, method);
          } else if (prev !== method) {
            unary.delete(op);
            existing.conflictedOps.add(key);
          }
        }
        for (const op of info.mixedOperandOps ?? []) {
          (existing.mixedOperandOps ??= new Set()).add(op);
        }
        for (const op of info.selfResultOps ?? []) {
          (existing.selfResultOps ??= new Set()).add(op);
        }
        for (const m of info.methodNames) existing.methodNames.add(m);
      } else {
        index.set(info.name, info);
      }
    }
  }

  finalizeHeritage(index);

  indexCache.set(program, index);
  return index;
}

const signaturePrinter = ts.createPrinter({ removeComments: true });

const IDENTIFIER_RE = /^[A-Za-z_$][A-Za-z0-9_$]*$/;

/**
 * Positionally substitute a parent's type parameter names with the child's
 * type arguments, as an AST transformation (PEP-052 Wave 4 review fix — the
 * original regex rewrite had no scope awareness): a `TypeReferenceNode` to a
 * renamed parameter is updated UNLESS a nested declaration (a member-level
 * type parameter like `coerce<F>(x: F): F`) shadows the name. Returns the
 * transformed node; the caller prints it once.
 */
function substituteTypeParamsInMember(
  member: ts.TypeElement,
  renames: ReadonlyMap<string, string>
): ts.TypeElement {
  const result = ts.transform(member, [
    (context) => {
      const visit = (node: ts.Node, shadowed: ReadonlySet<string>): ts.Node => {
        let scope = shadowed;
        const tps = (node as { typeParameters?: readonly ts.TypeParameterDeclaration[] })
          .typeParameters;
        if (tps && tps.length > 0) {
          const s = new Set(shadowed);
          for (const tp of tps) s.add(tp.name.text);
          scope = s;
        }
        if (
          ts.isTypeReferenceNode(node) &&
          ts.isIdentifier(node.typeName) &&
          renames.has(node.typeName.text) &&
          !scope.has(node.typeName.text)
        ) {
          const renamed = context.factory.createIdentifier(renames.get(node.typeName.text)!);
          const visitedArgs = node.typeArguments
            ? (node.typeArguments.map((a) => visit(a, scope) as ts.TypeNode) as ts.TypeNode[])
            : undefined;
          return context.factory.updateTypeReferenceNode(
            node,
            renamed,
            visitedArgs ? context.factory.createNodeArray(visitedArgs) : undefined
          );
        }
        return ts.visitEachChild(node, (n) => visit(n, scope), context);
      };
      return (n: ts.Node) => visit(n, new Set()) as ts.TypeElement;
    },
  ]);
  const transformed = result.transformed[0];
  result.dispose();
  return transformed;
}

/**
 * Print a member signature for inclusion in `fullSignatureText`. Printed
 * against the member's ORIGINAL source file (transformed subtrees are
 * synthesized and print positionlessly; untouched subtrees fall back to the
 * original text). A single trailing `;`/`,` is trimmed so the caller can join
 * uniformly.
 */
function printMember(member: ts.TypeElement, sourceFile: ts.SourceFile): string {
  const text = signaturePrinter.printNode(ts.EmitHint.Unspecified, member, sourceFile).trim();
  return text.endsWith(";") || text.endsWith(",") ? text.slice(0, -1) : text;
}

/**
 * Resolve `extends` heritage across the indexed `@typeclass` declarations
 * (PEP-052 Wave 4):
 *
 * - `isHkt` propagates: a typeclass extending an HKT typeclass with its own
 *   type parameter in the Kind-bearing (first) position is itself HKT
 *   (`Monad<F> extends FlatMap<F>, Applicative<F> {}` is HKT even though its
 *   own body is empty).
 * - `fullSignatureText` is flattened: inherited member signatures are folded in
 *   (with positional type-parameter substitution) so HKT expansion of e.g.
 *   `Monad<Option>` produces the full map/flatMap/pure/ap structural type, not
 *   just the empty child body. Child members override same-named parents;
 *   diamond parents (Monad → FlatMap/Applicative → Apply → Functor) dedupe by
 *   member name.
 *
 * Own-member metadata (`opToMethod`, `methodNames`) is deliberately NOT
 * flattened — operator/method-sugar activation semantics are unchanged.
 */
function finalizeHeritage(index: Map<string, TypeclassOpInfo>): void {
  type FlatMember = { name: string; node: ts.TypeElement; sourceFile: ts.SourceFile };
  type Flat = { members: FlatMember[]; isHkt: boolean };
  const memo = new Map<string, Flat>();

  function ownMembers(def: NonNullable<TypeclassOpInfo["def"]>): FlatMember[] {
    return (def.memberEntries ?? []).map((m) => ({
      name: m.name,
      node: m.node,
      sourceFile: m.node.getSourceFile(),
    }));
  }

  function flatten(name: string, visiting: Set<string>): Flat {
    const cached = memo.get(name);
    if (cached) return cached;

    const def = index.get(name)?.def;
    // Unknown parent, built-in seed, or cycle: nothing to inherit.
    if (!def?.memberEntries || visiting.has(name)) {
      return { members: def ? ownMembers(def) : [], isHkt: def?.usesKind ?? false };
    }

    visiting.add(name);
    const members = ownMembers(def);
    const seen = new Set(members.map((m) => m.name));
    let isHkt = def.usesKind === true;

    for (const h of def.heritage ?? []) {
      const parentDef = index.get(h.name)?.def;
      if (!parentDef) continue;
      const parentFlat = flatten(h.name, visiting);
      const parentParams = parentDef.typeParams ?? [parentDef.typeParam];
      // Rename map for this heritage edge, built once. Only identifier
      // arguments can be applied as an AST rename; a non-identifier argument
      // (no known occurrence — heritage args are type params like `F`) makes
      // the substitution unrepresentable as a rename, so those parents'
      // members are conservatively skipped rather than mangled.
      const renames = new Map<string, string>();
      let renamable = true;
      parentParams.forEach((param, i) => {
        const arg = h.typeArgs[i];
        if (!arg || arg === param) return;
        if (!IDENTIFIER_RE.test(arg)) renamable = false;
        renames.set(param, arg);
      });
      if (!renamable) continue;
      for (const m of parentFlat.members) {
        if (seen.has(m.name)) continue;
        seen.add(m.name);
        members.push({
          name: m.name,
          node: renames.size > 0 ? substituteTypeParamsInMember(m.node, renames) : m.node,
          sourceFile: m.sourceFile,
        });
      }
      // HKT-ness inherits only when the child passes its own type param where
      // the parent's (first, Kind-bearing) type param goes.
      if (parentFlat.isHkt && h.typeArgs[0] === def.typeParam) isHkt = true;
    }
    visiting.delete(name);

    const flat: Flat = { members, isHkt };
    memo.set(name, flat);
    return flat;
  }

  for (const [name, info] of index) {
    if (!info.def?.memberEntries) continue; // built-in seed — leave untouched
    const flat = flatten(name, new Set());
    info.isHkt = flat.isHkt;
    if (flat.members.length > 0) {
      info.def.fullSignatureText = `{ ${flat.members
        .map((m) => printMember(m.node, m.sourceFile))
        .join("; ")} }`;
    }
  }
}

/**
 * Whether the named typeclass is higher-kinded, derived from its `@typeclass`
 * declaration in the program: some member signature (own or inherited) applies
 * the interface's type parameter as a type constructor (`Kind<F, ...>`).
 * Registry-free replacement for the hardcoded `hktTypeclassNames` set.
 */
export function isHktTypeclass(program: ts.Program, tcName: string): boolean {
  return buildIndex(program).get(tcName)?.isHkt ?? false;
}

/**
 * Get the operator/method metadata for a typeclass by name, read generically from
 * its `@typeclass` declaration in the program. Returns `undefined` if no such
 * typeclass is declared.
 */
export function getOpMapForTypeclass(
  program: ts.Program,
  tcName: string
): TypeclassOpInfo | undefined {
  return buildIndex(program).get(tcName);
}

/**
 * Among a set of activated typeclasses, find those whose declaration maps the
 * given operator token, returning `{ typeclass, method }` candidates. This is the
 * registry-free replacement for `getSyntaxForOperator`, scoped to the typeclasses
 * the using file actually activated via `@syntax-operators` imports.
 *
 * `arity` selects the binary (`a - b`, two-parameter method) or prefix-unary
 * (`-a`, one-parameter method) mapping. `rightOperandIsSelf` says whether the
 * method's right parameter is the typeclass's type parameter, i.e. whether the
 * right operand must be the instance type for the dispatch to be well-typed.
 * `resultIsSelf` says whether the method returns the type parameter (see
 * {@link TypeclassOpInfo.selfResultOps}).
 */
export function getOperatorCandidates(
  program: ts.Program,
  activatedTypeclasses: Iterable<string>,
  op: string,
  arity: "binary" | "unary" = "binary"
): Array<{
  typeclass: string;
  method: string;
  rightOperandIsSelf: boolean;
  resultIsSelf: boolean;
}> {
  const candidates: Array<{
    typeclass: string;
    method: string;
    rightOperandIsSelf: boolean;
    resultIsSelf: boolean;
  }> = [];
  for (const tc of activatedTypeclasses) {
    const info = getOpMapForTypeclass(program, tc);
    if (!info) continue;
    const method = arity === "unary" ? info.unaryOpToMethod?.get(op) : info.opToMethod.get(op);
    if (method) {
      candidates.push({
        typeclass: tc,
        method,
        rightOperandIsSelf: arity === "binary" && !info.mixedOperandOps?.has(op),
        resultIsSelf: arity === "binary" && !!info.selfResultOps?.has(op),
      });
    }
  }
  return candidates;
}

/**
 * The complement of {@link getOperatorCandidates}: every typeclass in the
 * program's index (source `@typeclass` declarations + built-in seeds) that maps
 * the operator but is NOT in `activatedTypeclasses`. Used only for the TS9804
 * "operator syntax not activated" hint, which must agree exactly with what
 * {@link getOperatorCandidates} would return once the file activated the
 * typeclass — hence the same per-typeclass lookup, over the other names.
 */
export function getInactiveOperatorCandidates(
  program: ts.Program,
  activatedTypeclasses: ReadonlySet<string>,
  op: string,
  arity: "binary" | "unary" = "binary"
): Array<{ typeclass: string; method: string; rightOperandIsSelf: boolean }> {
  const inactive: string[] = [];
  for (const name of buildIndex(program).keys()) {
    if (!activatedTypeclasses.has(name)) inactive.push(name);
  }
  return getOperatorCandidates(program, inactive, op, arity);
}

/**
 * Among a set of activated typeclasses, find those whose declaration declares the
 * given method name, returning `{ typeclass, method }` candidates. Registry-free
 * replacement for `getTypeclassesForMethod`, scoped to activated method syntax.
 */
export function getMethodCandidates(
  program: ts.Program,
  activatedTypeclasses: Iterable<string>,
  methodName: string
): Array<{ typeclass: string; method: string }> {
  const candidates: Array<{ typeclass: string; method: string }> = [];
  for (const tc of activatedTypeclasses) {
    const info = getOpMapForTypeclass(program, tc);
    if (info?.methodNames.has(methodName)) candidates.push({ typeclass: tc, method: methodName });
  }
  return candidates;
}

/**
 * Find EVERY `@typeclass` in the program that declares a method with the given
 * name. This is the registry-free replacement for `getTypeclassesForMethod`
 * (which scanned the global `typeclassRegistry`). Unscoped by design — used by
 * the `extend()` macro, a NAMED trigger that self-activates via its own explicit
 * import (PEP-052's two-trigger-class rule), so it needs no separate
 * `@syntax-methods` gate. Instance-method sugar (`p.equals(q)`) is a distinct,
 * syntactic-trigger path and uses the scoped `getMethodCandidates` instead
 * (Phase E).
 */
export function getTypeclassesDeclaringMethod(
  program: ts.Program,
  methodName: string
): Array<{ typeclass: string; method: string }> {
  const candidates: Array<{ typeclass: string; method: string }> = [];
  for (const info of buildIndex(program).values()) {
    if (info.methodNames.has(methodName)) {
      candidates.push({ typeclass: info.name, method: methodName });
    }
  }
  return candidates;
}

/**
 * Get the full definition of a typeclass by name, read from its `@typeclass`
 * declaration in the program (or the built-in seed). Registry-free replacement for
 * `typeclassRegistry.get(name)` — used by HKT expansion (`fullSignatureText`).
 */
export function getTypeclassDef(program: ts.Program, tcName: string): TypeclassInfo | undefined {
  return buildIndex(program).get(tcName)?.def;
}

/** Whether a typeclass with the given name is declared/seeded for the program. */
export function isTypeclassDeclared(program: ts.Program, tcName: string): boolean {
  return buildIndex(program).has(tcName);
}
