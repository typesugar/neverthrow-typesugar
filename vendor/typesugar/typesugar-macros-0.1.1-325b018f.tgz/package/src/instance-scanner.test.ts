/**
 * Tests for InstanceScanner (PEP-038 Wave 2A).
 *
 * Verifies that the scanner discovers typeclass instances from module exports
 * via @impl JSDoc tags and type annotations.
 */

import { describe, it, expect, afterEach } from "vitest";
import * as ts from "typescript";
import * as fs from "fs";
import * as path from "path";
import * as os from "os";
import {
  InstanceScanner,
  parseDoMethodsTag,
  DEFAULT_DO_METHODS,
  type ScannedInstance,
} from "./instance-scanner.js";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

interface TestModule {
  program: ts.Program;
  typeChecker: ts.TypeChecker;
  moduleSymbol: ts.Symbol;
  resolvedPath: string;
  cleanup: () => void;
}

const cleanups: (() => void)[] = [];

afterEach(() => {
  for (const fn of cleanups) fn();
  cleanups.length = 0;
});

/**
 * Create a real ts.Program from source so we get a working TypeChecker.
 * Overrides getSourceFile to re-parse with setParentNodes=true so JSDoc
 * tags are visible (TypeScript 5.3+ optimization workaround).
 */
function createTestModule(source: string, fileName = "test-module.ts"): TestModule {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "scanner-test-"));
  const filePath = path.join(tmpDir, fileName);
  fs.writeFileSync(filePath, source);

  const options: ts.CompilerOptions = {
    target: ts.ScriptTarget.ES2020,
    module: ts.ModuleKind.ESNext,
    moduleResolution: ts.ModuleResolutionKind.Bundler,
    strict: true,
    noEmit: true,
  };

  const host = ts.createCompilerHost(options);
  const origGetSourceFile = host.getSourceFile.bind(host);
  host.getSourceFile = (fn, languageVersion, onError, shouldCreate) => {
    const sf = origGetSourceFile(fn, languageVersion, onError, shouldCreate);
    if (sf && fn === filePath) {
      // Re-parse with setParentNodes=true for JSDoc tag visibility
      return ts.createSourceFile(fn, sf.text, languageVersion, true);
    }
    return sf;
  };

  const program = ts.createProgram([filePath], options, host);
  const typeChecker = program.getTypeChecker();
  const sourceFile = program.getSourceFile(filePath)!;
  const moduleSymbol = typeChecker.getSymbolAtLocation(sourceFile)!;

  const cleanup = () => fs.rmSync(tmpDir, { recursive: true, force: true });
  cleanups.push(cleanup);

  return { program, typeChecker, moduleSymbol, resolvedPath: filePath, cleanup };
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("InstanceScanner", () => {
  it("detects @impl JSDoc tag", () => {
    const mod = createTestModule(`
/** @impl("Ord<number>") */
export const ordNumber = {
  compare: (a: number, b: number): number => (a < b ? -1 : a > b ? 1 : 0),
};
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results).toHaveLength(1);
    expect(results[0]).toMatchObject({
      typeclassName: "Ord",
      forTypeString: "number",
      exportName: "ordNumber",
      detectedVia: "impl-tag",
    });
  });

  it("detects type annotation fallback", () => {
    const mod = createTestModule(`
interface Ord<A> { compare(a: A, b: A): number; }
export const ordNumber: Ord<number> = {
  compare: (a: number, b: number): number => (a < b ? -1 : a > b ? 1 : 0),
};
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results).toHaveLength(1);
    expect(results[0]).toMatchObject({
      typeclassName: "Ord",
      forTypeString: "number",
      exportName: "ordNumber",
      detectedVia: "type-annotation",
    });
  });

  it("@impl tag takes precedence over type annotation", () => {
    const mod = createTestModule(`
interface Show<A> { show(a: A): string; }
/** @impl("Show<number>") */
export const showNumber: Show<number> = {
  show: (a: number): string => String(a),
};
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results).toHaveLength(1);
    expect(results[0].detectedVia).toBe("impl-tag");
  });

  it("ignores plain exports without annotations", () => {
    const mod = createTestModule(`
export const PI = 3.14159;
export const greeting = "hello";
export function add(a: number, b: number) { return a + b; }
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results).toHaveLength(0);
  });

  it("ignores function exports (generic factories)", () => {
    const mod = createTestModule(`
export function showArray<A>(elementShow: { show: (a: A) => string }) {
  return {
    show: (arr: A[]): string => arr.map(x => elementShow.show(x)).join(", "),
  };
}
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results).toHaveLength(0);
  });

  it("caches results and clearCache forces re-scan", () => {
    const mod = createTestModule(`
/** @impl("Eq<number>") */
export const eqNumber = { eq: (a: number, b: number): boolean => a === b };
    `);

    const scanner = new InstanceScanner();
    const first = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);
    const second = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    // Same reference — cache hit
    expect(second).toBe(first);

    scanner.clearCache();
    const third = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    // Different reference — re-scanned
    expect(third).not.toBe(first);
    // But same content
    expect(third).toEqual(first);
  });

  it("finds multiple annotated exports", () => {
    const mod = createTestModule(`
/** @impl("Show<number>") */
export const showNumber = { show: (a: number): string => String(a) };

/** @impl("Eq<number>") */
export const eqNumber = { eq: (a: number, b: number): boolean => a === b };

/** @impl("Ord<string>") */
export const ordString = { compare: (a: string, b: string): number => a.localeCompare(b) };
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results).toHaveLength(3);
    const names = results.map((r) => r.exportName).sort();
    expect(names).toEqual(["eqNumber", "ordString", "showNumber"]);
  });

  it("handles nested generics in @impl tag", () => {
    const mod = createTestModule(`
/** @impl("Numeric<Expression<number>>") */
export const numericExprNumber = { add: (a: any, b: any) => a };
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results).toHaveLength(1);
    expect(results[0]).toMatchObject({
      typeclassName: "Numeric",
      forTypeString: "Expression<number>",
    });
  });

  it("handles @instance tag synonym", () => {
    const mod = createTestModule(`
/** @instance("Hash<string>") */
export const hashString = { hash: (a: string): number => a.length };
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results).toHaveLength(1);
    expect(results[0]).toMatchObject({
      typeclassName: "Hash",
      forTypeString: "string",
      detectedVia: "impl-tag",
    });
  });

  it("returns empty array for module with no exports", () => {
    const mod = createTestModule(`
const internal = 42;
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results).toHaveLength(0);
  });

  it("follows re-exports to their original declarations", () => {
    // Create two files: provider.ts exports instances, consumer.ts re-exports them
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "scanner-reexport-"));
    cleanups.push(() => fs.rmSync(tmpDir, { recursive: true, force: true }));

    const providerPath = path.join(tmpDir, "provider.ts");
    fs.writeFileSync(
      providerPath,
      `
/** @impl("Ord<number>") */
export const ordNumber = { compare: (a: number, b: number): number => a < b ? -1 : a > b ? 1 : 0 };
    `
    );

    const consumerPath = path.join(tmpDir, "consumer.ts");
    fs.writeFileSync(
      consumerPath,
      `
export { ordNumber } from "./provider.js";
    `
    );

    const options: ts.CompilerOptions = {
      target: ts.ScriptTarget.ES2020,
      module: ts.ModuleKind.ESNext,
      moduleResolution: ts.ModuleResolutionKind.Bundler,
      strict: true,
      noEmit: true,
    };

    const host = ts.createCompilerHost(options);
    const origGetSourceFile = host.getSourceFile.bind(host);
    host.getSourceFile = (fn, languageVersion, onError, shouldCreate) => {
      const sf = origGetSourceFile(fn, languageVersion, onError, shouldCreate);
      if (sf && (fn === providerPath || fn === consumerPath)) {
        return ts.createSourceFile(fn, sf.text, languageVersion, true);
      }
      return sf;
    };

    const program = ts.createProgram([consumerPath, providerPath], options, host);
    const typeChecker = program.getTypeChecker();
    const consumerSF = program.getSourceFile(consumerPath)!;
    const consumerSymbol = typeChecker.getSymbolAtLocation(consumerSF)!;

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(typeChecker, consumerSymbol, consumerPath);

    // Re-exported symbols should be discovered by following to the original declaration
    expect(results).toHaveLength(1);
    expect(results[0]).toMatchObject({
      typeclassName: "Ord",
      forTypeString: "number",
      exportName: "ordNumber",
    });
  });

  it("discovers all 28 @impl-tagged instances in primitives.ts", () => {
    // Integration test: scan the actual primitives.ts source file
    const primitivesPath = path.resolve(__dirname, "primitives.ts");
    const source = fs.readFileSync(primitivesPath, "utf-8");

    const options: ts.CompilerOptions = {
      target: ts.ScriptTarget.ES2020,
      module: ts.ModuleKind.ESNext,
      moduleResolution: ts.ModuleResolutionKind.Bundler,
      strict: true,
      noEmit: true,
    };

    const host = ts.createCompilerHost(options);
    const origGetSourceFile = host.getSourceFile.bind(host);
    host.getSourceFile = (fn, languageVersion, onError, shouldCreate) => {
      if (fn === primitivesPath) {
        return ts.createSourceFile(fn, source, languageVersion, true);
      }
      return origGetSourceFile(fn, languageVersion, onError, shouldCreate);
    };

    // primitives.ts imports from ./typeclass.js — stub it to avoid resolution errors
    const stubPath = path.resolve(__dirname, "typeclass.ts");
    host.fileExists = (fn) => fn === primitivesPath || fn === stubPath || ts.sys.fileExists(fn);

    const program = ts.createProgram([primitivesPath], options, host);
    const typeChecker = program.getTypeChecker();
    const sourceFile = program.getSourceFile(primitivesPath)!;
    const moduleSymbol = typeChecker.getSymbolAtLocation(sourceFile)!;

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(typeChecker, moduleSymbol, primitivesPath);

    // Verify all 28 tagged instances are found
    expect(results.length).toBe(28);

    // Verify all detectedVia are "impl-tag"
    expect(results.every((r) => r.detectedVia === "impl-tag")).toBe(true);

    // Spot check a few
    const byName = new Map(results.map((r) => [r.exportName, r]));
    expect(byName.get("ordNumber")).toMatchObject({
      typeclassName: "Ord",
      forTypeString: "number",
    });
    expect(byName.get("showString")).toMatchObject({
      typeclassName: "Show",
      forTypeString: "string",
    });
    expect(byName.get("eqBigint")).toMatchObject({ typeclassName: "Eq", forTypeString: "bigint" });
    expect(byName.get("hashNull")).toMatchObject({ typeclassName: "Hash", forTypeString: "null" });
    expect(byName.get("monoidBoolean")).toMatchObject({
      typeclassName: "Monoid",
      forTypeString: "boolean",
    });

    // Verify variants are NOT included
    expect(byName.has("semigroupNumberProduct")).toBe(false);
    expect(byName.has("monoidBooleanAny")).toBe(false);

    // Verify namespace objects are NOT included
    expect(byName.has("Show")).toBe(false);
    expect(byName.has("Eq")).toBe(false);
  });
});

describe("@do-methods metadata (PEP-052 Wave 3)", () => {
  it("parses key=value pairs and attaches doMeta to the scanned instance", () => {
    const mod = createTestModule(`
/**
 * @impl FlatMap<Promise>
 * @do-methods bind=then map=then orElse=catch
 */
export const flatMapPromise = { flatMap: (fa: any, f: any) => fa.then(f) };
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results).toHaveLength(1);
    expect(results[0].doMeta).toEqual({
      bind: "then",
      map: "then",
      orElse: "catch",
      style: "method",
    });
  });

  it("parses style=static receiver=... for static-call emission", () => {
    const mod = createTestModule(`
/**
 * @impl FlatMap<Effect>
 * @do-methods bind=flatMap map=map orElse=catchAll style=static receiver=Effect
 */
export const flatMapEffect = {};
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results[0].doMeta).toEqual({
      bind: "flatMap",
      map: "map",
      orElse: "catchAll",
      style: "static",
      receiver: "Effect",
    });
  });

  it("leaves doMeta undefined when the tag is absent (defaults applied by consumers)", () => {
    const mod = createTestModule(`
/** @impl FlatMap<Array> */
export const flatMapArray = {};
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results[0].doMeta).toBeUndefined();
    expect(DEFAULT_DO_METHODS).toEqual({ bind: "flatMap", map: "map", style: "method" });
  });

  it("captures unknown keys and malformed pairs as unrecognized (warned at use sites)", () => {
    const sf = ts.createSourceFile(
      "x.ts",
      `/**
 * @do-methods bind=chain frobnicate=yes =bad noequals map=select style=statik
 */
const inst = {};`,
      ts.ScriptTarget.Latest,
      true
    );
    const meta = parseDoMethodsTag(sf.statements[0]);
    expect(meta).toEqual({
      bind: "chain",
      map: "select",
      style: "method",
      unrecognized: ["frobnicate=yes", "=bad", "noequals", "style=statik"],
    });
  });
});

describe("resolveTypeString keyword resolution (PEP-052 Wave 5 review fix)", () => {
  // On some ts.TypeChecker instances, resolving a keyword type via an
  // unbound synthetic node (ts.factory.createKeywordTypeNode +
  // getTypeFromTypeNode) silently returns `any` instead of the keyword's own
  // type — and `any` is bidirectionally assignable to/from everything, so
  // two DIFFERENT type-annotated instances (e.g. `Show<symbol>` and
  // `Show<number>`) would incorrectly resolve to the "same" forType and be
  // reported as an ambiguous instance pair. Exercised end-to-end (not just
  // resolveTypeString in isolation) because the bug is specifically about
  // cross-instance type MATCHING, not single-type resolution.
  it("does not conflate `symbol`, `unknown`, `object`, and `number` typed instances with each other", () => {
    const mod = createTestModule(`
/** @impl Ord<symbol> */
export const ordSymbol = { compare: (a: symbol, b: symbol) => 0 };
/** @impl Ord<unknown> */
export const ordUnknown = { compare: (a: unknown, b: unknown) => 0 };
/** @impl Ord<object> */
export const ordObject = { compare: (a: object, b: object) => 0 };
/** @impl Ord<number> */
export const ordNumber = { compare: (a: number, b: number) => 0 };
    `);

    const scanner = new InstanceScanner();
    const results = scanner.scanModule(mod.typeChecker, mod.moduleSymbol, mod.resolvedPath);

    expect(results).toHaveLength(4);
    const bySymbolName = new Map(results.map((r) => [r.exportName, r]));
    // Every instance must resolve to a DEFINED forType — not just "not Any".
    // A keyword silently regressing to `undefined` (e.g. an internal
    // TypeChecker getter disappearing in a future TS version, falling into
    // the any-guard's undefined return) would pass a weaker "falsy-Any"
    // check while the instance quietly becomes unresolvable in production.
    for (const r of results) {
      expect(r.forType, `${r.exportName} must resolve to a concrete type`).toBeDefined();
      expect(r.forType!.flags & ts.TypeFlags.Any).toBe(0);
    }
    // And each instance's resolved forType must be distinct — none should
    // have silently collapsed to `any` or to each other.
    const forTypes = new Set(results.map((r) => bySymbolName.get(r.exportName)!.forType));
    expect(forTypes.size).toBe(4);
  });
});

describe("@derive companions of an exported type (a library's instances)", () => {
  it("in a .d.ts: each companion member the @derive tag names, typed by the type itself", () => {
    const mod = createTestModule(
      `/** @derive(Eq, Ord) */
export interface Point { x: number; y: number }
export declare namespace Point {
  const Eq: { equals: (a: Point, b: Point) => boolean };
}
`,
      "lib.d.ts"
    );
    const results = new InstanceScanner().scanModule(
      mod.typeChecker,
      mod.moduleSymbol,
      mod.resolvedPath
    );
    // Ord is named but has no member (its derive failed): not an instance.
    expect(results).toHaveLength(1);
    expect(results[0]).toMatchObject({
      typeclassName: "Eq",
      exportName: "Point.Eq",
      forTypeString: "Point",
      detectedVia: "derived",
    });
    const sf = mod.program.getSourceFile(mod.resolvedPath)!;
    const pointSym = mod.typeChecker.getSymbolAtLocation(
      (sf.statements[0] as ts.InterfaceDeclaration).name
    )!;
    expect(results[0].forType).toBe(mod.typeChecker.getDeclaredTypeOfSymbol(pointSym));
  });

  it("in a .d.ts: a namespace member's own @impl tag (the decorator form leaves no @derive)", () => {
    const mod = createTestModule(
      `export declare class Money { amount: number }
export declare namespace Money {
  /** @impl Eq<Money> */
  const Eq: { equals: (a: Money, b: Money) => boolean };
  const notAnInstance: number;
}
`,
      "money.d.ts"
    );
    const results = new InstanceScanner().scanModule(
      mod.typeChecker,
      mod.moduleSymbol,
      mod.resolvedPath
    );
    expect(results).toEqual([
      expect.objectContaining({
        typeclassName: "Eq",
        exportName: "Money.Eq",
        forTypeString: "Money",
      }),
    ]);
    expect(results[0].forType).toBeDefined();
  });

  it("a .d.ts with both the @derive tag and the member's @impl tag: one instance", () => {
    const mod = createTestModule(
      `/** @derive(Eq) */
export interface Point { x: number }
export declare namespace Point {
  /** @impl Eq<Point> */
  const Eq: { equals: (a: Point, b: Point) => boolean };
}
`,
      "both.d.ts"
    );
    const results = new InstanceScanner().scanModule(
      mod.typeChecker,
      mod.moduleSymbol,
      mod.resolvedPath
    );
    expect(results.map((r) => r.exportName)).toEqual(["Point.Eq"]);
  });

  it("in source: the companion a GenericDerivation will generate (it doesn't exist yet)", () => {
    const mod = createTestModule(`
import type { Eq } from "typesugar";
/** @derive(Eq, NotATypeclass) */
export interface Point { x: number }
/**
 * Docs only:
 * \`\`\`
 * @derive(Ord)
 * \`\`\`
 */
export interface Other { y: number }
`);
    const results = new InstanceScanner().scanModule(
      mod.typeChecker,
      mod.moduleSymbol,
      mod.resolvedPath
    );
    expect(results.map((r) => `${r.typeclassName}:${r.exportName}`)).toEqual(["Eq:Point.Eq"]);
  });

  it("a function whose JSDoc shows an @impl example is not an instance", () => {
    const mod = createTestModule(`
/**
 * Register an instance:
 * \`\`\`typescript
 * /** @impl Eq<Point> *\\/
 * export const pointEq = { ... };
 * \`\`\`
 */
export declare function impl<T>(desc: string, body: T): T;
`);
    const results = new InstanceScanner().scanModule(
      mod.typeChecker,
      mod.moduleSymbol,
      mod.resolvedPath
    );
    expect(results).toEqual([]);
  });
});

describe("scanLocalDeriveCompanions: a checker failure is reported, not swallowed", () => {
  it("calls onCheckerFailure with the declaration it skipped", () => {
    const mod = createTestModule(
      `/** @derive(Eq) */\nexport interface P { x: number }\nexport const n = 1;\n`
    );
    cleanups.push(mod.cleanup);
    const sf = mod.program.getSourceFile(mod.resolvedPath)!;
    // A checker whose symbol lookup throws (CLAUDE.md: synthetic nodes and
    // checker bugs do this in production).
    const throwing = new Proxy(mod.typeChecker, {
      get(target, prop, receiver) {
        if (prop === "getSymbolAtLocation") {
          return () => {
            throw new Error("start < 0");
          };
        }
        return Reflect.get(target, prop, receiver);
      },
    });
    const failures: string[] = [];
    const result = new InstanceScanner().scanLocalDeriveCompanions(
      throwing,
      sf,
      mod.program,
      (node, error) => failures.push(`${node.getText()}: ${String(error)}`)
    );
    expect(result).toEqual([]);
    expect(failures).toEqual(["P: Error: start < 0"]);
  });
});

describe("every checker failure in a scan is reported, once (CLAUDE.md caught-failure rule)", () => {
  function throwingOn(checker: ts.TypeChecker, method: string): ts.TypeChecker {
    return new Proxy(checker, {
      get(target, prop, receiver) {
        if (prop === method) {
          return () => {
            throw new Error("start < 0");
          };
        }
        return Reflect.get(target, prop, receiver);
      },
    });
  }
  function scanWith(source: string, method: string, how: "module" | "local" = "module"): string[] {
    const mod = createTestModule(source);
    const failures: string[] = [];
    const sink = (node: ts.Node, error: unknown, what: string) =>
      failures.push(`${what}: ${String(error)}`);
    const checker = throwingOn(mod.typeChecker, method);
    const scanner = new InstanceScanner();
    if (how === "module") {
      scanner.scanModule(checker, mod.moduleSymbol, mod.resolvedPath, mod.program, sink);
      // A second scan (cache cleared, same scanner) reports nothing new.
      scanner.scanModule(checker, mod.moduleSymbol, mod.resolvedPath, undefined, sink);
    } else {
      const sf = mod.program.getSourceFile(mod.resolvedPath)!;
      scanner.scanLocalFile(checker, sf, mod.program, sink);
    }
    return failures;
  }

  it("a module whose exports can't be read", () => {
    expect(scanWith(`export const n = 1;`, "getExportsOfModule")).toEqual([
      "the exports of this module: Error: start < 0",
    ]);
  });

  it("a re-export whose alias can't be followed", () => {
    expect(scanWith(`const n = 1;\nexport { n as m };`, "getAliasedSymbol")).toEqual([
      "the re-export 'm' (read as declared): Error: start < 0",
    ]);
  });

  it("an instance's annotated type (TC<T>) and a derived<TC<T>>() type argument", () => {
    const src = `
import { derived } from "typesugar";
interface Eq<A> { equals(a: A, b: A): boolean }
export const eqA: Eq<number> = { equals: (a, b) => a === b };
export const eqB = derived<Eq<string>>();
`;
    expect(scanWith(src, "getTypeFromTypeNode", "local")).toEqual([
      "the type of the instance 'eqA' (matched by name only): Error: start < 0",
      "the type of the derived instance 'eqB' (matched by name only): Error: start < 0",
    ]);
  });

  it("a @derive'd type's companions, and a type an @impl tag names", () => {
    const src = `
import type { Eq } from "typesugar";
/** @derive(Eq) */
export interface P { x: number }
/** @impl Show<P> */
export const showP = { show: (p: P) => String(p.x) };
`;
    const failures = scanWith(src, "getDeclaredTypeOfSymbol");
    expect(failures).toContain("'P's @derive companions: Error: start < 0");
    expect(failures).toContain(
      "the type 'P' an @impl tag names (matched by name only): Error: start < 0"
    );
  });

  it("a keyword type an @impl tag names", () => {
    const src = `/** @impl Show<number> */\nexport const showN = { show: (n: number) => String(n) };`;
    // Both the intrinsic getter and the synthetic-node fallback fail: one line.
    const mod = createTestModule(src);
    const failures: string[] = [];
    const checker = new Proxy(mod.typeChecker, {
      get(target, prop, receiver) {
        if (prop === "getNumberType" || prop === "getTypeFromTypeNode") {
          return () => {
            throw new Error("boom");
          };
        }
        return Reflect.get(target, prop, receiver);
      },
    });
    new InstanceScanner().scanModule(
      checker,
      mod.moduleSymbol,
      mod.resolvedPath,
      mod.program,
      (_n, e, what) => failures.push(`${what}: ${String(e)}`)
    );
    expect(failures).toEqual([
      "the type 'number' an @impl tag names (matched by name only): Error: boom",
    ]);
  });
});
