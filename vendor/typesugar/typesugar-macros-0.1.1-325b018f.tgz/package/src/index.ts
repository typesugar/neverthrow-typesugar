/**
 * @typesugar/macros - Built-in Macros
 *
 * This module exports all built-in macros and ensures they're registered
 * with the global registry when imported.
 */

// MUST stay the first import: rejects TypeScript 7 (no JS compiler API) with one
// clear message before any module below reads `ts.*` at load (PEP-060 item 1).
import "./ts-guard.js";

// Import to register all built-in macros
import "./comptime.js";
import "./derive.js";
import "./operators.js";
import "./reflect.js";
import "./typeclass.js";
import "./specialize.js";
import "./implicits.js"; // = implicit() parameter resolution + summonAll
import "./coverage.js"; // Coverage checking - must load before primitives
import "./primitives.js"; // Primitive typeclass instances for derivation
import "./generic.js"; // Generic programming (Product/Sum) for structural derivation
import "./auto-derive.js"; // Scala 3-style typeclass derivation via Mirror/Generic
import "./static-assert.js";
import "./cfg.js";
import "./forward.js";
import "./config-when.js";
import "./include.js";
import "./module-graph.js";
import "./tailrec.js";
import "./hkt.js"; // Higher-Kinded Type F<_> syntax support
import "./verify-laws.js"; // Typeclass law verification
import "./extension.js"; // Standalone extension methods for concrete types
import "./opaque.js"; // @opaque type macro (PEP-012)
import "./adt.js"; // @adt macro for algebraic data types (PEP-014)

// --- Diagnostic suppression rules ---
// NOTE: diagnostic-suppression-rules.ts is NOT imported as a side-effect module.
// Rules are registered explicitly during transformer/language-service init.
// See createExtensionMethodCallRule() export below.

// --- Testing macros ---
// NOTE: @typesugar/testing/macros is NOT imported here to avoid duplicate
// registration of typeInfo macro. Import it separately when needed.

// Re-export for programmatic use
export {
  comptimeMacro,
  jsToComptimeValue,
  setComptimeEvaluationEnabled,
  isComptimeEvaluationEnabled,
  type ComptimePermissions,
} from "./comptime.js";
export {
  // Derive markers for use in @derive() decorators
  // Eq, Ord, Hash, Show are frozen objects carrying primitive instances
  Eq,
  Ord,
  Clone,
  Debug,
  Hash,
  Default,
  Json,
  TypeGuard,
  Show,
  // Utility for derived function naming
  createDerivedFunctionName,
} from "./derive.js";
export { pipeMacro, composeMacro, getOperatorString } from "./operators.js";
export {
  rewrittenChainType,
  rewrittenOperandType,
  operatorRewriteResult,
  declaredDispatchTypes,
  declaredOperandType,
  isPrimitiveTypedBinary,
  isPrimitiveByFlags,
  admitsNullish,
  isNullOrUndefinedExpr,
  chainBinary,
  PRIMITIVE_RESULT_OPERATORS,
  type OperatorChainHooks,
} from "./operator-chain-types.js";
export {
  reflectAttribute,
  typeInfoMacro,
  fieldNamesMacro,
  validatorMacro,
  type TypeInfo,
  type FieldInfo,
  type MethodInfo,
  type ParameterInfo,
  type ValidationResult,
} from "./reflect.js";
export {
  typeclassAttribute,
  implAttribute,
  summonMacro,
  derivedMacro,
  extendMacro,
  withDerivationContext,
  resolveFieldInstance,
  tryExpandGenericDerive,
  reportGenericDeriveFailure,
  GenericDeriveError,
  registerTypeclassMacros,
  instanceVarName,
  companionPath,
  tryExtractSumType,
  getTypeclassesForMethod,
  extractOpFromJSDoc,
  extractOpsFromJSDoc,
  registerInstanceWithMeta,
  type TypeclassInfo,
  type TypeclassMethod,
  type InstanceInfo,
  type SyntaxEntry,
} from "./typeclass.js";
export {
  // Internal: registerInstanceMethodsFromAST is used by @impl macro, not public API
  registerInstanceMethodsFromAST,
  getInstanceMethodsForDeclaration,
  extractMethodsFromObjectLiteral,
  getInstanceMethods,
  getInstanceOrIntrinsicMethods,
  getPrimitiveIntrinsicMethods,
  isRegisteredInstance,
  getRegisteredInstanceNames,
  classifyInlineFailure,
  classifyInlineFailureDetailed,
  getInlineFailureHelp,
  inlineMethod,
  inlineMethodAsStatements,
  collectMethodFreeNames,
  collectMethodLocalBindings,
  forEachMethodFreeReference,
  methodDependsOnReceiver,
  flattenReturnsToExpression,
  analyzeForFlattening,
  SpecializationCache,
  createHoistedSpecialization,
  getResultAlgebra,
  registerResultAlgebra,
  type ResultAlgebra,
  type DictMethodMap,
  type DictMethod,
  type InlineFailureReason,
  type InlineClassification,
  type InlineOptions,
  type FlattenAnalysis,
  type MemberMethodResolver,
} from "./specialize.js";
// --- Source-based instance extraction for auto-specialization (PEP-053) ---
export {
  tryExtractInstanceFromSource,
  getInstanceName,
  hasImplAnnotation,
  hasTypeclassTypeAnnotation,
  extractBrandFromImpl,
  type InstanceExtractionContext,
} from "./instance-extraction.js";
// --- Implicit parameter resolution (= implicit() default pattern) ---
export {
  summonAllMacro,
  isImplicitDefault,
  hasImplicitParams,
  getImplicitParamIndices,
  valueParameters,
  functionCallTarget,
  buildImplicitScopeFromDecl,
  transformImplicitsCall,
  type ImplicitScope,
} from "./implicits.js";

// --- Coverage checking for derivation ---
export {
  registerPrimitive,
  hasPrimitive,
  getPrimitivesFor,
  checkCoverage,
  validateCoverageOrError,
  configureCoverage,
  getCoverageConfig,
  type CoverageConfig,
  type CoverageResult,
  type FieldInfo as CoverageFieldInfo,
} from "./coverage.js";

// --- Generic programming (Product/Sum) ---
export {
  type Product,
  type Sum,
  type Field,
  type Variant,
  type Generic,
  type Rep,
  type GenericMeta,
  genericDerive,
  registerGeneric,
  getGeneric,
  getGenericMeta,
  registerGenericMeta,
  showProduct,
  showSum,
  eqProduct,
  eqSum,
  ordProduct,
  hashProduct,
  deriveShowViaGeneric,
  deriveEqViaGeneric,
  genericDeriveMacro,
} from "./generic.js";

// --- Scala 3-style typeclass derivation via Mirror/Generic ---
export {
  type GenericDerivation,
  type DerivationResult,
  registerGenericDerivation,
  getGenericDerivation,
  hasGenericDerivation,
  tryDeriveViaGeneric,
  canDeriveViaGeneric,
  clearDerivationCaches,
  makePrimitiveChecker,
} from "./auto-derive.js";

// --- Primitive typeclass instances ---
export {
  // Show
  showNumber,
  showString,
  showBoolean,
  showBigint,
  showArray,
  // Eq
  eqNumber,
  eqString,
  eqBoolean,
  eqBigint,
  eqArray,
  // Ord
  ordNumber,
  ordString,
  ordBoolean,
  ordBigint,
  ordArray,
  // Hash
  hashNumber,
  hashString,
  hashBoolean,
  hashBigint,
  hashArray,
  // Semigroup
  semigroupNumber,
  semigroupString,
  semigroupArray,
  // Monoid
  monoidNumber,
  monoidString,
  monoidArray,
  // Grouped exports (Eq, Ord, Hash, Show are now on the derive markers in derive.ts)
  Semigroup,
  Monoid,
} from "./primitives.js";

// --- Instance Scanner & Resolver (PEP-038 Wave 2A/2B) ---
export {
  InstanceScanner,
  instanceScanner,
  deriveNamesOf,
  parseDoMethodsTag,
  DEFAULT_DO_METHODS,
  type ScannedInstance,
  type DoNotationMeta,
  type ScannerCheckerFailure,
} from "./instance-scanner.js";
export {
  resolveInstance,
  companionAssignedBefore,
  buildInstanceReference,
  buildImportedReference,
  clearResolverCache,
  findInstanceInScopeByName,
  resolveDoNotationInstance,
  isAmbiguousDoNotationInstance,
  type AmbiguousDoNotationInstance,
  brandMatchesForType,
  scanWarnings,
  type ResolvedDoNotationInstance,
  type ResolvedInstance,
  type AmbiguousInstances,
  type ResolutionResult,
  type ResolutionSource,
} from "./instance-resolver.js";
export { getDoInstanceModule } from "./do-instance-index.js";
// --- Import-scoped extension providers (shared by the rewrite and the ExtensionMethodCall rule) ---
export {
  findImportedExtensionMatches,
  hasExtensionImportTag,
  isRegistryExtensionCalleeBound,
  isImportExtensionInScopeAt,
  extensionCallReturnType,
  extensionImportUses,
  chooseExtensionMatch,
  importClauseBindings,
  inactiveExtensionImportTags,
  type ExtensionImportUses,
  checkImportedSymbolForExtension,
  hasExtensionDecorator,
  isDefaultLibMember,
  isGlobalAugmentationStub,
  type ExtensionImportEnv,
  type ImportedExtensionMatch,
} from "./extension-imports.js";
export {
  getOpMapForTypeclass,
  getOperatorCandidates,
  getInactiveOperatorCandidates,
  getMethodCandidates,
  getTypeclassesDeclaringMethod,
  isHktTypeclass,
  isTypeclassDeclared,
  type TypeclassOpInfo,
} from "./typeclass-index.js";

// --- Phase 1.1: Quasiquoting ---
export {
  quote,
  quoteStatements,
  quoteType,
  quoteBlock,
  quoteCall,
  quotePropAccess,
  quoteMethodCall,
  quoteConst,
  quoteLet,
  quoteReturn,
  quoteIf,
  quoteArrow,
  quoteFunction,
  ident,
  raw,
  spread,
  SpreadSplice,
  IdentSplice,
  RawSplice,
  type QuoteSplice,
} from "./quote.js";

// --- Phase 1.2: Pattern-based macros ---
export {
  defineSyntaxMacro,
  defineRewrite,
  type PatternCapture,
  type PatternArm,
  type SyntaxMacroOptions,
} from "./syntax-macro.js";

// --- Phase 1.3: Simplified custom derive ---
export {
  defineCustomDerive,
  defineCustomDeriveAst,
  defineFieldDerive,
  defineTypeFunctionDerive,
  type SimpleFieldInfo,
  type SimpleTypeInfo,
} from "./custom-derive.js";

// --- Phase 2.1: Compile-time file I/O ---
export {
  includeStrMacro,
  includeBytesMacro,
  includeJsonMacro,
  getFileDependencies,
  clearFileDependencies,
} from "./include.js";

// --- Phase 2.2: Conditional compilation ---
export { forwardMacro } from "./forward.js";
export { cfgMacro, cfgAttrMacro, setCfgConfig, getCfgConfig, evaluateCfgCondition } from "./cfg.js";

// --- Phase 2.3: Module-graph reflection ---
export { collectTypesMacro, moduleIndexMacro } from "./module-graph.js";

// --- Phase 3.2: Enhanced diagnostics ---
export { staticAssertMacro, compileErrorMacro, compileWarningMacro } from "./static-assert.js";

// --- Tail-call optimization ---
export { tailrecAttribute } from "./tailrec.js";

// --- Typeclass law verification ---
export { verifyLawsAttribute, getVerifyLawsConfig } from "./verify-laws.js";

// --- Standalone extension methods for concrete types ---
export {
  extensionAttribute,
  registerExtensionsMacro,
  registerExtensionMacro,
  registerStandaloneExtensionEntry,
  findStandaloneExtension,
  getStandaloneExtensionsForType,
  getAllStandaloneExtensions,
  buildStandaloneExtensionCall,
  standaloneExtensionRegistry,
  createRegistrationCall,
  type StandaloneExtensionInfo,
} from "./extension.js";

// --- Opaque type macro (PEP-012) ---
export { opaqueAttribute, registerOpaqueInterface } from "./opaque.js";

// --- ADT macro (PEP-014) ---
export { adtAttribute } from "./adt.js";

// --- Diagnostic Suppression Rules ---
export {
  createExtensionMethodCallRule,
  createMacroCallChainRule,
  createMatchSwitchRule,
  createContractBlockRule,
  createMacroDecoratorRule,
  createOperatorOverloadRule,
  createRewrittenOperatorResultRule,
  createTypeRewriteAssignmentRule,
  createDerivedCompanionAccessRule,
  createDerivedDeclarationReferenceRule,
  createJSDocDeriveImportRule,
  createExtensionImportRule,
  generatedValueNames,
  isDerivedValueSymbol,
} from "./diagnostic-suppression-rules.js";

// --- Unified Diagnostic Suppression Registration (PEP-034) ---
export {
  registerAllDiagnosticSuppressionRules,
  ALL_DIAGNOSTIC_SUPPRESSION_RULE_NAMES,
  type DiagnosticSuppressionRegistrationOptions,
} from "./diagnostic-suppression-registration.js";

// --- Higher-Kinded Types (part of typeclass system) ---
// HKT enables typeclasses parameterized by type constructors (F<_>).
// Use @instance("Monad<Option>") for HKT typeclass instances.

// From typeclass.ts - canonical HKT registration.
// Whether a typeclass is HKT is declaration-derived (PEP-052 Wave 4): see
// `isHktTypeclass` in typeclass-index.ts. The old hardcoded name table
// (hktTypeclassNames/registerHKTTypeclass) is gone.
export { registerHKTExpansion } from "./typeclass.js";

// From hkt.ts - type-level utilities only
export {
  hktAttribute,
  transformHKTDeclaration,
  isKindAnnotation,
  getKindArity,
  kindParamRegistry,
  type KindParamInfo,
} from "./hkt.js";

// --- Testing macros ---
// NOTE: Testing macros (powerAssertMacro, comptimeAssertMacro, etc.) are
// available from @typesugar/testing/macros but are NOT re-exported here
// to avoid duplicate registration of the typeInfo macro.

// ============================================================================
// Runtime Stubs
// ============================================================================
// These are placeholder functions that the transformer replaces at compile time.
// They provide type information and give meaningful errors if transformer isn't configured.

export {
  // Typeclass stubs
  typeclass,
  instance,
  deriving,
  summon,
  summonAll,
  derived,
  extend,
  // Extension method decorator
  extension,
  // Extension registration stubs (deprecated, use @extension instead)
  registerExtensions,
  registerExtension,
  // Implicit parameter resolution stub
  implicit,
  // Comptime stub
  comptime,
  // Derive stub
  derive,
  // Operator stubs
  pipe,
  compose,
  flow,
  // Reflect stubs
  reflect,
  typeInfo,
  fieldNames,
  validator,
  // Conditional compilation
  cfg,
  cfgAttr,
  type CfgBranch,
  // File include stubs
  includeStr,
  includeJson,
  includeBytes,
  includeText,
  // Compile-time diagnostics
  compileError,
  compileWarning,
  // Static assert
  staticAssert,
  // Tail recursion
  tailrec,
  // HKT
  hkt,
} from "./runtime-stubs.js";
