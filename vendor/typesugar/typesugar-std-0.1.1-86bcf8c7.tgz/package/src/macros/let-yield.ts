/**
 * let:/yield: Labeled Block Macro
 *
 * Generic do-notation style syntax that works with any type that has a
 * FlatMap instance. Desugars `let: { x << expr }` blocks into flatMap chains.
 *
 * ## Syntax
 *
 * ```typescript
 * let: {
 *   x << expr1           // Monadic bind: flatMap
 *   y = x * 2            // Pure map: inline computation
 *   _ << sideEffect()    // Discard: bind but ignore result
 *   z << expr2 || alt    // orElse: fallback on failure
 *   if (condition) {}    // Guard: short-circuit on false
 * }
 * yield: { resultExpr }   // or: yield: resultExpr, e.g. yield: ({ x, y })
 * ```
 *
 * ## Examples
 *
 * ```typescript
 * // With Array
 * let: {
 *   x << [1, 2, 3]
 *   y << [x * 10, x * 20]
 * }
 * yield: ({ x, y })
 * // Compiles to: [1,2,3].flatMap(x => [x*10, x*20].map(y => ({ x, y })))
 *
 * // With Promise
 * let: {
 *   user << fetchUser(id)
 *   posts << fetchPosts(user.id)
 * }
 * yield: ({ user, posts })
 * // Compiles to: fetchUser(id).then(user => fetchPosts(user.id).then(posts => ({ user, posts })))
 *
 * // With guards and orElse
 * let: {
 *   x << someOption
 *   if (x > 0) {}           // Guards: short-circuit if false
 *   y << getY() || default  // orElse: fallback on failure
 * }
 * yield: (x + y)
 *
 * // Implicit yield (returns last binding)
 * let: {
 *   x << Some(42)
 * }
 * // Returns Some(42) directly
 * ```
 *
 * ## How it works
 *
 * 1. The macro parses steps from the `let:` block (binds, maps, guards)
 * 2. It infers the type constructor from the first bind's expression
 * 3. It looks up the FlatMap instance for that type constructor
 * 4. It generates a chain: flatMap for intermediate binds, map for the last
 *
 * ## Supporting custom types
 *
 * Declare an instance tagged `@impl FlatMap<MyType>` (JSDoc) in the file, or
 * export it from a module the file imports — resolution is scope-based
 * (PEP-052):
 *
 * ```typescript
 * // JSDoc tag on the declaration: @impl FlatMap<MyType>
 * export const flatMapMyType = {
 *   map: (fa, f) => fa.map(f),
 *   flatMap: (fa, f) => fa.flatMap(f),
 * };
 * ```
 */

import * as ts from "typescript";
import {
  type LabeledBlockMacro,
  type MacroContext,
  defineLabeledBlockMacro,
  globalRegistry,
  TS9225,
} from "@typesugar/core";
import {
  resolveDoNotationInstance,
  getDoInstanceModule,
  DEFAULT_DO_METHODS,
  type DoNotationMeta,
} from "@typesugar/macros";
import {
  type ComprehensionStep,
  type BindStep,
  type MapStep,
  type GuardStep,
  type ParallelGroupStep,
  extractReturnExpr,
  inferTypeConstructor,
  createArrowFn,
  createMethodCall,
  createIIFE,
  resolveStdDoFallback,
  KNOWN_DO_INSTANCE_MODULES,
  createStyleAwareCall,
  createMetadataJoin,
  createSequentialBinds,
  createTupleBindingPattern,
  emitComprehensionResult,
  importSelfReceiver,
} from "./comprehension-utils.js";
import { extractParSteps, validateIndependence } from "./par-yield.js";
import { getStdParCombineBuilder } from "../typeclasses/par-combine.js";

/**
 * Brands whose comprehensions can FILTER (`if (cond) {}` guards): the ones
 * with a known empty value. All three std collection brands accept an array
 * literal as both `pure` (`[x]`) and `empty` (`[]`) — `flatMapIterable` /
 * `flatMapAsyncIterable` `yield*` over any iterable. Every other brand
 * rejects guards: the old `cond ? inner : undefined` put `undefined` INTO
 * the result instead of filtering (deep review #7).
 */
const GUARD_CAPABLE_BRANDS = new Set(["Array", "Iterable", "AsyncIterable"]);

/**
 * Method names for FlatMap operations.
 * Different types may use different method names (e.g., Promise uses "then").
 */
interface MethodNames {
  bind: string;
  map: string;
  orElse?: string;
}

// ============================================================================
// let:/yield: Labeled Block Macro
// ============================================================================

/**
 * The let:/yield: macro transforms labeled block syntax into FlatMap chains.
 *
 * It resolves the FlatMap instance based on the type of the first binding,
 * then generates appropriate map/flatMap calls.
 */
export const letYieldMacro: LabeledBlockMacro = defineLabeledBlockMacro({
  name: "letYield",
  label: ["let", "seq"],
  continuationLabels: ["yield", "pure", "return"],
  valueProducing: true,
  syntaxModule: "@typesugar/std/syntax/do",
  expand(
    ctx: MacroContext,
    mainBlock: ts.LabeledStatement,
    continuation: ts.LabeledStatement | undefined
  ): ts.Statement | ts.Statement[] {
    const { factory, typeChecker } = ctx;
    const label = mainBlock.label.text;

    // The main block must be a Block
    if (!ts.isBlock(mainBlock.statement)) {
      ctx.reportError(mainBlock, `${label}: must be followed by a block { ... }`);
      return mainBlock;
    }

    // Extract steps from the let/seq block
    const steps = extractSteps(ctx, mainBlock.statement, label);
    if (!steps || steps.length === 0) {
      ctx.reportError(mainBlock, `${label}: block must contain at least one binding or guard`);
      return mainBlock;
    }

    // Must have at least one bind step (or parallel-group with binds)
    const hasBindStep = steps.some((s) => s.kind === "bind" || s.kind === "parallel-group");
    if (!hasBindStep) {
      ctx.reportError(
        mainBlock,
        `${label}: block must contain at least one \`name << expression\` binding`
      );
      return mainBlock;
    }

    // Infer the type constructor from the first bind step (possibly inside a
    // leading parallel group).
    const firstBind = steps
      .flatMap((s): BindStep[] =>
        s.kind === "bind"
          ? [s]
          : s.kind === "parallel-group"
            ? s.steps.filter((p): p is BindStep => p.kind === "bind")
            : []
      )
      .at(0);
    if (!firstBind) {
      ctx.reportError(
        mainBlock,
        `${label}: block must contain at least one \`name << expression\` binding`
      );
      return mainBlock;
    }
    const typeConstructorName = inferTypeConstructor(
      firstBind.effect,
      typeChecker,
      ctx.sourceFile,
      ctx
    );

    if (!typeConstructorName) {
      ctx.reportError(
        firstBind.effect,
        "Could not infer type constructor from expression. " +
          "Make sure the expression has a known type (Array, Promise, Option, etc.)"
      );
      return mainBlock;
    }

    // PEP-052 Wave 3: instance resolution is scope-based — an instance
    // declared in this file or exported by any imported module (the std
    // builtins come in through the `@typesugar/std/syntax/do` marker every
    // do-notation file already imports). No global registry. The static
    // fallback serves the std builtins in hosts that cannot resolve modules.
    const scoped =
      resolveDoNotationInstance(ctx, "FlatMap", typeConstructorName) ??
      resolveStdDoFallback(ctx.sourceFile, "FlatMap", typeConstructorName);
    if (!scoped) {
      // Provider-declared activation module (program-wide @do-instance-module
      // index) first; the static table is the fallback for providers whose
      // declaration files are unreachable in this program.
      const knownModule =
        getDoInstanceModule(ctx.program, typeConstructorName) ??
        KNOWN_DO_INSTANCE_MODULES[typeConstructorName];
      ctx
        .diagnostic(TS9225)
        .at(firstBind.effect)
        .withArgs({ typeclass: "FlatMap", brand: typeConstructorName })
        .help(
          knownModule
            ? `Add \`import "${knownModule}";\` to bring the ${typeConstructorName} instance into scope.`
            : `Import a module exporting an @impl FlatMap<${typeConstructorName}> instance, or declare one in this file.`
        )
        .emit();
      return mainBlock;
    }

    // Method names + emission style from the instance's @do-methods metadata.
    let doMeta: DoNotationMeta = scoped.doMeta ?? DEFAULT_DO_METHODS;
    doMeta = importSelfReceiver(ctx, scoped, doMeta, typeConstructorName);

    // Guards need an empty value to filter with (deep review #7).
    if (!GUARD_CAPABLE_BRANDS.has(typeConstructorName)) {
      const guard = steps.find((s): s is GuardStep => s.kind === "guard");
      if (guard) {
        ctx.reportError(
          guard.node,
          `${label}: guards (\`if (cond) {}\`) need a type with an empty value to filter with; ` +
            `they are supported for Array, Iterable and AsyncIterable, not ${typeConstructorName}. ` +
            `Filter inside a bind instead (e.g. \`x << (cond ? some(v) : none)\`).`
        );
        return mainBlock;
      }
    }
    if (doMeta.unrecognized?.length) {
      ctx.reportWarning(
        mainBlock,
        `@do-methods on the ${typeConstructorName} FlatMap instance (${scoped.exportName}) has ` +
          `unrecognized entries: ${doMeta.unrecognized.join(" ")} — valid keys are ` +
          `bind= map= orElse= all= receiver= style=method|static.`
      );
    }
    // `x << fa || alt` / `?? alt` needs a recovery method. A method-style
    // instance defaults to `fa.orElse(...)`, but a static-style one has no
    // such default: `F.orElse` only exists when the instance declares it
    // (`@do-methods orElse=…`) — emitting it anyway was a runtime TypeError
    // (docs review r3 guides-a #2).
    if (doMeta.style === "static" && !doMeta.orElse) {
      const fallback = steps.find((s): s is BindStep => s.kind === "bind" && !!s.orElse);
      if (fallback) {
        ctx.reportError(
          fallback.node,
          `${label}: the ${typeConstructorName} FlatMap instance (${scoped.exportName}) declares no ` +
            `orElse= in its @do-methods, so \`<< expr || fallback\` / \`?? fallback\` is not supported ` +
            `for ${typeConstructorName}. Recover inside the bind instead (e.g. \`x << orElse(expr, () => fallback)\`).`
        );
        return mainBlock;
      }
    }
    const methods: MethodNames = {
      bind: doMeta.bind,
      map: doMeta.map,
      orElse: doMeta.orElse ?? "orElse",
    };

    // Handle yield expression or implicit return
    let returnExpr: ts.Expression;
    if (continuation) {
      // `yield: { expr }` or `yield: expr` (e.g. `yield: ({ a, b })`).
      const extracted = extractReturnExpr(ctx, continuation.statement);
      if (!extracted) {
        return mainBlock;
      }
      returnExpr = extracted;
    } else {
      // No yield/pure block — return the last bind step's result directly
      const lastBind = [...steps].reverse().find((s): s is BindStep => s.kind === "bind");
      if (!lastBind) {
        ctx.reportError(mainBlock, "No bind step found for implicit return");
        return mainBlock;
      }

      // The last bind's effect IS the result. Anything after it (a guard, a
      // pure map, a parallel group) would be meaningless — and used to be
      // silently dropped (deep review #8) — so require an explicit yield:.
      const lastIdx = steps.lastIndexOf(lastBind);
      if (lastIdx !== steps.length - 1) {
        ctx.reportError(
          steps[lastIdx + 1].node,
          `${label}: without a yield: block the result is the last \`name << expr\` binding, ` +
            `so nothing may follow it — add a yield: { ... } block.`
        );
        return mainBlock;
      }
      const tail = applyOrElse(ctx, lastBind, methods, doMeta);
      const stepsWithoutLast = steps.slice(0, lastIdx);
      if (stepsWithoutLast.length === 0) {
        // Only one bind step — just return the expression directly
        return emitComprehensionResult(factory, mainBlock, continuation, tail);
      }
      // The tail is already an effect: every bind before it must flatten.
      const chain = buildChain(
        ctx,
        stepsWithoutLast,
        tail,
        methods,
        typeConstructorName,
        doMeta,
        true
      );
      return emitComprehensionResult(factory, mainBlock, continuation, chain);
    }

    // Build the chain
    const result = buildChain(ctx, steps, returnExpr, methods, typeConstructorName, doMeta);

    return emitComprehensionResult(factory, mainBlock, continuation, result);
  },
});

// ============================================================================
// Step Extraction
// ============================================================================

/**
 * Extract comprehension steps from a block statement.
 *
 * Handles:
 * - `name << expr` — bind step
 * - `name << expr || alt` — bind with orElse
 * - `name << expr ?? alt` — bind with nullish coalescing fallback
 * - `_ << expr` — discard binding
 * - `name = expr` — pure map step
 * - `if (cond) {}` — guard step
 */
function extractSteps(
  ctx: MacroContext,
  block: ts.Block,
  label: string = "let"
): ComprehensionStep[] | undefined {
  const steps: ComprehensionStep[] = [];

  for (const stmt of block.statements) {
    // Guard: if (condition) {}
    if (ts.isIfStatement(stmt)) {
      steps.push({
        kind: "guard",
        condition: stmt.expression,
        node: stmt,
      });
      continue;
    }

    // Nested parallel group: par: { ... } or all: { ... }
    if (ts.isLabeledStatement(stmt)) {
      const parLabel = stmt.label.text;
      if (parLabel === "par" || parLabel === "all") {
        if (!ts.isBlock(stmt.statement)) {
          ctx.reportError(stmt, `${parLabel}: must be followed by a block { ... }`);
          return undefined;
        }
        const parSteps = extractParSteps(ctx, stmt.statement, parLabel);
        if (!parSteps) return undefined;
        if (!validateIndependence(ctx, parSteps, parLabel)) return undefined;
        if (parSteps.length === 0) {
          ctx.reportError(stmt, `${parLabel}: block must contain at least one binding`);
          return undefined;
        }
        steps.push({
          kind: "parallel-group",
          steps: parSteps,
          label: parLabel,
          node: stmt,
        });
        continue;
      }
    }

    if (!ts.isExpressionStatement(stmt)) {
      ctx.reportError(
        stmt,
        `${label}: block statements must be \`name << expr\`, \`name = expr\`, or \`if (cond) {}\``
      );
      return undefined;
    }

    const expr = stmt.expression;

    if (!ts.isBinaryExpression(expr)) {
      ctx.reportError(stmt, "Expected `name << expression` or `name = expression`");
      return undefined;
    }

    const opKind = expr.operatorToken.kind;

    // Pure map: name = expr
    // Note: EqualsToken (63) === FirstAssignment - they're the same value
    if (opKind === ts.SyntaxKind.FirstAssignment) {
      if (!ts.isIdentifier(expr.left)) {
        ctx.reportError(expr.left, "Left side of = must be an identifier");
        return undefined;
      }
      steps.push({
        kind: "map",
        name: expr.left.text,
        expression: expr.right,
        node: stmt,
      });
      continue;
    }

    // Monadic bind with orElse: name << expr || fallback
    // Due to operator precedence, `name << expr || fallback` parses as
    // (name << expr) || fallback — a BinaryExpression with || at the top.
    if (opKind === ts.SyntaxKind.BarBarToken) {
      const lhs = expr.left;
      if (
        ts.isBinaryExpression(lhs) &&
        lhs.operatorToken.kind === ts.SyntaxKind.LessThanLessThanToken &&
        ts.isIdentifier(lhs.left)
      ) {
        steps.push({
          kind: "bind",
          name: lhs.left.text,
          effect: lhs.right,
          orElse: expr.right,
          node: stmt,
        });
        continue;
      }
    }

    // Monadic bind with nullish coalescing: name << expr ?? fallback
    if (opKind === ts.SyntaxKind.QuestionQuestionToken) {
      const lhs = expr.left;
      if (
        ts.isBinaryExpression(lhs) &&
        lhs.operatorToken.kind === ts.SyntaxKind.LessThanLessThanToken &&
        ts.isIdentifier(lhs.left)
      ) {
        steps.push({
          kind: "bind",
          name: lhs.left.text,
          effect: lhs.right,
          orElse: expr.right,
          node: stmt,
        });
        continue;
      }
    }

    // Plain bind: name << expr
    if (opKind === ts.SyntaxKind.LessThanLessThanToken) {
      if (!ts.isIdentifier(expr.left)) {
        ctx.reportError(expr.left, "Left side of << must be an identifier (variable name or _)");
        return undefined;
      }
      steps.push({
        kind: "bind",
        name: expr.left.text,
        effect: expr.right,
        node: stmt,
      });
      continue;
    }

    ctx.reportError(
      stmt,
      `${label}: expected \`name << expression\`, \`name = expression\`, or \`if (cond) {}\``
    );
    return undefined;
  }

  return steps;
}

// Method names are resolved from the scoped instance's @do-methods metadata
// (see resolveDoNotationInstance in @typesugar/macros).

// ============================================================================
// Chain Building
// ============================================================================

/** `effect.orElse(_ => fallback)` (style-aware) when the bind has a fallback. */
function applyOrElse(
  ctx: MacroContext,
  step: BindStep,
  methods: MethodNames,
  doMeta: DoNotationMeta
): ts.Expression {
  if (!step.orElse || !methods.orElse) return step.effect;
  return createStyleAwareCall(
    ctx.factory,
    doMeta,
    methods.orElse,
    step.effect,
    createArrowFn(ctx.factory, "_", step.orElse)
  );
}

/**
 * Build the comprehension chain from steps and a return expression.
 *
 * Built inside-out, tracking whether the expression built so far is a plain
 * VALUE (the yield, possibly wrapped in pure-map IIFEs) or an EFFECT (after
 * any bind / guard / parallel group). A bind whose continuation is an effect
 * uses the bind method (`flatMap`/`then`); one whose continuation is a value
 * uses `map`. This is what keeps `let:` without `yield:` and binds after a
 * guard or a nested `par:` from nesting `F<F<A>>` (deep review #8, #9).
 *
 * - bind steps → `fa.flatMap(x => effect)` / `fa.map(x => value)`
 * - map steps → `((name) => inner)(expr)`
 * - guard steps (Array/Iterable/AsyncIterable only) → `cond ? effect : []`,
 *   lifting a value continuation with `[value]` first (deep review #7)
 * - parallel groups → the ParCombine join (metadata `all=`, the std builder,
 *   or `.map().ap()`), continued with bind/map like a single bind
 */
function buildChain(
  ctx: MacroContext,
  steps: ComprehensionStep[],
  returnExpr: ts.Expression,
  methods: MethodNames,
  typeConstructor: string,
  doMeta: DoNotationMeta,
  returnIsEffect = false
): ts.Expression {
  const { factory } = ctx;

  if (steps.length === 0) {
    return returnExpr;
  }

  let inner: ts.Expression = returnExpr;
  let innerIsEffect = returnIsEffect;

  // Process steps from last to first
  for (let i = steps.length - 1; i >= 0; i--) {
    const step = steps[i];

    switch (step.kind) {
      case "bind": {
        inner = createStyleAwareCall(
          factory,
          doMeta,
          innerIsEffect ? methods.bind : methods.map,
          applyOrElse(ctx, step, methods, doMeta),
          createArrowFn(factory, step.name, inner)
        );
        innerIsEffect = true;
        break;
      }

      case "map": {
        // Pure map step: wrap inner in an IIFE that binds the computed value.
        inner = createIIFE(factory, step.name, inner, step.expression);
        break;
      }

      case "guard": {
        // Only reached for GUARD_CAPABLE_BRANDS (checked in expand): an array
        // literal is both `pure` and `empty` for them.
        const effect = innerIsEffect ? inner : factory.createArrayLiteralExpression([inner]);
        inner = factory.createConditionalExpression(
          step.condition,
          factory.createToken(ts.SyntaxKind.QuestionToken),
          effect,
          factory.createToken(ts.SyntaxKind.ColonToken),
          factory.createArrayLiteralExpression([])
        );
        innerIsEffect = true;
        break;
      }

      case "parallel-group": {
        const bindSteps = step.steps.filter((s): s is BindStep => s.kind === "bind");
        const mapSteps = step.steps.filter((s): s is MapStep => s.kind === "map");

        if (bindSteps.length === 0) {
          for (const mapStep of [...mapSteps].reverse()) {
            inner = createIIFE(factory, mapStep.name, inner, mapStep.expression);
          }
          break;
        }

        const continueMethod = innerIsEffect ? methods.bind : methods.map;

        // 1. `@do-methods all=… receiver=…` join (Promise, Effect, …):
        //    `R.all([e1, e2])` continued with the FlatMap instance's
        //    bind/map, over the destructured results.
        const parScoped =
          resolveDoNotationInstance(ctx, "ParCombine", typeConstructor) ??
          resolveStdDoFallback(ctx.sourceFile, "ParCombine", typeConstructor);
        if (parScoped?.doMeta?.all && parScoped.doMeta.receiver) {
          let bodyWithMaps = inner;
          for (const mapStep of [...mapSteps].reverse()) {
            bodyWithMaps = createIIFE(factory, mapStep.name, bodyWithMaps, mapStep.expression);
          }
          const parMeta = importSelfReceiver(ctx, parScoped, parScoped.doMeta, typeConstructor);
          inner = createMetadataJoin(factory, parMeta, bindSteps, bodyWithMaps, {
            meta: doMeta,
            method: continueMethod,
          });
          innerIsEffect = true;
          break;
        }

        // 2. No ParCombine join and no std builder, and the FlatMap instance
        //    is static style (fp's Option/Either/IO/List: no `.map`/`.ap`
        //    methods on the values): chain the group's independent binds
        //    straight into the surrounding chain (docs review r3 guides-a #1).
        if (!getStdParCombineBuilder(typeConstructor) && doMeta.style === "static") {
          let bodyWithMaps = inner;
          for (const mapStep of [...mapSteps].reverse()) {
            bodyWithMaps = createIIFE(factory, mapStep.name, bodyWithMaps, mapStep.expression);
          }
          inner = createSequentialBinds(factory, doMeta, bindSteps, bodyWithMaps, innerIsEffect);
          innerIsEffect = true;
          break;
        }

        // 3./4. Otherwise combine the group into F<[names...]> — with the std
        //    builder (Array/Iterable cartesian product, AsyncIterable
        //    collection) or the generic `.map().ap()` chain — and continue
        //    from that tuple like a single bind.
        const names = [
          ...bindSteps.map((s) => s.name).filter((n) => n !== "_"),
          ...mapSteps.map((s) => s.name),
        ];
        const tuple = factory.createArrayLiteralExpression(
          names.map((n) => factory.createIdentifier(n))
        );
        const builder = getStdParCombineBuilder(typeConstructor);
        let joined: ts.Expression;
        if (builder) {
          joined = builder(ctx, step.steps, tuple);
        } else {
          let tupleWithMaps: ts.Expression = tuple;
          for (const mapStep of [...mapSteps].reverse()) {
            tupleWithMaps = createIIFE(factory, mapStep.name, tupleWithMaps, mapStep.expression);
          }
          let curried: ts.Expression = tupleWithMaps;
          for (let j = bindSteps.length - 1; j > 0; j--) {
            curried = createArrowFn(factory, bindSteps[j].name, curried);
          }
          joined = createMethodCall(
            factory,
            bindSteps[0].effect,
            "map",
            createArrowFn(factory, bindSteps[0].name, curried)
          );
          for (let j = 1; j < bindSteps.length; j++) {
            joined = createMethodCall(factory, joined, "ap", bindSteps[j].effect);
          }
        }
        const tupleParam = factory.createParameterDeclaration(
          undefined,
          undefined,
          createTupleBindingPattern(factory, names)
        );
        inner = createStyleAwareCall(
          factory,
          doMeta,
          continueMethod,
          joined,
          factory.createArrowFunction(
            undefined,
            undefined,
            [tupleParam],
            undefined,
            factory.createToken(ts.SyntaxKind.EqualsGreaterThanToken),
            inner
          )
        );
        innerIsEffect = true;
        break;
      }
    }
  }

  return inner;
}

// ============================================================================
// Registration
// ============================================================================

/**
 * Register the let:/yield: macro with the global registry.
 */
export function registerLetYield(): void {
  globalRegistry.register(letYieldMacro);
}

// Auto-register on import
registerLetYield();
