"use extension";

import { type Range, range as rangeExclusive, rangeInclusive } from "../data/range.js";

/**
 * Number Extension Methods
 *
 * All exported functions take `number` as their first argument,
 * enabling method-call syntax: `(-5).abs()`, `n.clamp(0, 100)`, etc.
 *
 * Inspired by:
 * - Ruby (times, upto, downto, even?, odd?, between?, clamp, abs, round, ceil, floor, digits)
 * - Kotlin (coerceIn, coerceAtLeast, coerceAtMost, rangeTo, downTo, compareTo)
 * - Swift (isMultiple(of:), magnitude, negate)
 * - Rust (clamp, pow, checked_add, saturating_add, wrapping_add)
 * - Python (math module: gcd, lcm, factorial, comb, perm, isqrt)
 * - Scala (to, until, max, min, abs, signum, toByte, toShort, toInt, toLong)
 * - Haskell (div, mod, divMod, quot, rem, gcd, lcm, even, odd)
 * - Most-requested JS/TS: clamp, lerp, remap, isEven, isOdd, random range, ordinal
 */

// ============================================================================
// Math.* Wrappers — Zero-Cost Static Method Extensions
// ============================================================================
// These wrap static Math methods so they can be called as extensions on numbers.
// Example: (-5).abs() instead of Math.abs(-5)
// The transformer inlines these, so there's no overhead.

export function abs(n: number): number {
  return Math.abs(n);
}

export function ceil(n: number): number {
  return Math.ceil(n);
}

export function floor(n: number): number {
  return Math.floor(n);
}

export function round(n: number): number {
  return Math.round(n);
}

export function trunc(n: number): number {
  return Math.trunc(n);
}

export function sqrt(n: number): number {
  return Math.sqrt(n);
}

export function cbrt(n: number): number {
  return Math.cbrt(n);
}

export function sign(n: number): number {
  return Math.sign(n);
}

export function log(n: number): number {
  return Math.log(n);
}

export function log10(n: number): number {
  return Math.log10(n);
}

export function log2(n: number): number {
  return Math.log2(n);
}

export function exp(n: number): number {
  return Math.exp(n);
}

export function sin(n: number): number {
  return Math.sin(n);
}

export function cos(n: number): number {
  return Math.cos(n);
}

export function tan(n: number): number {
  return Math.tan(n);
}

export function asin(n: number): number {
  return Math.asin(n);
}

export function acos(n: number): number {
  return Math.acos(n);
}

export function atan(n: number): number {
  return Math.atan(n);
}

export function sinh(n: number): number {
  return Math.sinh(n);
}

export function cosh(n: number): number {
  return Math.cosh(n);
}

export function tanh(n: number): number {
  return Math.tanh(n);
}

// Binary Math functions with number as first argument
// Note: pow, min, max are NOT included here because they conflict with
// the generic typeclass versions in typeclasses/numeric-ops.ts.
// Use (2).pow(3) via the Numeric typeclass, or Math.pow directly.

export function atan2(y: number, x: number): number {
  return Math.atan2(y, x);
}

export function hypot(a: number, b: number): number {
  return Math.hypot(a, b);
}

// ============================================================================
// Arithmetic & Rounding (Custom)
// ============================================================================

export function clamp(n: number, min: number, max: number): number {
  return n < min ? min : n > max ? max : n;
}

export function lerp(start: number, end: number, t: number): number {
  return start + (end - start) * t;
}

export function inverseLerp(start: number, end: number, value: number): number {
  return start === end ? 0 : (value - start) / (end - start);
}

export function remap(
  n: number,
  fromMin: number,
  fromMax: number,
  toMin: number,
  toMax: number
): number {
  const t = inverseLerp(fromMin, fromMax, n);
  return lerp(toMin, toMax, t);
}

export function roundTo(n: number, decimals: number): number {
  const factor = 10 ** decimals;
  return Math.round(n * factor) / factor;
}

export function ceilTo(n: number, decimals: number): number {
  const factor = 10 ** decimals;
  return Math.ceil(n * factor) / factor;
}

export function floorTo(n: number, decimals: number): number {
  const factor = 10 ** decimals;
  return Math.floor(n * factor) / factor;
}

export function truncTo(n: number, decimals: number): number {
  const factor = 10 ** decimals;
  return Math.trunc(n * factor) / factor;
}

export function snap(n: number, step: number): number {
  return Math.round(n / step) * step;
}

// ============================================================================
// Predicates
// ============================================================================

export function isEven(n: number): boolean {
  return n % 2 === 0;
}

export function isOdd(n: number): boolean {
  return n % 2 !== 0;
}

export function isPositive(n: number): boolean {
  return n > 0;
}

export function isNegative(n: number): boolean {
  return n < 0;
}

export function isZero(n: number): boolean {
  return n === 0;
}

export function isInteger(n: number): boolean {
  return Number.isInteger(n);
}

export function isFiniteNum(n: number): boolean {
  return Number.isFinite(n);
}

export function isNaN_(n: number): boolean {
  return Number.isNaN(n);
}

export function isBetween(n: number, min: number, max: number): boolean {
  return n >= min && n <= max;
}

export function isMultipleOf(n: number, divisor: number): boolean {
  return divisor !== 0 && n % divisor === 0;
}

export function isPrime(n: number): boolean {
  if (!Number.isInteger(n) || n < 2) return false;
  if (n < 4) return true;
  if (n % 2 === 0 || n % 3 === 0) return false;
  for (let i = 5; i * i <= n; i += 6) {
    if (n % i === 0 || n % (i + 2) === 0) return false;
  }
  return true;
}

export function isPerfectSquare(n: number): boolean {
  if (n < 0) return false;
  const s = Math.sqrt(n);
  return s === Math.floor(s);
}

/** True for 1, 2, 4, 8, ... (any integer power of two, not limited to 32 bits). */
export function isPowerOfTwo(n: number): boolean {
  if (!Number.isInteger(n) || n < 1) return false;
  while (n % 2 === 0) n /= 2;
  return n === 1;
}

// ============================================================================
// Number Theory (Python math, Haskell Prelude)
// ============================================================================

export function gcd(a: number, b: number): number {
  a = Math.abs(a);
  b = Math.abs(b);
  while (b) {
    [a, b] = [b, a % b];
  }
  return a;
}

export function lcm(a: number, b: number): number {
  return a === 0 || b === 0 ? 0 : Math.abs(a * b) / gcd(a, b);
}

export function factorial(n: number): number {
  if (n < 0) throw new RangeError("factorial of negative number");
  if (n <= 1) return 1;
  let result = 1;
  for (let i = 2; i <= n; i++) result *= i;
  return result;
}

export function fibonacci(n: number): number {
  if (n < 0) throw new RangeError("fibonacci of negative number");
  let [a, b] = [0, 1];
  for (let i = 0; i < n; i++) [a, b] = [b, a + b];
  return a;
}

export function nCr(n: number, r: number): number {
  if (r < 0 || r > n) return 0;
  if (r === 0 || r === n) return 1;
  r = Math.min(r, n - r);
  let result = 1;
  for (let i = 0; i < r; i++) {
    result = (result * (n - i)) / (i + 1);
  }
  return Math.round(result);
}

export function nPr(n: number, r: number): number {
  if (r < 0 || r > n) return 0;
  let result = 1;
  for (let i = 0; i < r; i++) result *= n - i;
  return result;
}

export function isqrt(n: number): number {
  if (n < 0) throw new RangeError("isqrt of negative number");
  return Math.floor(Math.sqrt(n));
}

export function digits(n: number, base: number = 10): number[] {
  if (!Number.isInteger(n)) throw new TypeError("digits requires an integer");
  if (!Number.isInteger(base) || base < 2)
    throw new RangeError("digits base must be an integer >= 2");
  n = Math.abs(n);
  if (n === 0) return [0];
  const result: number[] = [];
  while (n > 0) {
    result.unshift(n % base);
    n = Math.floor(n / base);
  }
  return result;
}

export function digitSum(n: number): number {
  return digits(n).reduce((a, b) => a + b, 0);
}

export function divisors(n: number): number[] {
  n = Math.abs(n);
  if (n === 0) return [];
  const result: number[] = [];
  for (let i = 1; i * i <= n; i++) {
    if (n % i === 0) {
      result.push(i);
      if (i !== n / i) result.push(n / i);
    }
  }
  return result.sort((a, b) => a - b);
}

// ============================================================================
// Conversion & Formatting
// ============================================================================

// toBin/toOct/toHex: the integer part of `n` in that base, with a leading "-"
// for negatives (no 32-bit wrap-around: toHex(2 ** 32) is "100000000" and
// toHex(-1) is "-1").
export function toBin(n: number): string {
  return Math.trunc(n).toString(2);
}

export function toOct(n: number): string {
  return Math.trunc(n).toString(8);
}

export function toHex(n: number): string {
  return Math.trunc(n).toString(16);
}

export function toBase(n: number, base: number): string {
  return n.toString(base);
}

export function toOrdinal(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = Math.abs(n) % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

export function toWords(n: number): string {
  if (n === 0) return "zero";
  if (!Number.isFinite(n)) return String(n);

  const ones = [
    "",
    "one",
    "two",
    "three",
    "four",
    "five",
    "six",
    "seven",
    "eight",
    "nine",
    "ten",
    "eleven",
    "twelve",
    "thirteen",
    "fourteen",
    "fifteen",
    "sixteen",
    "seventeen",
    "eighteen",
    "nineteen",
  ];
  const tens = [
    "",
    "",
    "twenty",
    "thirty",
    "forty",
    "fifty",
    "sixty",
    "seventy",
    "eighty",
    "ninety",
  ];

  // The fractional part is dropped (toward zero): toWords(-1.5) is "negative one",
  // toWords(-0.5) is "zero".
  n = Math.trunc(n);
  if (n === 0) return "zero";
  const negative = n < 0;
  n = Math.abs(n);

  if (n < 20) return (negative ? "negative " : "") + ones[n];
  if (n < 100)
    return (
      (negative ? "negative " : "") + tens[Math.floor(n / 10)] + (n % 10 ? "-" + ones[n % 10] : "")
    );
  if (n < 1000)
    return (
      (negative ? "negative " : "") +
      ones[Math.floor(n / 100)] +
      " hundred" +
      (n % 100 ? " and " + toWords(n % 100) : "")
    );

  const scales = ["", "thousand", "million", "billion", "trillion"];
  const parts: string[] = [];
  let scaleIdx = 0;
  while (n > 0) {
    const chunk = n % 1000;
    if (chunk > 0) {
      parts.unshift(toWords(chunk) + (scales[scaleIdx] ? " " + scales[scaleIdx] : ""));
    }
    n = Math.floor(n / 1000);
    scaleIdx++;
  }

  return (negative ? "negative " : "") + parts.join(", ");
}

export function toRoman(n: number): string {
  if (n <= 0 || n >= 4000 || !Number.isInteger(n))
    throw new RangeError("Roman numerals require 1-3999");

  const vals = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1];
  const syms = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"];
  let result = "";
  for (let i = 0; i < vals.length; i++) {
    while (n >= vals[i]) {
      result += syms[i];
      n -= vals[i];
    }
  }
  return result;
}

export function padStart(n: number, length: number, fill: string = "0"): string {
  return String(n).padStart(length, fill);
}

export function toPercent(n: number, decimals: number = 0): string {
  return (n * 100).toFixed(decimals) + "%";
}

export function toFileSize(bytes: number, decimals: number = 2): string {
  if (!Number.isFinite(bytes)) return `${bytes} B`;
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB", "PB"];
  const abs = Math.abs(bytes);
  // Values below 1 B stay in bytes; beyond PB stay in PB.
  const i = abs < 1 ? 0 : Math.min(sizes.length - 1, Math.floor(Math.log(abs) / Math.log(k)));
  return parseFloat((bytes / k ** i).toFixed(decimals)) + " " + sizes[i];
}

export function toDuration(ms: number): string {
  const abs = Math.abs(ms);
  if (abs < 1000) return `${ms}ms`;
  if (abs < 60_000) return `${(ms / 1000).toFixed(1)}s`;
  if (abs < 3_600_000) return `${Math.floor(ms / 60_000)}m ${Math.floor((ms % 60_000) / 1000)}s`;
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  return `${h}h ${m}m`;
}

export function toCompact(n: number): string {
  const abs = Math.abs(n);
  if (abs >= 1e12) return (n / 1e12).toFixed(1) + "T";
  if (abs >= 1e9) return (n / 1e9).toFixed(1) + "B";
  if (abs >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (abs >= 1e3) return (n / 1e3).toFixed(1) + "K";
  return String(n);
}

// ============================================================================
// Iteration (Ruby times/upto/downto, Kotlin rangeTo, Scala to/until)
// ============================================================================

/**
 * Creates an inclusive Range from this number to end.
 * The Range is lazy — use `.toArray()` to materialize.
 *
 * @example
 * (1).to(5)                    // Range { 1..5 inclusive }
 * (1).to(10).step(2).toArray() // [1, 3, 5, 7, 9]
 * (1).to(5).contains(3)        // true
 */
export function to(n: number, end: number): Range {
  return rangeInclusive(n, end);
}

/**
 * Creates an exclusive Range from this number to end (end not included).
 * The Range is lazy — use `.toArray()` to materialize.
 *
 * @example
 * (1).until(5)                    // Range { 1..<5 exclusive }
 * (1).until(10).step(2).toArray() // [1, 3, 5, 7, 9]
 * (0).until(arr.length)           // common pattern for array indices
 */
export function until(n: number, end: number): Range {
  return rangeExclusive(n, end);
}

export function times<T>(n: number, fn: (i: number) => T): T[] {
  const result: T[] = [];
  for (let i = 0; i < n; i++) result.push(fn(i));
  return result;
}

export function timesVoid(n: number, fn: (i: number) => void): void {
  for (let i = 0; i < n; i++) fn(i);
}

export function* upTo(start: number, end: number, step: number = 1): Generator<number> {
  if (!(step > 0)) throw new RangeError("upTo step must be positive");
  for (let i = start; i <= end; i += step) yield i;
}

export function* downTo(start: number, end: number, step: number = 1): Generator<number> {
  if (!(step > 0)) throw new RangeError("downTo step must be positive");
  for (let i = start; i >= end; i -= step) yield i;
}

export function rangeTo(start: number, end: number, step?: number): number[] {
  const s = step ?? (start <= end ? 1 : -1);
  if (s === 0 || Number.isNaN(s)) throw new RangeError("rangeTo step must be non-zero");
  const result: number[] = [];
  if (s > 0) {
    for (let i = start; i <= end; i += s) result.push(i);
  } else {
    for (let i = start; i >= end; i += s) result.push(i);
  }
  return result;
}

export function rangeUntil(start: number, end: number, step?: number): number[] {
  const s = step ?? (start <= end ? 1 : -1);
  if (s === 0 || Number.isNaN(s)) throw new RangeError("rangeUntil step must be non-zero");
  const result: number[] = [];
  if (s > 0) {
    for (let i = start; i < end; i += s) result.push(i);
  } else {
    for (let i = start; i > end; i += s) result.push(i);
  }
  return result;
}

// ============================================================================
// Saturating & Wrapping Arithmetic (Rust)
// ============================================================================

export function saturatingAdd(a: number, b: number, max: number = Number.MAX_SAFE_INTEGER): number {
  const result = a + b;
  return result > max ? max : result;
}

export function saturatingSub(a: number, b: number, min: number = Number.MIN_SAFE_INTEGER): number {
  const result = a - b;
  return result < min ? min : result;
}

export function wrappingAdd(a: number, b: number, bits: number = 32): number {
  const max = 2 ** bits;
  return (((a + b) % max) + max) % max;
}

export function wrappingSub(a: number, b: number, bits: number = 32): number {
  const max = 2 ** bits;
  return (((a - b) % max) + max) % max;
}

// ============================================================================
// Random (commonly requested in JS/TS)
// ============================================================================

export function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function randomFloat(min: number, max: number): number {
  return Math.random() * (max - min) + min;
}

// ============================================================================
// Aggregate — collect all into a namespace-like object for extension
// ============================================================================

export const NumberExt = {
  // Math.* wrappers
  abs,
  ceil,
  floor,
  round,
  trunc,
  sqrt,
  cbrt,
  sign,
  log,
  log10,
  log2,
  exp,
  sin,
  cos,
  tan,
  asin,
  acos,
  atan,
  sinh,
  cosh,
  tanh,
  atan2,
  hypot,
  // Note: pow, min, max come from typeclasses/numeric-ops.ts
  // Custom extensions
  clamp,
  lerp,
  inverseLerp,
  remap,
  roundTo,
  ceilTo,
  floorTo,
  truncTo,
  snap,
  isEven,
  isOdd,
  isPositive,
  isNegative,
  isZero,
  isInteger,
  isFinite: isFiniteNum,
  isNaN: isNaN_,
  isBetween,
  isMultipleOf,
  isPrime,
  isPerfectSquare,
  isPowerOfTwo,
  gcd,
  lcm,
  factorial,
  fibonacci,
  nCr,
  nPr,
  isqrt,
  digits,
  digitSum,
  divisors,
  toBin,
  toOct,
  toHex,
  toBase,
  toOrdinal,
  toWords,
  toRoman,
  padStart,
  toPercent,
  toFileSize,
  toDuration,
  toCompact,
  times,
  timesVoid,
  upTo,
  downTo,
  to,
  until,
  rangeTo,
  rangeUntil,
  saturatingAdd,
  saturatingSub,
  wrappingAdd,
  wrappingSub,
  randomInt,
  randomFloat,
} as const;
