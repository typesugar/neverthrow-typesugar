/**
 * Resolution Scope Tracking
 *
 * Tracks which typeclasses and extensions are "in scope" for a given file:
 * the typeclasses it defines, and the operator / method / label syntax its
 * `@syntax-*` marker imports activate (PEP-052).
 *
 * Each file's scope still records the configured `resolution.mode`, but
 * nothing reads it: 1.0 has no "automatic" or "explicit" modes and no prelude.
 */

import * as ts from "typescript";
import { config, ResolutionMode } from "./config.js";
import { getSyntaxMarkerFallback } from "./syntax-marker-fallback.js";
import { isSyntheticNode } from "./ast-utils.js";

/**
 * Resolution scope for a single file.
 */
export interface FileResolutionScope {
  /** The file path */
  fileName: string;
  /** The resolution mode for this file */
  mode: ResolutionMode;
  /** Typeclasses defined in this file (via @typeclass) — always in scope */
  definedTypeclasses: Set<string>;
  /** Whether this file has a "use no typesugar" directive */
  optedOut: boolean;
  /** Specific features opted out of */
  optedOutFeatures: Set<string>;
  /** Whether this file has a "use extension" directive */
  hasUseExtension: boolean;
  /**
   * Typeclasses whose OPERATOR syntax (tier 3) is activated in this file, via a
   * side-effect import of a module carrying a `@syntax-operators <TC>` marker
   * (PEP-052). `a === b` only rewrites when its typeclass is in this set.
   * Operators imply methods, so an entry here is also added to
   * {@link activatedMethodSyntax}.
   */
  activatedOperatorSyntax: Set<string>;
  /**
   * Typeclasses whose METHOD syntax (tier 2) is activated in this file, via a
   * side-effect import of a module carrying a `@syntax-methods <TC>` (or the
   * louder `@syntax-operators <TC>`) marker (PEP-052). `a.eq(b)` only resolves
   * when its typeclass is in this set.
   */
  activatedMethodSyntax: Set<string>;
  /**
   * Labeled-block / trigger-label macros whose LABEL syntax is activated in
   * this file, via a side-effect import of a module carrying a
   * `@syntax-labels <macroName>` marker (PEP-052 Part 2). Keyed by MACRO name
   * (e.g. "letYield", "contract"), not label text, so one marker activates all
   * of a macro's label aliases (`let:`/`seq:`). A `let: { ... }` block only
   * expands when its macro is in this set.
   */
  activatedLabelSyntax: Set<string>;
}

/**
 * Global scope tracker for all files being processed.
 */
export class ResolutionScopeTracker {
  private fileScopes = new Map<string, FileResolutionScope>();

  /**
   * Get or create a resolution scope for a file.
   */
  getScope(fileName: string): FileResolutionScope {
    if (!this.fileScopes.has(fileName)) {
      this.fileScopes.set(fileName, {
        fileName,
        mode: config.getResolutionModeForFile(fileName),
        definedTypeclasses: new Set(),
        optedOut: false,
        optedOutFeatures: new Set(),
        hasUseExtension: false,
        activatedOperatorSyntax: new Set(),
        activatedMethodSyntax: new Set(),
        activatedLabelSyntax: new Set(),
      });
    }
    return this.fileScopes.get(fileName)!;
  }

  /**
   * Register a typeclass as defined in the current file.
   *
   * Typeclasses defined in a file are always in scope for that file,
   * regardless of resolution mode. You don't need to import what you define.
   */
  registerDefinedTypeclass(fileName: string, typeclassName: string): void {
    const scope = this.getScope(fileName);
    scope.definedTypeclasses.add(typeclassName);
  }

  /**
   * Activate operator syntax (tier 3) for a typeclass in a file (PEP-052).
   * Operators imply methods, so this also activates method syntax.
   */
  activateOperatorSyntax(fileName: string, typeclassName: string): void {
    const scope = this.getScope(fileName);
    scope.activatedOperatorSyntax.add(typeclassName);
    scope.activatedMethodSyntax.add(typeclassName);
  }

  /**
   * Activate method syntax (tier 2) for a typeclass in a file (PEP-052).
   */
  activateMethodSyntax(fileName: string, typeclassName: string): void {
    const scope = this.getScope(fileName);
    scope.activatedMethodSyntax.add(typeclassName);
  }

  /**
   * Activate label syntax for a labeled-block / trigger-label macro in a file
   * (PEP-052 Part 2). Keyed by macro name.
   */
  activateLabelSyntax(fileName: string, macroName: string): void {
    const scope = this.getScope(fileName);
    scope.activatedLabelSyntax.add(macroName);
  }

  /**
   * Whether a typeclass's operator syntax is activated in a file.
   * Respects file-level opt-out.
   */
  isOperatorSyntaxActivated(fileName: string, typeclassName: string): boolean {
    const scope = this.getScope(fileName);
    if (scope.optedOut) return false;
    return scope.activatedOperatorSyntax.has(typeclassName);
  }

  /**
   * Whether a typeclass's method syntax is activated in a file.
   * Respects file-level opt-out.
   */
  isMethodSyntaxActivated(fileName: string, typeclassName: string): boolean {
    const scope = this.getScope(fileName);
    if (scope.optedOut) return false;
    return scope.activatedMethodSyntax.has(typeclassName);
  }

  /**
   * Whether a labeled-block / trigger-label macro's label syntax is activated
   * in a file. Respects file-level opt-out.
   */
  isLabelSyntaxActivated(fileName: string, macroName: string): boolean {
    const scope = this.getScope(fileName);
    if (scope.optedOut) return false;
    return scope.activatedLabelSyntax.has(macroName);
  }

  /** Typeclasses defined in a file (via `@typeclass`) — always activated locally. */
  getDefinedTypeclasses(fileName: string): Set<string> {
    return this.getScope(fileName).definedTypeclasses;
  }

  /** All typeclasses with operator syntax activated in a file. */
  getActivatedOperatorSyntax(fileName: string): Set<string> {
    return this.getScope(fileName).activatedOperatorSyntax;
  }

  /** All typeclasses with method syntax activated in a file. */
  getActivatedMethodSyntax(fileName: string): Set<string> {
    return this.getScope(fileName).activatedMethodSyntax;
  }

  /**
   * Set the opt-out status for a file.
   */
  setOptedOut(fileName: string, optedOut: boolean): void {
    const scope = this.getScope(fileName);
    scope.optedOut = optedOut;
  }

  /**
   * Add a specific feature to the opt-out list.
   */
  addOptedOutFeature(fileName: string, feature: string): void {
    const scope = this.getScope(fileName);
    scope.optedOutFeatures.add(feature);
  }

  /**
   * Check if a specific feature is opted out for a file.
   */
  isFeatureOptedOut(fileName: string, feature: string): boolean {
    const scope = this.getScope(fileName);
    return scope.optedOut || scope.optedOutFeatures.has(feature);
  }

  /**
   * Set whether a file has "use extension" directive.
   * When set, all exports from this file are treated as extension methods.
   */
  setHasUseExtension(fileName: string, hasUseExtension: boolean): void {
    const scope = this.getScope(fileName);
    scope.hasUseExtension = hasUseExtension;
  }

  /**
   * Check if a file has "use extension" directive.
   */
  hasUseExtension(fileName: string): boolean {
    const scope = this.getScope(fileName);
    return scope.hasUseExtension;
  }

  /**
   * Clear the scope for a file (e.g., when re-processing).
   */
  clearScope(fileName: string): void {
    this.fileScopes.delete(fileName);
  }

  /**
   * Clear all scopes.
   */
  reset(): void {
    this.fileScopes.clear();
  }
}

/**
 * Global resolution scope tracker instance.
 */
export const globalResolutionScope = new ResolutionScopeTracker();

/**
 * Read PEP-052 syntax-activation markers from a module imported by a side-effect
 * (or any) import. A marker module is a tiny file whose first statement carries a
 * module-level JSDoc tag naming the typeclass it activates, e.g.:
 *
 * ```ts
 * // @typesugar/std/syntax/eq/ops
 * /** @syntax-operators Eq *\/
 * export {};
 * ```
 *
 * Returns the typeclass names activated for operator and method syntax, plus the
 * macro names activated for label syntax (`@syntax-labels <macroName>`). Requires
 * a `program` to resolve the module specifier to its source file; without one,
 * no markers are discovered (callers in registry-only paths pass none).
 */
interface SyntaxMarkers {
  operatorTCs: string[];
  methodTCs: string[];
  /** Macro names from `@syntax-labels <macroName>` tags (PEP-052 Part 2). */
  labelMacros: string[];
}

// Memoize marker results per resolved module SourceFile. Marker modules are
// program-stable, and importing a large barrel/.d.ts otherwise re-scans all its
// statements per importing file. Keyed by SourceFile (a WeakMap) so it invalidates
// automatically across watch/LSP program rebuilds.
const markerCache = new WeakMap<ts.SourceFile, SyntaxMarkers>();

function readSyntaxActivationMarkers(
  checker: ts.TypeChecker,
  moduleSpecifier: ts.Expression
): SyntaxMarkers {
  const empty: SyntaxMarkers = { operatorTCs: [], methodTCs: [], labelMacros: [] };

  // Resolve the imported module via the checker (respects the program's module
  // resolution — works for on-disk and virtual/in-memory hosts alike).
  const moduleSymbol = checker.getSymbolAtLocation(moduleSpecifier);
  const moduleFile = moduleSymbol?.declarations?.find((d): d is ts.SourceFile =>
    ts.isSourceFile(d)
  );
  if (!moduleFile) return empty;

  const cached = markerCache.get(moduleFile);
  if (cached) return cached;

  // The marker JSDoc is attached to an exported declaration in the module (a real
  // declaration rather than a bare `export {}`, so it survives `.d.ts` bundling).
  // Scan every top-level statement so we don't depend on declaration ordering in
  // the generated declaration file.
  const operatorTCs: string[] = [];
  const methodTCs: string[] = [];
  const labelMacros: string[] = [];
  for (const stmt of moduleFile.statements) {
    for (const tag of ts.getJSDocTags(stmt)) {
      const tagName = tag.tagName.text;
      if (
        tagName !== "syntax-operators" &&
        tagName !== "syntax-methods" &&
        tagName !== "syntax-labels"
      ) {
        continue;
      }
      const name =
        typeof tag.comment === "string"
          ? tag.comment.trim()
          : ts.getTextOfJSDocComment(tag.comment)?.trim();
      if (!name) continue;
      if (tagName === "syntax-operators") operatorTCs.push(name);
      else if (tagName === "syntax-methods") methodTCs.push(name);
      else labelMacros.push(name);
    }
  }
  const result: SyntaxMarkers = { operatorTCs, methodTCs, labelMacros };
  markerCache.set(moduleFile, result);
  return result;
}

/**
 * Parse imports from a source file and register them in the scope.
 *
 * When `program` is supplied, PEP-052 syntax-activation markers on imported
 * modules are discovered and recorded (operator/method syntax activation).
 */
export function scanImportsForScope(
  sourceFile: ts.SourceFile,
  tracker: ResolutionScopeTracker = globalResolutionScope,
  program?: ts.Program
): void {
  const fileName = sourceFile.fileName;

  // Clear existing scope for this file
  tracker.clearScope(fileName);

  // Imports are scanned from the program's copy of the file when available:
  // `sourceFile` may be a re-parsed copy that is not part of `program` (the
  // expression-comprehension preprocessor rewrites the text and the pipeline
  // re-parses it), and checker-based module resolution only works on nodes
  // that belong to the program. Preprocessing never touches imports, so the
  // program copy's import list is authoritative either way. When the file is
  // not in the program at all, checker resolution is guaranteed to fail —
  // skip it entirely (the syntaxModule text fallback below still applies).
  const programFile = program?.getSourceFile(fileName);
  const importScanFile = programFile ?? sourceFile;
  const checker = programFile ? program!.getTypeChecker() : undefined;

  // Scan imports
  ts.forEachChild(importScanFile, (node) => {
    if (ts.isImportDeclaration(node)) {
      const moduleSpecifier = node.moduleSpecifier;
      if (!ts.isStringLiteral(moduleSpecifier)) return;

      const moduleName = moduleSpecifier.text;

      // PEP-052: discover syntax-activation markers on the imported module.
      // This runs for every import — including side-effect imports
      // (`import "@typesugar/std/syntax/eq/ops"`), which have no import clause.
      if (checker) {
        const { operatorTCs, methodTCs, labelMacros } = readSyntaxActivationMarkers(
          checker,
          moduleSpecifier
        );
        for (const tc of operatorTCs) tracker.activateOperatorSyntax(fileName, tc);
        for (const tc of methodTCs) tracker.activateMethodSyntax(fileName, tc);
        for (const m of labelMacros) tracker.activateLabelSyntax(fileName, m);
      }
      // PEP-052 Wave 6 (unified with Wave 2's syntaxModule index in a later
      // pass): resolution-free fallback for operator/method/label syntax
      // markers, keyed by exact import specifier — see
      // syntax-marker-fallback.ts. Populated at macro-registration time
      // (labels, from each macro's `syntaxModule`) and by provider packages
      // directly (operators/methods, for typeclasses, which have no
      // `MacroDefinition`/`syntaxModule` to key off).
      const markerFallback = getSyntaxMarkerFallback(moduleName);
      if (markerFallback) {
        for (const tc of markerFallback.operators ?? [])
          tracker.activateOperatorSyntax(fileName, tc);
        for (const tc of markerFallback.methods ?? []) tracker.activateMethodSyntax(fileName, tc);
        for (const m of markerFallback.labels ?? []) tracker.activateLabelSyntax(fileName, m);
      }
    }
  });

  // PEP-052: pre-register typeclasses DEFINED in this file (interfaces carrying a
  // `@typeclass` JSDoc tag). A defined typeclass activates its own operator/method
  // syntax locally ("you don't import what you define"). Doing this in the pre-scan
  // (rather than waiting for the `@typeclass` macro to expand during the top-down
  // visit) makes activation independent of declaration order — an operator used
  // above its typeclass's declaration in the same file still activates.
  for (const stmt of sourceFile.statements) {
    // (a) `/** @typeclass */ interface Foo<A> { ... }`
    if (
      ts.isInterfaceDeclaration(stmt) &&
      ts.getJSDocTags(stmt).some((tag) => tag.tagName.text === "typeclass")
    ) {
      tracker.registerDefinedTypeclass(fileName, stmt.name.text);
      continue;
    }
    // (b) the call form `typeclass("Foo");` (used when the interface carries no
    // JSDoc tag) — register it here too so same-file activation doesn't depend on
    // the macro running during the top-down visit.
    if (ts.isExpressionStatement(stmt) && ts.isCallExpression(stmt.expression)) {
      const call = stmt.expression;
      if (
        ts.isIdentifier(call.expression) &&
        call.expression.text === "typeclass" &&
        call.arguments.length >= 1 &&
        ts.isStringLiteralLike(call.arguments[0])
      ) {
        tracker.registerDefinedTypeclass(fileName, call.arguments[0].text);
      }
    }
  }

  // Scan for directives at file level (top-level statements only)
  for (const stmt of sourceFile.statements) {
    if (ts.isExpressionStatement(stmt)) {
      const expr = stmt.expression;
      if (ts.isStringLiteral(expr)) {
        const text = expr.text;

        // Full opt-out
        if (text === "use no typesugar") {
          tracker.setOptedOut(fileName, true);
          continue;
        }

        // Feature-specific opt-outs
        const featureMatch = text.match(/^use no typesugar (\w+)$/);
        if (featureMatch) {
          const feature = featureMatch[1];
          if (["operators", "derive", "extensions", "typeclasses", "macros"].includes(feature)) {
            tracker.addOptedOutFeature(fileName, feature);
          }
        }

        // "use extension" directive - marks all exports as extension methods
        if (text === "use extension") {
          tracker.setHasUseExtension(fileName, true);
        }
      }
    }
  }
}

/**
 * Parse a single line for inline opt-out comments.
 * Supports: // @ts-no-typesugar, // @ts-no-typesugar operators, etc.
 */
export function hasInlineOptOut(
  sourceFile: ts.SourceFile,
  node: ts.Node,
  feature?: string
): boolean {
  // Synthetic nodes have no source position — no comment to check
  if (isSyntheticNode(node)) return false;

  const nodeStart = node.getStart(sourceFile);
  const lineStarts = sourceFile.getLineStarts();

  // Find the line this node is on
  let lineIndex = 0;
  for (let i = 0; i < lineStarts.length; i++) {
    if (lineStarts[i] <= nodeStart) {
      lineIndex = i;
    } else {
      break;
    }
  }

  const lineStart = lineStarts[lineIndex];
  const lineEnd =
    lineIndex + 1 < lineStarts.length ? lineStarts[lineIndex + 1] : sourceFile.getEnd();

  // Only COMMENT text on the line counts: a marker inside a string literal
  // (`log("// @ts-no-typesugar")`) is not an opt-out.
  const comments = commentTextsInRange(sourceFile, lineStart, lineEnd);

  // Check for inline opt-out comment
  if (feature) {
    const featureMarker = new RegExp(`@ts-no-typesugar[ \t]+${escapeRegExp(feature)}(?![\\w-])`);
    return comments.some(
      (c) =>
        featureMarker.test(c) ||
        c.includes("@ts-no-typesugar-all") ||
        // The bare marker (no feature word after it) opts out of everything —
        // the documented `// @ts-no-typesugar` form (deep review core #17).
        BARE_OPT_OUT.test(c)
    );
  }

  return comments.some((c) => c.includes("@ts-no-typesugar"));
}

/** `@ts-no-typesugar` not followed by `-all`/a word char or by a feature name. */
const BARE_OPT_OUT = /@ts-no-typesugar(?![\w-]|[ \t]+\w)/;

function escapeRegExp(text: string): string {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Texts of the comments that START within [start, end) of the file, found by
 * scanning tokens (with trivia) over that range — so string/template contents
 * are never mistaken for comments.
 */
function commentTextsInRange(sourceFile: ts.SourceFile, start: number, end: number): string[] {
  const text = sourceFile.text;
  if (!text.slice(start, end).includes("@ts-no-typesugar")) return []; // fast path
  const scanner = ts.createScanner(
    ts.ScriptTarget.Latest,
    /* skipTrivia */ false,
    sourceFile.languageVariant,
    text,
    undefined,
    start,
    end - start
  );
  const out: string[] = [];
  // Template substitutions: the scanner returns a `}` as a plain brace, and
  // only the caller knows it closes a `${`. Without re-scanning it as the
  // template's continuation, the template's closing backtick read as the
  // start of a new template, which swallowed the rest of the line, comments
  // included (`grammar\`a ${y}\` // @ts-no-typesugar` was not opted out).
  // Each entry: the brace depth inside one open `${ ... }`.
  const substitutions: number[] = [];
  for (let kind = scanner.scan(); kind !== ts.SyntaxKind.EndOfFileToken; kind = scanner.scan()) {
    if (
      kind === ts.SyntaxKind.SingleLineCommentTrivia ||
      kind === ts.SyntaxKind.MultiLineCommentTrivia
    ) {
      out.push(scanner.getTokenText());
    } else if (kind === ts.SyntaxKind.TemplateHead) {
      substitutions.push(0);
    } else if (kind === ts.SyntaxKind.OpenBraceToken && substitutions.length > 0) {
      substitutions[substitutions.length - 1]++;
    } else if (kind === ts.SyntaxKind.CloseBraceToken && substitutions.length > 0) {
      if (substitutions[substitutions.length - 1] > 0) {
        substitutions[substitutions.length - 1]--;
      } else if (scanner.reScanTemplateToken(false) === ts.SyntaxKind.TemplateTail) {
        substitutions.pop();
      } // TemplateMiddle: the next substitution, at depth 0 again
    }
  }
  return out;
}

/**
 * Check if a node is inside a function with "use no typesugar" directive.
 */
export function isInOptedOutScope(
  sourceFile: ts.SourceFile,
  node: ts.Node,
  tracker: ResolutionScopeTracker = globalResolutionScope,
  feature?: string
): boolean {
  const fileName = sourceFile.fileName;
  const scope = tracker.getScope(fileName);

  // Check file-level opt-out
  if (scope.optedOut) {
    return true;
  }

  // Check feature-specific opt-out
  if (feature && scope.optedOutFeatures.has(feature)) {
    return true;
  }

  // Check inline opt-out comment on this line
  if (hasInlineOptOut(sourceFile, node, feature)) {
    return true;
  }

  // Check for function-scoped opt-out
  let current: ts.Node | undefined = node;
  while (current) {
    if (
      ts.isFunctionDeclaration(current) ||
      ts.isFunctionExpression(current) ||
      ts.isArrowFunction(current) ||
      ts.isMethodDeclaration(current)
    ) {
      // Check if the function body starts with "use no typesugar"
      const body = (current as { body?: ts.Node }).body;
      if (body && ts.isBlock(body)) {
        const firstStatement = body.statements[0];
        if (firstStatement && ts.isExpressionStatement(firstStatement)) {
          const expr = firstStatement.expression;
          if (ts.isStringLiteral(expr)) {
            const text = expr.text;
            if (text === "use no typesugar") {
              return true;
            }
            if (feature && text === `use no typesugar ${feature}`) {
              return true;
            }
          }
        }
      }
    }
    current = current.parent;
  }

  return false;
}
